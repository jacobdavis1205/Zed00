# Zed-00 — Foundry VTT System

A Stars Without Number homebrew for colony survival on a sealed world.

## Installing

**If you run your own server:** drop this `zed00` folder into
`Data/systems/`, restart Foundry, and create a world using the system.

**If someone else hosts for you:** send them the zip. They unpack it into
`Data/systems/zed00/`. Later, putting this on GitHub Releases means they
can install from a manifest URL once and click Update forever after.

Requires **Foundry v13.345** or later.

## What's in it

**Two dice scales, kept strictly separate.** Skill checks are
2d6 + skill + attribute against a TN. Saves are a BARE d20 against a
target of 16 − level − attribute modifier, because the modifier is
already in the target.

**Strain is the WIS score and never grows.** HP triples over a campaign
and Strain doesn't, so by level 10 the mind is the only thing that can
still break.

**Exposure** is one track with six hazard categories. Weekly gain is the
highest hazard left after gear, never the sum.

**Every tunable number is a setting.** The Unstable threshold, Exposure
penalties, push costs, medicine modifiers, darkness, colony yields — all
editable in the Foundry UI at runtime, with no reinstall. Change them
mid-session.

**Automation is optional.** `Apply condition penalties automatically` is
on by default; turn it off and the sheet simply displays everything while
the GM applies it by hand.

## Known gaps

- Compendium packs are not yet compiled. Source JSON for 150 items lives
  in `../packs-source/`.
- Colony phase, Banner management and disease tracking are not automated.
- No artwork. Item icons point at Foundry's bundled set.
