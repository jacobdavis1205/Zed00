/**
 * What stacks and what doesn't.
 *
 * The trouble with quantity is that some things carry state of their own
 * and some don't. Twenty Metal is twenty Metal — there is nothing to say
 * about any one of them. Two rifles are not interchangeable the moment
 * one has four rounds left and the other is full, and a single `ammo`
 * field cannot describe both.
 *
 * So the rule is: **anything with a magazine is its own item.** Buy three
 * rifles and you get three rifles, each with its own ammunition, its own
 * condition and its own modification. Everything else — melee weapons,
 * armour, gear, drugs, materials — stacks freely, and readying one peels
 * it off the pile.
 *
 * That keeps reloading honest without making the player think about it,
 * and it is the reason the gear tab shows a quantity box on a dagger and
 * not on an autopistol.
 */

/** Does this item keep state that can't be shared across a stack? */
export function isUnique(item) {
  const s = item?.system ?? {};
  if (item?.type === "weapon") return !!s.magazine;
  return false;
}

export function registerStackingHooks() {

  // Anything perishable is dated the moment it exists, wherever it lands.
  //
  // This used to happen only on the way into a stockpile, which meant a
  // meal dragged straight onto a character sheet had no date at all and
  // so never went off. Stamping it at creation covers every route in —
  // a compendium drop, a crafted batch, a sheet-to-sheet drag — and
  // because it only stamps an unstamped item, a lot that already has a
  // date keeps it through any number of moves.
  Hooks.on("preCreateItem", (item) => {
    // Only things that actually exist somewhere get a date. A catalogue
    // entry in the Items sidebar, or a compendium record, is a recipe
    // rather than a lot of food — dating those would mean a meal dragged
    // out in week 40 arrived stamped from week 1 and already rotten.
    if (!item?.parent || item?.pack) return;
    const s = item.system ?? {};
    const shelf = Number(s.shelfLife) || 0;
    const already = Number(s.spoilsOn) || 0;
    if (!shelf || already) return;
    const week = Number(game.settings?.get?.("zed00", "week")) || 1;
    item.updateSource({ "system.spoilsOn": week + shelf });
  });

  // Creating several of something that can't stack makes several of them.
  Hooks.on("preCreateItem", (item, data) => {
    if (!isUnique(item)) return;
    const qty = Number(data?.system?.quantity) || 1;
    if (qty > 1) item.updateSource({ "system.quantity": 1 });
  });

  Hooks.on("createItem", async (item, options, userId) => {
    if (game.user.id !== userId) return;
    if (!isUnique(item) || !item.parent) return;
    const wanted = Number(options?.zed00Copies) || 0;
    if (wanted <= 1) return;
    const copies = Array.from({ length: wanted - 1 }, () => {
      const c = item.toObject();
      delete c._id;
      c.system.quantity = 1;
      return c;
    });
    await item.parent.createEmbeddedDocuments("Item", copies);
  });

  // And nudging the quantity up on one is the same request.
  Hooks.on("preUpdateItem", (item, change) => {
    if (!isUnique(item)) return;
    const qty = change?.system?.quantity;
    if (qty === undefined) return;
    const n = Number(qty) || 0;
    if (n <= 1) return;
    change.system.quantity = 1;
    if (!item.parent) return;
    // Make the extras for real rather than silently refusing.
    const copies = Array.from({ length: n - 1 }, () => {
      const c = item.toObject();
      delete c._id;
      c.system.quantity = 1;
      c.system.ammo = 0;              // a new gun off the rack is empty
      return c;
    });
    item.parent.createEmbeddedDocuments("Item", copies).then(() => {
      ui.notifications.info(
        `${item.name} carries its own ammunition, so ${n - 1} more were added ` +
        `as separate entries rather than a stack.`);
    });
  });
}

/* ------------------------------------------------------------------ */
/*  Freshness                                                          */
/* ------------------------------------------------------------------ */

/**
 * How long a perishable has left, read honestly.
 *
 * `spoilsOn` is an absolute week, which is the right way to store it —
 * it survives moving between sheds and sheets. It breaks in one case:
 * winding the calendar backwards. Rewind five weeks and a lot stamped
 * in the old timeline still carries a stamp from the future, so it
 * reports more life left than its shelf life allows — a meal that keeps
 * four weeks showing fourteen.
 *
 * A stamp that implies more life than the thing can possibly have is a
 * stamp from a timeline that no longer happened, so it is capped at the
 * shelf life. Nothing is written; the stored date is left alone in case
 * the calendar goes forward again.
 */
export function freshness(item, week) {
  const s = item?.system ?? {};
  const shelf = Number(s.shelfLife) || 0;
  const on = Number(s.spoilsOn) || 0;
  if (!shelf && !on) return { perishable: false, left: null, expired: false };

  const raw = on ? on - week : shelf;
  // Capped at the shelf life, and never below "already gone".
  const left = shelf ? Math.min(raw, shelf) : raw;
  return {
    perishable: true,
    left,
    expired: left <= 0,
    // True when the stamp is from a wound-back calendar, so a sheet can
    // say so rather than quietly showing a different number.
    rewound: shelf > 0 && raw > shelf
  };
}
