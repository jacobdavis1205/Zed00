/**
 * Structures on the map.
 *
 * Three problems this solves, all of them about a building being a very
 * different thing from a person even though Foundry only has one kind of
 * token:
 *
 *  1. Buildings should not be draggable by accident. A wall that slides
 *     two squares because you meant to click the colonist standing in
 *     front of it has quietly ruined the fight.
 *  2. Players need to read a stockpile's sheet without twenty-five
 *     buildings appearing in their Actors tab.
 *  3. Lights should light things, and only while they are powered.
 */

const FLAG = "zed00";

/** Is this token a structure? */
export function isStructure(doc) {
  return doc?.actor?.type === "structure" || doc?.type === "structure";
}

/**
 * The scene the colony is standing on.
 *
 * This used to be "whatever scene you happen to be looking at", which is
 * right most of the time and badly wrong the rest: walk the party into
 * an insect nest and the upkeep tally reports the nest's power grid,
 * which is to say none. A colony is a place, so it gets named once and
 * stays named.
 *
 * The designation is a world setting rather than a scene flag, so asking
 * the question never needs a scene in hand.
 */
export function colonyScene() {
  const id = game.settings?.get?.("zed00", "colonyScene");
  if (id) {
    const named = game.scenes?.get(id);
    if (named) return named;
  }
  // Nothing designated yet, or the designated scene has been deleted.
  return canvas?.scene ?? game.scenes?.active ?? game.scenes?.current ?? null;
}

/** Has somebody actually chosen one, or are we still guessing? */
export function colonySceneIsSet() {
  const id = game.settings?.get?.("zed00", "colonyScene");
  return !!(id && game.scenes?.get(id));
}

/** Is the party somewhere else at the moment? */
export function viewingElsewhere() {
  const home = colonyScene();
  return !!(home && canvas?.scene && canvas.scene.id !== home.id);
}

export async function setColonyScene(scene) {
  if (!game.user.isGM) return null;
  await game.settings.set("zed00", "colonyScene", scene?.id ?? "");
  invalidateStructures();
  ui.notifications.info(scene
    ? `${scene.name} is the colony. Upkeep, the week and the colony sheet ` +
      `read it from now on, wherever everyone happens to be standing.`
    : "Colony scene cleared — it falls back to whichever scene is open.");
  return scene ?? null;
}

/**
 * Every structure **standing on the map**.
 *
 * Not `game.actors`. The sidebar holds one entry per kind of building —
 * that is the whole point of unlinked tokens — so reading it counts one
 * battery however many you built, and counts things you have not built
 * at all. The tokens are the buildings; the sidebar is the catalogue.
 *
 * A token's `actor` is its own synthetic actor carrying its own data, so
 * two solar generators are two generators with two sets of hit points.
 * Linked tokens are the exception and share one actor, so they are
 * counted once however many are placed.
 *
 * Anything that asks "what has the colony got" must come through here.
 */
let cache = { scene: null, stamp: -1, list: null };
let stamp = 0;

/**
 * Throw the cached structure list away.
 *
 * Called whenever anything could have changed what is standing on the
 * map or what is in it. Cheap to call and cheap to get wrong in the
 * safe direction, so it is called generously.
 */
export function invalidateStructures() {
  cache.list = null;
  stamp++;
}

export function placedStructures(scene = null) {
  scene ??= colonyScene();
  if (!scene) return [];

  // Reading a token's `actor` builds a synthetic actor for an unlinked
  // token, so a full scan is not free, and the upkeep tally used to do
  // three of them per redraw. One scan per change is plenty.
  if (cache.list && cache.scene === scene.id && cache.stamp === stamp) {
    return cache.list;
  }

  const out = [];
  const seenLinked = new Set();
  for (const token of scene.tokens) {
    const actor = token.actor;
    if (actor?.type !== "structure") continue;
    if (token.actorLink) {
      if (seenLinked.has(token.actorId)) continue;
      seenLinked.add(token.actorId);
    }
    out.push(actor);
  }
  cache = { scene: scene.id, stamp, list: out };
  return out;
}

/** Stockpiles on the map, which is where the colony's goods actually are. */
export function placedStockpiles(scene = null) {
  return placedStructures(scene).filter(a => a.system.function === "stockpile");
}

/** Structures in the sidebar that are not on this scene — the catalogue. */
export function unplacedStructures(scene = null) {
  const on = new Set(placedStructures(scene).map(a => a.id));
  return game.actors.filter(a => a.type === "structure" && !on.has(a.id));
}

/** Is this structure token pinned in place? */
export function isPinned(tokenDoc) {
  return tokenDoc?.getFlag?.(FLAG, "pinned") !== false;
}

/* ------------------------------------------------------------------ */
/*  Pinning                                                           */
/* ------------------------------------------------------------------ */

const DARK = { bright: 0, dim: 0, alpha: 0, animation: { type: null } };

/**
 * Work out what light a structure should be throwing right now.
 *
 * The radii come off the structure itself, from the Area Lit column, so
 * a torch really does light a ninth of what a floodlight does. A flame
 * only needs to be standing; anything electric needs power as well.
 *
 * Returns a token light config, or the dark one if it should be off.
 */
export function lightFor(actor) {
  const sys = actor?.system;
  if (!sys || actor.type !== "structure") return null;
  if (!sys.lit?.bright && !sys.lit?.dim) return null;   // not a light at all

  // A flame needs no grid, but it still needs to be lit: `running` is the
  // switch for both, so a torch can be put out the same way a lamp can be
  // turned off. Either way a wrecked fixture throws nothing.
  const burning = !!sys.lit.flame;
  const on = sys.power.running && (burning ? sys.usable : sys.working);
  if (!on) return DARK;

  return {
    bright: sys.lit.bright,
    dim: sys.lit.dim,
    color: burning ? "#ffb066" : "#ffeec9",
    alpha: 0.12,
    luminosity: burning ? 0.4 : 0.5,
    animation: burning
      ? { type: "torch", speed: 2, intensity: 3 }
      : { type: null, speed: 5, intensity: 5 }
  };
}

/* ------------------------------------------------------------------ */

export function registerStructureHooks() {

  // Anything that could change what is on the map, or what is in it,
  // drops the cached scan.
  for (const h of ["createToken", "updateToken", "deleteToken",
                   "createActor", "updateActor", "deleteActor",
                   "createItem", "updateItem", "deleteItem",
                   "canvasReady", "updateScene"]) {
    Hooks.on(h, invalidateStructures);
  }

  /* --- 1. pinned structures do not move ------------------------- */

  Hooks.on("preUpdateToken", (tokenDoc, change, options) => {
    if (!isStructure(tokenDoc)) return;
    const moving = ("x" in change) || ("y" in change) || ("elevation" in change);
    if (!moving) return;
    if (options?.zed00Unpinned) return;      // deliberate move, let it through
    if (!isPinned(tokenDoc)) return;

    delete change.x;
    delete change.y;
    delete change.elevation;
    if (game.user.isGM) {
      ui.notifications.warn(
        `${tokenDoc.name} is pinned. Unpin it on its sheet to move it.`);
    }
    return Object.keys(change).length ? undefined : false;
  });

  /* --- 2. players see the sheet, not the sidebar ----------------- */

  // Structures are Observer-by-default so a player can open one from the
  // map. That would otherwise fill their Actors tab with buildings, so
  // the directory drops them for anyone who is not the GM.
  Hooks.on("renderActorDirectory", (app, html) => {
    if (game.user.isGM) return;
    const root = html instanceof HTMLElement ? html : html?.[0];
    if (!root) return;
    for (const li of root.querySelectorAll("[data-entry-id], [data-document-id]")) {
      const id = li.dataset.entryId ?? li.dataset.documentId;
      if (game.actors.get(id)?.type === "structure") li.remove();
    }
  });

  /* --- 3. lights light things ------------------------------------ */

  // When a structure's power or condition changes, its tokens catch up.
  Hooks.on("updateActor", async (actor, change) => {
    if (!game.user.isGM || actor.type !== "structure") return;
    const touched = change.system &&
      ("power" in change.system || "condition" in change.system);
    if (!touched) return;
    await syncLights(actor);
  });

  // And when one is first dropped on the map.
  Hooks.on("createToken", async (tokenDoc) => {
    if (!game.user.isGM || !isStructure(tokenDoc)) return;
    const light = lightFor(tokenDoc.actor);
    if (light) await tokenDoc.update({ light }, { diff: false });
  });

  /* --- 4. a deleted off-hand stops being an off-hand -------------- */

  // Otherwise the weapon keeps its "dual" tag and dual-wields a ghost.
  Hooks.on("deleteItem", async (item) => {
    const actor = item.parent;
    if (!actor || actor.documentName !== "Actor") return;
    if (!game.user.isGM && !actor.isOwner) return;
    const orphans = actor.items.filter(i =>
      i.type === "weapon" && i.system?.offhandId === item.id);
    for (const o of orphans) await o.update({ "system.offhandId": "" });
  });

  // Drop a stack of two paired daggers to one and the pairing goes too.
  Hooks.on("updateItem", async (item, change) => {
    if (item.type !== "weapon") return;
    if (!(change.system && "quantity" in change.system)) return;
    if (item.system.offhandId !== item.id) return;        // not self-paired
    if ((Number(item.system.quantity) || 1) >= 2) return;
    if (!item.parent?.isOwner) return;
    await item.update({ "system.offhandId": "" });
  });
}

/** Push the right light onto every token of this structure. */
export async function syncLights(actor) {
  const light = lightFor(actor);
  if (!light) return;
  for (const scene of game.scenes) {
    const mine = scene.tokens.filter(t => t.actorId === actor.id ||
      t.delta?.parent?.id === actor.id || t.actor === actor);
    if (!mine.length) continue;
    await scene.updateEmbeddedDocuments("Token",
      mine.map(t => ({ _id: t.id, light })), { diff: false });
  }
}

/** Move a pinned structure anyway — used by the sheet's unpin button. */
export async function moveUnpinned(tokenDoc, update) {
  return tokenDoc.update(update, { zed00Unpinned: true });
}

/**
 * Re-apply player access to structures that already exist.
 *
 * New structures are created Owner-by-default, but anything already in
 * a world keeps whatever it was made with. This brings them into line
 * so players can use the sheds they have already built.
 */
export async function grantPlayerAccess(level = CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER) {
  if (!game.user.isGM) return;
  const all = game.actors.filter(a => a.type === "structure");
  const updates = all
    .filter(a => (a.ownership?.default ?? 0) !== level)
    .map(a => ({ _id: a.id, "ownership.default": level }));

  if (!updates.length) {
    return ui.notifications.info("Every structure already has that access.");
  }
  await Actor.updateDocuments(updates);

  // Tokens already on a map carry their own copy of the actor.
  let tokens = 0;
  for (const scene of game.scenes) {
    const mine = scene.tokens.filter(t => t.actor?.type === "structure" && !t.actorLink);
    for (const t of mine) {
      await t.actor.update({ "ownership.default": level });
      tokens++;
    }
  }
  ui.notifications.info(
    `Updated ${updates.length} structure${updates.length === 1 ? "" : "s"}` +
    (tokens ? ` and ${tokens} placed token${tokens === 1 ? "" : "s"}` : "") + ".");
}


/**
 * Right-click a scene in the sidebar to name it as the colony.
 *
 * A scene is picked by pointing at it, not by typing its id into a
 * settings field, so the designation lives where the scenes are.
 */
export function registerColonySceneMenu() {
  const entry = {
    name: "Set as the colony",
    icon: '<i class="fas fa-house-chimney"></i>',
    condition: (li) => {
      if (!game.user.isGM) return false;
      const id = li?.dataset?.entryId ?? li?.dataset?.documentId
        ?? li?.[0]?.dataset?.entryId;
      return !!id && game.settings.get("zed00", "colonyScene") !== id;
    },
    callback: (li) => {
      const id = li?.dataset?.entryId ?? li?.dataset?.documentId
        ?? li?.[0]?.dataset?.entryId;
      const scene = game.scenes.get(id);
      if (scene) setColonyScene(scene);
    }
  };

  // The hook is named differently across v12 and v13, so both are wired
  // and whichever exists fires.
  for (const hook of ["getSceneContextOptions", "getSceneDirectoryEntryContext"]) {
    Hooks.on(hook, (_app, options) => {
      if (Array.isArray(options) && !options.some(o => o.name === entry.name)) {
        options.push(entry);
      }
    });
  }
}
