import * as ActorData from "./data/actor.mjs";
import * as ItemData from "./data/item.mjs";
import { registerSettings, cfg } from "./settings.mjs";
import * as Dice from "./dice.mjs";
import { Zed00ActorSheet } from "./sheets/actor-sheet.mjs";
import { Zed00CreatureSheet } from "./sheets/creature-sheet.mjs";
import { registerPackHooks, populatePacks } from "./packs.mjs";
import { Zed00ItemSheet } from "./sheets/item-sheet.mjs";

export const ZED00 = {
  attributes: {
    str: "ZED00.Attr.Str", dex: "ZED00.Attr.Dex", con: "ZED00.Attr.Con",
    int: "ZED00.Attr.Int", wis: "ZED00.Attr.Wis", cha: "ZED00.Attr.Cha"
  },
  saves: { physical: "ZED00.Save.Physical", mental: "ZED00.Save.Mental", evasion: "ZED00.Save.Evasion" },
  skills: [
    "administer", "connect", "exert", "fix", "heal", "know", "lead", "notice",
    "perform", "pilot", "program", "punch", "shoot", "sneak", "stab",
    "survive", "talk", "trade", "work"
  ],
  talkingSkills: ["talk", "lead", "administer", "connect", "trade"],
  hazards: ["temperature", "airQuality", "precipitation", "shelter", "withdrawal", "starvation"],
  benches: ["none", "forge", "hand-tailor", "machining", "fabrication"],
  conditions: ["pristine", "damaged", "broken", "destroyed"],
  medicine: ["none", "herbal", "industrial", "glitterworld"]
};

/* ------------------------------------------------------------------ */
/*  Documents                                                          */
/* ------------------------------------------------------------------ */

class Zed00Actor extends Actor {
  /** Roll a skill check. 2d6 + skill + attribute vs a TN. */
  async rollSkill(skillName, options = {}) {
    const skill = this.items.find(i => i.type === "skill" && i.name.toLowerCase() === skillName.toLowerCase());
    const isTalking = ZED00.talkingSkills.includes(skillName.toLowerCase());
    return Dice.rollSkill(this, {
      skill,
      attribute: options.attribute ?? skill?.system?.attribute ?? "int",
      label: skill?.name ?? skillName,
      // Talking skills are the only ones the dark doesn't touch.
      ...options,
      darkness: isTalking ? false : options.darkness
    });
  }

  async rollSave(type, options = {}) { return Dice.rollSave(this, type, options); }

  async applyDamage(amount, options = {}) { return Dice.takeDamage(this, amount, options); }

  async push() { return Dice.push(this); }

  /** A week of rest. Natural healing is your level in hit points. */
  async restWeek({ bed = "basic", recreational = false } = {}) {
    const sys = this.system;
    const updates = {};

    updates["system.health.value"] = Math.min(sys.health.max, sys.health.value + sys.level);

    // Strain recovery does not happen at Exposure 2 or above.
    if (sys.exposure.level < 2) {
      const clear = recreational ? 0 : (bed === "private" ? 2 : bed === "basic" ? 1 : 0);
      updates["system.strain.value"] = Math.max(0, sys.strain.value - clear);
    }

    // All hazards at zero recovers one level of Exposure.
    if (sys.exposure.worstHazard === 0 && sys.exposure.level > 0) {
      updates["system.exposure.level"] = sys.exposure.level - 1;
    } else if (sys.exposure.worstHazard > 0) {
      const ceiling = sys.exposure.ceiling;
      if (sys.exposure.level < ceiling) {
        updates["system.exposure.level"] = Math.min(ceiling, sys.exposure.level + sys.exposure.worstHazard);
      }
    }

    await this.update(updates);
  }
}

class Zed00Item extends Item {
  /** Gear degrades one step. Destroyed has no repair path at any price. */
  async degrade() {
    const order = ZED00.conditions;
    const i = order.indexOf(this.system.condition ?? "pristine");
    if (i < 0 || i >= order.length - 1) return;
    await this.update({ "system.condition": order[i + 1] });
    ChatMessage.create({ content: `<strong>${this.name}</strong> is now ${order[i + 1]}.` });
  }

  /** Roll a Durability Save. Threshold is set by the bench it was made at. */
  async durabilitySave() {
    const target = this.system.durability ?? 5;
    const roll = await new Roll("1d6").evaluate();
    const survived = roll.total >= target;
    await roll.toMessage({
      flavor: `<strong>${this.name}</strong> — Durability Save, needs ${target}+ — <em>${survived ? "holds" : "fails"}</em>`
    });
    if (!survived) await this.degrade();
    return survived;
  }
}

/* ------------------------------------------------------------------ */
/*  Init                                                               */
/* ------------------------------------------------------------------ */

Hooks.once("init", () => {
  console.log("Zed-00 | Initialising");

  game.zed00 = { Dice, cfg, ZED00, rollItemMacro, populatePacks };
  CONFIG.ZED00 = ZED00;
  CONFIG.Actor.documentClass = Zed00Actor;
  CONFIG.Item.documentClass = Zed00Item;

  CONFIG.Actor.dataModels = {
    character: ActorData.Zed00Character,
    colonist:  ActorData.Zed00Colonist,
    creature:  ActorData.Zed00Creature
  };
  CONFIG.Item.dataModels = {
    weapon:       ItemData.Zed00Weapon,
    armor:        ItemData.Zed00Armor,
    modification: ItemData.Zed00Modification,
    gear:         ItemData.Zed00Gear,
    drug:         ItemData.Zed00Drug,
    cyberware:    ItemData.Zed00Cyberware,
    power:        ItemData.Zed00Power,
    focus:        ItemData.Zed00Focus,
    xenotype:     ItemData.Zed00Xenotype,
    skill:        ItemData.Zed00Skill
  };

  // Initiative is 1d8 + Dex modifier, rolled once at the top of a fight.
  CONFIG.Combat.initiative = { formula: "1d8 + @attributes.dex.mod", decimals: 0 };

  registerSettings();
  registerPackHooks();

  foundry.documents.collections.Actors.unregisterSheet("core", foundry.appv1.sheets.ActorSheet);
  foundry.documents.collections.Actors.registerSheet("zed00", Zed00ActorSheet,
    { types: ["character", "colonist"], makeDefault: true });
  foundry.documents.collections.Actors.registerSheet("zed00", Zed00CreatureSheet,
    { types: ["creature"], makeDefault: true });
  foundry.documents.collections.Items.unregisterSheet("core", foundry.appv1.sheets.ItemSheet);
  foundry.documents.collections.Items.registerSheet("zed00", Zed00ItemSheet, { makeDefault: true });

  registerHandlebarsHelpers();
});

function registerHandlebarsHelpers() {
  Handlebars.registerHelper("signed", v => (v >= 0 ? `+${v}` : `${v}`));
  Handlebars.registerHelper("pct", (v, max) => (max ? Math.round((v / max) * 100) : 0));
  Handlebars.registerHelper("capitalise", s => String(s ?? "").replace(/^\w/, c => c.toUpperCase()));
  Handlebars.registerHelper("eq", (a, b) => a === b);
  Handlebars.registerHelper("gte", (a, b) => a >= b);
  Handlebars.registerHelper("times", (n, block) => {
    let out = "";
    for (let i = 0; i < n; i++) out += block.fn(i);
    return out;
  });
}

/* ------------------------------------------------------------------ */

async function rollItemMacro(itemUuid) {
  const item = await fromUuid(itemUuid);
  if (!item) return ui.notifications.warn("That item no longer exists.");
  const actor = item.parent;
  if (!actor) return ui.notifications.warn("That item is not owned by anyone.");
  if (item.type === "weapon") {
    const skill = actor.items.find(i => i.type === "skill" &&
      ["punch", "stab", "shoot"].includes(i.name.toLowerCase()));
    return Dice.rollAttack(actor, item, { skill });
  }
  return item.sheet.render(true);
}

Hooks.once("ready", () => {
  Hooks.on("hotbarDrop", (bar, data, slot) => {
    if (data.type !== "Item") return;
    const command = `game.zed00.rollItemMacro("${data.uuid}");`;
    Macro.create({ name: data.name ?? "Item", type: "script", command, img: data.img })
      .then(m => game.user.assignHotbarMacro(m, slot));
    return false;
  });
});
