/**
 * The upkeep tally.
 *
 * Reads what is standing on the map and says what it costs to keep
 * standing: Power against Capacity, and how many weeks of Wood and Fuel
 * are left in the stores at the current burn.
 *
 * It stores nothing. Every number is derived from the structures, so
 * building a generator changes the tally without anybody typing anything,
 * and a structure that is broken or switched off stops counting the
 * moment it stops working. That was the whole point of putting colony
 * buildings on the map as actors.
 */

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

import { placedStructures as structures, colonyScene, unplacedStructures as unplaced }
  from "./structures.mjs";

/** Everything in every stockpile on the map, totalled by name. */
function stores(all = null) {
  const total = new Map();
  for (const pile of all ?? structures()) {
    if (pile.system.function !== "stockpile") continue;
    for (const good of pile.items) {
      const n = good.name.trim();
      total.set(n, (total.get(n) ?? 0) + (Number(good.system.quantity) || 0));
    }
  }
  return total;
}

/**
 * What a weather-dependent generator makes this week.
 *
 * Wind is rated 10–20 variable in the book, so a windy week runs it at
 * the ceiling and a still one at nothing. Solar either works or it does
 * not.
 */
function weatherOutput(sys, weather) {
  if (!sys.power.weatherDependent) return sys.power.output;
  const solarOff = weather?.solar === false;
  const isWind = sys.power.output <= 10;      // the turbine's floor
  if (isWind) {
    if (weather?.wind === true) return sys.power.output * 2;
    if (weather?.wind === false) return 0;
    return sys.power.output;
  }
  return solarOff ? 0 : sys.power.output;
}

/**
 * Add up the colony.
 *
 * `weather` is optional: pass this week's weather and the tally shows
 * what the grid does under it as well as on a fair week, which is the
 * difference between "we have enough" and "we have enough today".
 */
export function tally(weather = null) {
  const all = structures();
  const produced = [], batteries = [], drawing = [], burning = [], idle = [];

  let output = 0, capacity = 0, draw = 0, fairOutput = 0;

  for (const a of all) {
    const sys = a.system;
    const working = sys.working;

    if (sys.power.output > 0) {
      const now = working ? weatherOutput(sys, weather) : 0;
      const fair = working ? sys.power.output : 0;
      output += now;
      fairOutput += fair;
      produced.push({ name: a.name, now, fair, working,
                      weather: sys.power.weatherDependent });
    }
    if (sys.power.capacity > 0) {
      capacity += working ? sys.power.capacity : 0;
      batteries.push({
        name: a.name, adds: sys.power.capacity, working,
        stored: sys.charge, percent: sys.chargePercent
      });
    }
    if (sys.power.draw > 0) {
      draw += working ? sys.power.draw : 0;
      if (working) drawing.push({ name: a.name, draw: sys.power.draw });
      else idle.push({ name: a.name, draw: sys.power.draw,
                       why: sys.condition !== "pristine" && sys.condition !== "damaged"
                         ? sys.condition : "switched off" });
    }
    if (sys.upkeep.amount > 0 && sys.upkeep.material) {
      if (working) {
        burning.push({ name: a.name, amount: sys.upkeep.amount,
                       material: sys.upkeep.material });
      }
    }
  }

  // Fuel and wood, by material, against what is in the sheds.
  const held = stores(all);
  const fuels = new Map();
  for (const b of burning) {
    const key = b.material;
    const f = fuels.get(key) ?? { material: key, perWeek: 0, users: [] };
    f.perWeek += b.amount;
    f.users.push(b);
    fuels.set(key, f);
  }
  for (const f of fuels.values()) {
    // Stock may be filed under a slightly different name — "Fuel" against
    // "Chemfuel" is near enough. Exact match wins; otherwise anything
    // that contains the name, or is contained by it, counts. Whatever it
    // matched is reported, because "you have no wood" with no reason is
    // how this went wrong in the first place.
    const want = f.material.trim().toLowerCase();
    let have = 0;
    const matched = [];
    for (const [name, qty] of held) {
      if (name.trim().toLowerCase() === want) { have += qty; matched.push(name); }
    }
    if (!matched.length) {
      for (const [name, qty] of held) {
        const got = name.trim().toLowerCase();
        if (got.includes(want) || want.includes(got)) { have += qty; matched.push(name); }
      }
    }
    f.have = have;
    f.matched = matched;
    f.weeksLeft = f.perWeek > 0 ? Math.floor(have / f.perWeek) : Infinity;
  }

  const totalCapacity = output + capacity;
  const fairCapacity = fairOutput + capacity;

  // The optional storage rule. Off by default, because the rules say a
  // battery provides its capacity whatever the weather and say nothing
  // about charge. On, a battery is also a reservoir: a surplus fills it
  // and a shortfall empties it.
  const storing = game.settings.get("zed00", "batteryStorage") === true;
  const stored = batteries.reduce((n, b) => n + (b.working ? b.stored : 0), 0);
  const surplus = output - draw;

  return {
    produced: produced.sort((x, y) => y.now - x.now),
    batteries, drawing: drawing.sort((x, y) => y.draw - x.draw), idle,
    idleDraw: idle.reduce((n, d) => n + d.draw, 0),
    fuels: [...fuels.values()].sort((a, b) => a.weeksLeft - b.weeksLeft),
    output, capacity, draw, fairOutput,
    totalCapacity, fairCapacity,
    spare: totalCapacity - draw,
    fairSpare: fairCapacity - draw,
    over: draw > totalCapacity,
    overBy: Math.max(0, draw - totalCapacity),
    // A grid that only works on a fair week is a grid with a problem.
    fragile: draw <= fairCapacity && draw > totalCapacity,
    storing, stored, surplus,
    storeMax: batteries.reduce((n, b) => n + (b.working ? b.adds : 0), 0),
    // Under the storage rule, a shortfall is covered out of the batteries
    // until they run dry; that is how many weeks of cover is left.
    weeksOfCover: storing && surplus < 0
      ? Math.floor(stored / -surplus) : null,
    weather,
    structures: all.length,
    // Where the numbers came from, so a surprising total can be checked.
    scene: colonyScene()?.name ?? "no scene",
    piles: all.filter(a => a.system.function === "stockpile").length,

    held: [...held.entries()].sort((a, b) => b[1] - a[1])
      .map(([name, qty]) => ({ name, qty })),
    // The placed scan is cached, so this is a cheap subtraction now.
    unplaced: unplaced().length
  };
}

/**
 * Settle the batteries for the week.
 *
 * Only runs under the optional storage rule. A surplus fills the
 * batteries, a shortfall empties them, and if they empty before the
 * shortfall is covered then something went dark — which is reported
 * rather than resolved, because which thing goes dark is the colony's
 * choice and not a dice roll.
 */
export async function settleBatteries(weather = null) {
  if (!game.user.isGM) return null;
  if (game.settings.get("zed00", "batteryStorage") !== true) return null;

  const t = tally(weather);
  if (!t.batteries.length) return null;

  const live = structures().filter(a => a.system.isBattery && a.system.working);
  let change = t.surplus;
  const report = [];

  if (change > 0) {
    // Fill the emptiest first, so a new battery catches up.
    live.sort((a, b) => a.system.chargePercent - b.system.chargePercent);
    for (const b of live) {
      if (change <= 0) break;
      const room = b.system.power.capacity - b.system.charge;
      const put = Math.min(room, change);
      if (put <= 0) continue;
      await b.update({ "system.power.stored": b.system.charge + put });
      change -= put;
    }
    report.push(`Stored ${t.surplus - change} of a ${t.surplus} surplus.`);
    if (change > 0) report.push(`${change} spilled — the batteries are full.`);
  } else if (change < 0) {
    let need = -change;
    live.sort((a, b) => b.system.charge - a.system.charge);
    for (const b of live) {
      if (need <= 0) break;
      const take = Math.min(b.system.charge, need);
      if (take <= 0) continue;
      await b.update({ "system.power.stored": b.system.charge - take });
      need -= take;
    }
    const drawn = -change - need;
    if (drawn) report.push(`Drew ${drawn} out of the batteries.`);
    if (need > 0) {
      report.push(`<strong>${need} short, and nothing left to draw on.</strong> ` +
                  `Something goes without power this week — your choice which.`);
    }
  } else {
    report.push("Production matched draw exactly. Nothing moved.");
  }

  const after = tally(weather);
  ChatMessage.create({
    content: `<div class="zed00-roll"><h3>The grid</h3>` +
             `<p>${report.join(" ")}</p>` +
             `<p class="hint">Batteries hold ${after.stored} of ${after.storeMax}.</p></div>`
  });
  return after;
}

/* ------------------------------------------------------------------ */

export class Zed00UpkeepSheet extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "zed00-upkeep",
    classes: ["zed00", "sheet", "upkeep-sheet"],
    position: { width: 520, height: 680 },
    window: { title: "Colony Upkeep", icon: "fas fa-bolt", resizable: true },
    actions: { refresh: Zed00UpkeepSheet.#refresh }
  };

  static PARTS = { body: { template: "systems/zed00/templates/upkeep.hbs" } };

  /** This week's weather, so the tally can show today as well as fair. */
  weather = null;

  async _prepareContext() {
    const t = tally(this.weather);
    return {
      t,
      // Weeks of fuel is the number a GM actually acts on, so lead with it.
      worst: t.fuels.length ? t.fuels[0] : null,
      hasFuel: t.fuels.length > 0,
      isGM: game.user.isGM
    };
  }

  static async #refresh() {
    this.render();
  }

  /**
   * Keep the tally live while it is open.
   *
   * Token hooks matter as much as actor hooks here: the buildings are
   * tokens, so placing, moving between scenes or deleting one changes
   * the numbers without any actor being touched.
   */
  _onFirstRender(context, options) {
    super._onFirstRender?.(context, options);
    const redraw = foundry.utils.debounce(() => this.render(), 400);
    const mine = (doc) => doc?.type === "structure" ||
                          doc?.actor?.type === "structure" ||
                          doc?.parent?.type === "structure" ||
                          doc?.parent?.parent?.type === "structure";

    this.#watching = [
      ["updateActor", (a) => { if (mine(a)) redraw(); }],
      ["createActor", (a) => { if (mine(a)) redraw(); }],
      ["deleteActor", (a) => { if (mine(a)) redraw(); }],
      ["createToken", (t) => { if (mine(t)) redraw(); }],
      ["updateToken", (t) => { if (mine(t)) redraw(); }],
      ["deleteToken", (t) => { if (mine(t)) redraw(); }],
      ["createItem", (i) => { if (mine(i)) redraw(); }],
      ["updateItem", (i) => { if (mine(i)) redraw(); }],
      ["deleteItem", (i) => { if (mine(i)) redraw(); }],
      ["canvasReady", () => redraw()]
    ].map(([name, fn]) => [name, Hooks.on(name, fn)]);
  }

  #watching = [];

  _onClose(options) {
    super._onClose?.(options);
    for (const [name, id] of this.#watching) Hooks.off(name, id);
    this.#watching = [];
  }
}

let open;

/** Show the tally, optionally under a particular week's weather. */
export function openUpkeep(weather = null) {
  open ??= new Zed00UpkeepSheet();
  open.weather = weather;
  open.render(true);
  return open;
}
