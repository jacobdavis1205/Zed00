/**
 * Every character and colonist starts with the full skill list at -1
 * (untrained but known of). Without this the darkness rule can't tell a
 * talking skill from a labouring one, because there'd be nothing to ask.
 */

export const SKILL_LIST = [
  { name: "Administer", attribute: "int", talking: true },
  { name: "Connect",    attribute: "cha", talking: true },
  { name: "Exert",      attribute: "str" },
  { name: "Fix",        attribute: "int" },
  { name: "Heal",       attribute: "int" },
  { name: "Know",       attribute: "int" },
  { name: "Lead",       attribute: "cha", talking: true },
  { name: "Notice",     attribute: "wis" },
  { name: "Perform",    attribute: "cha" },
  { name: "Pilot",      attribute: "dex" },
  { name: "Program",    attribute: "int" },
  { name: "Punch",      attribute: "str", combat: true },
  { name: "Shoot",      attribute: "dex", combat: true },
  { name: "Sneak",      attribute: "dex" },
  { name: "Stab",       attribute: "str", combat: true },
  { name: "Survive",    attribute: "wis" },
  { name: "Talk",       attribute: "cha", talking: true },
  { name: "Trade",      attribute: "cha", talking: true },
  { name: "Work",       attribute: "int" }
];

export const TALKING = SKILL_LIST.filter(s => s.talking).map(s => s.name.toLowerCase());

/** Skill documents for a fresh character. */
export function defaultSkillItems() {
  return SKILL_LIST.map(s => ({
    name: s.name,
    type: "skill",
    img: s.combat ? "icons/svg/sword.svg" : "icons/svg/book.svg",
    system: {
      level: -1,
      attribute: s.attribute,
      combat: !!s.combat,
      description: ""
    }
  }));
}

/** Everyone has fists. Punch adds its skill level to damage, uniquely. */
export function unarmedStrike() {
  return {
    name: "Unarmed Strike",
    type: "weapon",
    img: "icons/svg/combat.svg",
    system: {
      description: "Fists, elbows, knees. Punch is the one skill that adds its level to damage. Unarmed cannot be disarmed, taken or broken — that is what it trades its reach for.",
      category: "melee", damage: "1d2", shock: { damage: 0, ac: 0 },
      range: { short: 0, long: 0 }, magazine: 0, ammo: 0, ammoPool: "",
      attribute: "str", burst: false, ballistic: false, akimbo: false,
      unarmed: true, tl4: false, twoHanded: false, reach: false,
      encumbrance: 0, quantity: 1, bench: "none",
      price: { buy: 0, sell: 0 }, stowed: false, homemade: false,
      condition: "pristine", mod: "", modUuid: ""
    }
  };
}

/** Give new characters and colonists the whole list. */
export function registerSkillHooks() {
  Hooks.on("preCreateActor", (actor, data, options, userId) => {
    if (!["character", "colonist"].includes(data.type)) return;
    if (data.items?.length) return;            // imported or duplicated — leave alone
    actor.updateSource({ items: [...defaultSkillItems(), unarmedStrike()] });
  });
}

/** Add any skills a sheet is missing, without touching the ones it has. */
export async function backfillSkills(actor) {
  const have = new Set(actor.items.filter(i => i.type === "skill")
                            .map(i => i.name.toLowerCase()));
  const missing = defaultSkillItems().filter(s => !have.has(s.name.toLowerCase()));
  const hasFists = actor.items.some(i => i.type === "weapon" && i.system.unarmed);
  if (!hasFists) missing.push(unarmedStrike());
  if (!missing.length) return ui.notifications.info(`${actor.name} already has every skill.`);
  await actor.createEmbeddedDocuments("Item", missing);
  ui.notifications.info(`Added ${missing.length} skills to ${actor.name}.`);
}
