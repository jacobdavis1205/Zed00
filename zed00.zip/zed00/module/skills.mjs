/**
 * Every character and colonist starts with the full skill list at -1
 * (untrained but known of). Without this the darkness rule can't tell a
 * talking skill from a labouring one, because there'd be nothing to ask.
 */

export const SKILL_LIST = [
  { name: "Administer", attribute: "int", talking: true },
  { name: "Connect",    attribute: "cha", talking: true },
  { name: "Exert",      attribute: "str" },
  { name: "Fix",        attribute: "int" },
  { name: "Heal",       attribute: "int" },
  { name: "Know",       attribute: "int" },
  { name: "Lead",       attribute: "cha", talking: true },
  { name: "Notice",     attribute: "wis" },
  { name: "Perform",    attribute: "cha" },
  { name: "Pilot",      attribute: "dex" },
  { name: "Program",    attribute: "int" },
  { name: "Punch",      attribute: "str", combat: true },
  { name: "Shoot",      attribute: "dex", combat: true },
  { name: "Sneak",      attribute: "dex" },
  { name: "Stab",       attribute: "str", combat: true },
  { name: "Survive",    attribute: "wis" },
  { name: "Talk",       attribute: "cha", talking: true },
  { name: "Trade",      attribute: "cha", talking: true },
  { name: "Work",       attribute: "int" }
];

export const SKILL_TEXT = {"administer": "Stretching supplies. Declare at the start of the week which one of these you're doing: - Cut the material cost of one build or craft - Cut the colony's food consumption - Cut fuel consumption for generators - Cut wood consumption for fired buildings How much you save depends on the skill. 10% at Administer-0 or 1, 20% at 2 or 3, and 30% at Administer-4. A quartermaster who really knows the stores is worth a farmer. A failure doesn't just waste the week \u2014 the thing you were managing goes badly. Rations come up short, a build wastes materials, a generator runs dry early. Cannot be multitasked.","connect": "Knowing people and knowing where things are. A successful check answers two questions about any settlement within about 100km \u2014 who buys what, who's hiring, who's feuding, what arrived last week. A failure gives you an answer that isn't true.","exert": "Mining, quarrying, logging. Heavy labor, and the numbers reflect how much of it is lying around. | Gathering | Weekly yield | |---|---| | Wood | 40 | | Stone chunks | 30 | | Metal | 20 | | Silver ore | 20\u201325, where a deposit exists |","fix": "Construction, crafting, and repair. A colonist gets through about 40 materials of work in a week \u2014 that's four walls, or one substantial item, or progress toward something bigger. Work carries over between weeks and can be split.","heal": "Every medical act in the game is the same check \u2014 2d6 + Heal + INT against a static TN, with the medicine modifier applied. | Supplies | Modifier | |---|---| | Nothing at all | -2, and the patient takes 1 Strain | | Herbal Medicine | +0 | | Industrial Medicine | +1 | | Glitterworld Medicine | +2 | | Job | TN | |---|---| | Treating Exposure | 8 | | Stabilizing an ordinary mortal wound | 8, +1 per round elapsed | | Stabilizing a Critical \u2014 Dying result | 10, +1 per round elapsed | | Treating a disease | The disease's own TN | | Fitting or removing a prosthetic | 8 | | Installing a cybernetic | 10 | | Removing a cybernetic | 14 | | Transplanting an organ | 12 | Ten minutes between fights, one unit of Medicine, and a Heal check against TN 8. On a success the patient recovers hit points: | Medicine used | Hit points restored | |---|---| | Herbal | Your level \u2014 one night's rest | | Industrial | Twice your level \u2014 two nights | | Glitterworld | Three times your level \u2014 three nights | Medicine buys you nights. A night's rest restores your level in hit points; a dose of Herbal does the same thing in ten minutes, and the better grades do it two and three times over. Once per patient per scene","know": "Research. A week of study produces 2d6 + Know + INT \u2212 4 Research Points, banked at the end of the week and spent against projects in the research tree. Tier 3 research needs an Advanced Research Station. Tier 4 needs one of those and a Multi-Analyzer, both powered \u2014 and one of each per researcher, if you want more than one working at a time. Know is also what you roll to identify something nobody in the colony has seen before. ---","lead": "Organizing everyone else. A successful Lead check gives every other colonist +1 on their check that week. A failure gives them -1 \u2014 you got in the way. Lead produces nothing itself. It's a full week spent making everyone else's week better, and with six colonists working it is almost always worth it. Cannot be multitasked.","notice": "Surveying. A successful check answers two questions about the surrounding land \u2014 where the ore is, what animals range here, what's worth salvaging, what's been through recently. Also the passive skill everything else is measured against: an ambusher's Sneak, a hidden trap, an IED nobody mentioned.","perform": "Art, and the making of it. A successful Perform check at an Art Bench produces a piece worth the check result multiplied by the material \u2014 Wood \u00d710, Textiles \u00d712, Metal \u00d715. A result of 7 or better makes it Decent, and a room containing decent art gives +1 to Mental saves. Below that it's crude: it still sells, because someone will always buy a bad painting, but nobody is moved by it. ---","pilot": "Caravans and overland travel. One check a week on the road decides how far you get. | Result | Travel | |---|---| | Critical success | 1.5\u00d7 your pace that week | | Success | Full pace | | Failure | Half pace | | Critical failure | Half pace, and the caravan is exposed \u2014 ambushes, predators, worse | ---","program": "Anything with a circuit in it. Turrets, battery banks, microprocessors, powered doors. A Program check builds and maintains what a Fix check can't understand. Also what you roll against electronic locks and hostile systems, with a Hacking Rig. ---","punch": "","shoot": "","sneak": "Preparing ground. A week spent mapping approaches, marking bottlenecks and setting traps earns a tactical token, spent during a raid: | Spend | Effect | |---|---| | Trap | A 2\u00d72 area deals 1d6 damage to raiders entering it | | Funnel | Force the attack into an 80ft cone. Two tokens narrows it to 40ft, three to 20ft | | Ambush | Two colonists choose their exact position on the initiative track, per token | How many you can hold at once depends on the skill. Sneak-0 holds one, Sneak-1 or 2 holds two, Sneak-3 holds three, and Sneak-4 holds four \u2014 a specialist can prepare a battlefield the way nobody else can. Sneak is also what you roll to hide, to move unseen, and to place an IED.","stab": "","survive": "Hunting \u2014 35 animal product and 10 Textiles. Halved without a Butcher Table. One hunter feeds more than two people. Foraging \u2014 28 plant product, or 4 Herbal Medicine. Choosing medicine gives up most of a week's food, which is why medicine is worth what it is. Agriculture \u2014 175 plant product per month, about 44 a week, and the best food in the game once it's running. It takes four weekly checks before the first harvest, and each one matters: | Each week's result | Effect on the harvest | |---|---| | Critical success | +25% | | Success | No change | | Failure | -25% | | Critical failure | -50% | The harvest caps at 150% of the listed yield, however well the month went. Two critical failures in one month lose the crop entirely \u2014 blight, rot, a hard frost. Start again. An untrained farmer brings in a thin harvest and occasionally loses the crop outright. Someone who knows the work reliably beats the listed yield and rarely loses anything. Weather can ruin a crop independently of your checks. A cold snap in the wrong week does what it does. Taming \u2014 one roll a week against the animal's TN. See Transport & Animals. ---","talk": "Prisoners, recruitment, and diplomacy. Interrogating a captive, turning one into a colonist, and speaking for the colony when a faction sends someone.","trade": "The only skill that doesn't cost a week. Trade is rolled at the moment of a deal. A success moves the price in your favour \u2014 10% normally, 20% at Trade-3, and 30% at Trade-4. A failure moves it 10% against you, and a critical failure ends the negotiation entirely. ---","work": "The assembly line. Converting what Exert brings in, and cooking what Survive brings back. | Job | Recipe | |---|---| | Stone cutting | 30 stone chunks \u2192 30 bricks | | Smelting | Melt gear down for 20% of its metal back | | Vacuum Sealing | 1 raw food + 1 Fuel \u2192 1 Preserved Food | A cook processes 56 raw food a week, whatever they're making. The tier decides how many meals that becomes. | Making | Recipe | One cook's week | |---|---|---| | Simple Meals | 2 raw food \u2192 1 | 28 meals | | Preserved Food | 1 raw plant + 1 raw animal \u2192 1 | 28 rations | | Fine Meals | 4 raw food \u2192 1 | 14 meals | | Lavish Meals | 8 raw food \u2192 1 | 7 meals | The colony eats at one quality for the week \u2014 whatever the cooks actually served everyone. There's no stacking and no picking: you ate what there was. | The colony ate | That week | |---|---| | Raw food | +1 Strain | | Simple Meals | Nothing. This is the baseline | | Fine Meals | +1 Strain recovered | | Lavish Meals | +1 Strain recovered, and +1 to every check | Everyone must eat a full week of that tier for it to count. Two lavish meals and five simple ones is a week of simple meals with a nice Tuesday. Lavish food cannot be a lifestyle, and the numbers w"};

export const TALKING = SKILL_LIST.filter(s => s.talking).map(s => s.name.toLowerCase());

/** Skill documents for a fresh character. */
export function defaultSkillItems() {
  return SKILL_LIST.map(s => ({
    name: s.name,
    type: "skill",
    img: s.combat ? "icons/svg/sword.svg" : "icons/svg/book.svg",
    system: {
      level: -1,
      attribute: s.attribute,
      combat: !!s.combat,
      misc: 0,
      description: SKILL_TEXT[s.name.toLowerCase()] ?? ""
    }
  }));
}

/** Everyone has fists. Punch adds its skill level to damage, uniquely. */
export function unarmedStrike() {
  return {
    name: "Unarmed Strike",
    type: "weapon",
    img: "icons/svg/combat.svg",
    system: {
      description: "Fists, elbows, knees. Punch is the one skill that adds its level to damage. Unarmed cannot be disarmed, taken or broken — that is what it trades its reach for.",
      category: "melee", damage: "1d2", shock: { damage: 0, ac: 0 },
      range: { short: 0, long: 0 }, magazine: 0, ammo: 0, ammoPool: "",
      attribute: "str", burst: false, ballistic: false, akimbo: false,
      unarmed: true, tl4: false, twoHanded: false, reach: false,
      encumbrance: 0, quantity: 1, bench: "none",
      price: { buy: 0, sell: 0 }, stowed: false, homemade: false,
      condition: "pristine", mod: "", modUuid: ""
    }
  };
}

/** Give new characters and colonists the whole list. */
export function registerSkillHooks() {
  Hooks.on("preCreateActor", (actor, data, options, userId) => {
    if (!["character", "colonist"].includes(data.type)) return;
    if (data.items?.length) return;            // imported or duplicated — leave alone
    actor.updateSource({ items: [...defaultSkillItems(), unarmedStrike()] });
  });
}

/** Add any skills a sheet is missing, without touching the ones it has. */
export async function backfillSkills(actor) {
  const have = new Set(actor.items.filter(i => i.type === "skill")
                            .map(i => i.name.toLowerCase()));
  const missing = defaultSkillItems().filter(s => !have.has(s.name.toLowerCase()));
  const hasFists = actor.items.some(i => i.type === "weapon" && i.system.unarmed);
  if (!hasFists) missing.push(unarmedStrike());
  if (!missing.length) return ui.notifications.info(`${actor.name} already has every skill.`);
  await actor.createEmbeddedDocuments("Item", missing);
  ui.notifications.info(`Added ${missing.length} skills to ${actor.name}.`);
}
