/**
 * Temporary pools: the Strain buffer, and temporary hit points.
 *
 * A Recreation Room grants "a temporary Strain buffer — functions like
 * temporary hit points against Strain". So Strain lands on the buffer
 * first and only reaches the real pool once the buffer is gone. Drugs
 * work the same way.
 *
 * Temporary hit points have no rules yet, but they are the same shape
 * and something will want them, so the plumbing is here and unused
 * rather than retrofitted later.
 */

/**
 * Put Strain on an actor, through the buffer.
 *
 * @param {Actor} actor
 * @param {number} amount  positive adds Strain, negative clears it
 * @returns {object} what happened, for reporting
 */
export async function applyStrain(actor, amount) {
  const sys = actor.system;
  const buffer = Number(sys.strain?.buffer) || 0;
  const value = Number(sys.strain?.value) || 0;
  const max = Number(sys.strain?.max) || 0;

  if (!amount) return { absorbed: 0, applied: 0, buffer, value };

  // Clearing Strain never touches the buffer — it is not a pool you heal
  // into, it is a shield that gets used up.
  if (amount < 0) {
    const next = Math.max(0, value + amount);
    await actor.update({ "system.strain.value": next });
    return { absorbed: 0, applied: next - value, buffer, value: next };
  }

  const absorbed = Math.min(buffer, amount);
  const through = amount - absorbed;
  const next = Math.min(max, value + through);

  await actor.update({
    "system.strain.buffer": buffer - absorbed,
    "system.strain.value": next
  });
  return { absorbed, applied: next - value, buffer: buffer - absorbed, value: next };
}

/** A sentence for chat, or an empty string when there is nothing to say. */
export function strainNote(result, name) {
  if (!result) return "";
  const bits = [];
  if (result.absorbed) {
    bits.push(`${result.absorbed} absorbed by the buffer` +
              (result.buffer ? ` (${result.buffer} left)` : ", now spent"));
  }
  if (result.applied > 0) bits.push(`${result.applied} Strain`);
  if (!bits.length) return "";
  return `${name ? name + ": " : ""}${bits.join(", ")}.`;
}

/**
 * Damage, through temporary hit points.
 *
 * Nothing in the rules grants these yet. The helper exists so that
 * whatever eventually does — a drug, a shield belt, a psychic ward —
 * has somewhere to put them.
 */
export async function applyTempDamage(actor, amount) {
  const sys = actor.system;
  const temp = Number(sys.health?.temp) || 0;
  if (amount <= 0 || !temp) return { absorbed: 0, remaining: amount };
  const absorbed = Math.min(temp, amount);
  await actor.update({ "system.health.temp": temp - absorbed });
  return { absorbed, remaining: amount - absorbed };
}

/* ------------------------------------------------------------------ */
/*  The colony's rec room                                              */
/* ------------------------------------------------------------------ */

/**
 * What each tier of rec room rolls.
 *
 * Straight off the Recreation table. "sparse" is the module's ruling for
 * a colony with only a Horseshoe Pin, which the rules call out as a
 * "standalone buffer only" that does not count toward a room's tier.
 */
export const REC_DICE = {
  none:   { label: "No rec room",                    formula: "" },
  sparse: { label: "A Horseshoe Pin and nothing else", formula: "1d2" },
  low:    { label: "Low-Quality Rec Room",           formula: "1d2+1" },
  medium: { label: "Medium-Quality Rec Room",        formula: "1d4+1" },
  high:   { label: "High-Quality Rec Room",          formula: "1d6+1" }
};

export function registerPoolSettings() {
  game.settings.register("zed00", "recRoom", {
    name: "The colony's rec room",
    hint: "A fully enclosed room up to 5x5 with at least two working pieces of recreational furniture. This sets the Strain buffer everyone rolls. A lone Horseshoe Pin is a standalone buffer and does not make a room.",
    scope: "world", config: true, type: String, default: "none",
    choices: Object.fromEntries(
      Object.entries(REC_DICE).map(([k, v]) => [k, v.label]))
  });

  game.settings.register("zed00", "bufferEvery", {
    name: "Weeks between Strain buffers",
    hint: "How often the rec room grants its buffer. Four is a month. The rules do not say, so this is the module's.",
    scope: "world", config: true, type: Number, default: 4,
    range: { min: 1, max: 13, step: 1 }
  });

  game.settings.register("zed00", "lastBufferWeek", {
    scope: "world", config: false, type: Number, default: 0
  });
}

export function recRoom() {
  const key = game.settings.get("zed00", "recRoom") ?? "none";
  return { key, ...(REC_DICE[key] ?? REC_DICE.none) };
}

/**
 * Roll everyone's buffer for the period.
 *
 * The buffer does not stack with itself — a new one replaces whatever is
 * left, which keeps a colony from banking four months of rec room and
 * walking into a raid immune to Strain.
 */
export async function grantBuffers(actors, { force = false } = {}) {
  if (!game.user.isGM) return null;
  const room = recRoom();
  if (!room.formula) return null;

  const rolled = [];
  for (const actor of actors) {
    const roll = await new Roll(room.formula).evaluate();
    const had = Number(actor.system.strain?.buffer) || 0;
    await actor.update({ "system.strain.buffer": roll.total });
    rolled.push({ name: actor.name, got: roll.total, had });
  }
  if (!rolled.length) return null;

  ChatMessage.create({
    content: `<div class="zed00-roll"><h3>${room.label}</h3>` +
      `<p>Strain buffer, ${room.formula} each:</p><ul>` +
      rolled.map(r => `<li><strong>${r.name}</strong> — ${r.got}` +
        (r.had ? ` <span class="hint">(replacing ${r.had})</span>` : "") + `</li>`).join("") +
      `</ul><p class="hint">A buffer takes Strain before the real pool does, ` +
      `and a new one replaces what was left rather than adding to it.</p></div>`
  });
  return rolled;
}

/**
 * Is a buffer due this week?
 *
 * Every fourth week — the month we settled on, not every week. The clock
 * is the week one was last handed out, so a colony that skips three
 * weeks of management does not then owe three buffers; it owes the one
 * it is due.
 */
export function bufferDue(week) {
  const every = game.settings.get("zed00", "bufferEvery") ?? 4;
  return weeksUntilBuffer(week) === 0;
}

/**
 * How many weeks until the next one. Zero means this week.
 *
 * The clock is the week a buffer was last handed out, which breaks if
 * the calendar is wound backwards: rewind five weeks and `lastBufferWeek`
 * is still in the future, so the sheet reports a wait longer than the
 * period itself — "next buffer in 9 weeks" when the period is four. A
 * stamp in the future is a stamp from a timeline that no longer
 * happened, so it is treated as never having been granted.
 */
export function weeksUntilBuffer(week) {
  const every = game.settings.get("zed00", "bufferEvery") ?? 4;
  let last = game.settings.get("zed00", "lastBufferWeek") ?? 0;
  if (last > week) last = 0;
  return Math.max(0, Math.min(every, every - (week - last)));
}

/**
 * A line for the week summary, so the cadence is visible on the card
 * rather than something to be remembered or guessed at.
 */
export function bufferSchedule(week) {
  const room = recRoom();
  if (!room.formula) return "No rec room — nobody is getting a Strain buffer.";
  const every = game.settings.get("zed00", "bufferEvery") ?? 4;
  const left = weeksUntilBuffer(week);
  if (left === 0) return `${room.label} — buffers rolled this week, ${room.formula} each.`;
  return `${room.label} — next buffer in ${left} week${left === 1 ? "" : "s"}, ` +
         `then every ${every}.`;
}

export async function markBufferGranted(week) {
  return game.settings.set("zed00", "lastBufferWeek", week);
}
