const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
import { cfg } from "../settings.mjs";

export class Zed00ActorSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "actor"],
    position: { width: 760, height: 820 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      changeTab:     Zed00ActorSheet.#changeTab,
      editImage:     Zed00ActorSheet.#editImage,
      rollInitiative: Zed00ActorSheet.#rollInitiative,
      rollSkill:     Zed00ActorSheet.#rollSkill,
      rollSave:      Zed00ActorSheet.#rollSave,
      rollAttack:    Zed00ActorSheet.#rollAttack,
      push:          Zed00ActorSheet.#push,
      endScene:      Zed00ActorSheet.#endScene,
      restWeek:      Zed00ActorSheet.#restWeek,
      adjustStrain:  Zed00ActorSheet.#adjustStrain,
      editItem:      Zed00ActorSheet.#editItem,
      deleteItem:    Zed00ActorSheet.#deleteItem,
      createItem:    Zed00ActorSheet.#createItem,
      toggleEquip:   Zed00ActorSheet.#toggleEquip,
      postItem:      Zed00ActorSheet.#postItem,
      castPower:     Zed00ActorSheet.#castPower,
      backfillSkills: Zed00ActorSheet.#backfillSkills,
      levelUp:       Zed00ActorSheet.#levelUp,
      buySkill:      Zed00ActorSheet.#buySkill,
      buyAttribute:  Zed00ActorSheet.#buyAttribute,
      removeXenotype: Zed00ActorSheet.#removeXenotype,
      addInjury:     Zed00ActorSheet.#addInjury,
      removeInjury:  Zed00ActorSheet.#removeInjury,
      addDisease:    Zed00ActorSheet.#addDisease,
      removeDisease: Zed00ActorSheet.#removeDisease,
      treatDisease:  Zed00ActorSheet.#treatDisease
    }
  };

  static PARTS = {
    header:    { template: "systems/zed00/templates/actor/header.hbs" },
    tabs:      { template: "systems/zed00/templates/actor/tabs.hbs" },
    main:      { template: "systems/zed00/templates/actor/main.hbs" },
    condition: { template: "systems/zed00/templates/actor/condition.hbs" },
    gear:      { template: "systems/zed00/templates/actor/gear.hbs" },
    psionics:  { template: "systems/zed00/templates/actor/psionics.hbs" },
    injury:    { template: "systems/zed00/templates/actor/injury.hbs" },
    bio:       { template: "systems/zed00/templates/actor/bio.hbs" }
  };

  static TAB_LIST = [
    { id: "main",      label: "ZED00.Tab.Main" },
    { id: "condition", label: "ZED00.Tab.Condition" },
    { id: "gear",      label: "ZED00.Tab.Gear" },
    { id: "psionics",  label: "ZED00.Tab.Psionics" },
    { id: "injury",    label: "ZED00.Tab.Injury" },
    { id: "bio",       label: "ZED00.Tab.Bio" }
  ];

  /** Which tab is showing. Survives re-render. */
  tabGroups = { primary: "main" };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const actor = this.document;
    const sys = actor.system;

    ctx.actor = actor;
    ctx.system = sys;
    ctx.config = CONFIG.ZED00;
    ctx.editable = this.isEditable;
    ctx.isColonist = actor.type === "colonist";

    // Sort the owned items into buckets the templates can iterate.
    ctx.items = {
      weapons:   actor.items.filter(i => i.type === "weapon"),
      armor:     actor.items.filter(i => i.type === "armor"),
      gear:      actor.items.filter(i => i.type === "gear"),
      drugs:     actor.items.filter(i => i.type === "drug"),
      cyberware: actor.items.filter(i => i.type === "cyberware"),
      powers:    actor.items.filter(i => i.type === "power"),
      foci:      actor.items.filter(i => i.type === "focus"),
      skills:    actor.items.filter(i => i.type === "skill")
                      .sort((a, b) => a.name.localeCompare(b.name)),
      xenotype:  actor.items.find(i => i.type === "xenotype") ?? null
    };

    // Encumbrance actually carried, against what the character can manage.
    const carried = actor.items.filter(i => i.system?.encumbrance !== undefined);
    ctx.encumbrance = {
      readied: carried.filter(i => !i.system.stowed)
                      .reduce((n, i) => n + (i.system.encumbrance * (i.system.quantity ?? 1)), 0),
      stowed:  carried.filter(i => i.system.stowed)
                      .reduce((n, i) => n + (i.system.encumbrance * (i.system.quantity ?? 1)), 0),
      readiedMax: sys.encumbrance.readiedMax,
      stowedMax:  sys.encumbrance.stowedMax
    };
    ctx.encumbrance.overReadied = ctx.encumbrance.readied > ctx.encumbrance.readiedMax;
    ctx.encumbrance.overStowed  = ctx.encumbrance.stowed  > ctx.encumbrance.stowedMax;

    // The Strain track renders as pips so the pool reads at a glance.
    ctx.strainPips = Array.from({ length: sys.strain.max }, (_, i) => ({
      filled: i < sys.strain.value,
      past:   i >= sys.strain.unstableAt
    }));

    ctx.exposureLadder = [0, 1, 2, 3, 4, 5].map(n => ({
      level: n,
      current: n === sys.exposure.level,
      reachable: n <= (sys.exposure.ceiling || 0)
    }));

    ctx.ammoPools = [
      { key: "arrows",     name: "Arrows",      feeds: "Short, Recurve, Great bow" },
      { key: "pistol",     name: "Pistol",      feeds: "Revolver, Autopistol" },
      { key: "shotgun",    name: "Shotgun",     feeds: "Pump, Chain shotgun" },
      { key: "smg",        name: "SMG",         feeds: "Machine pistol, Heavy SMG" },
      { key: "rifle",      name: "Rifle",       feeds: "Bolt-action, Assault rifle, LMG, Minigun" },
      { key: "charged",    name: "Charged",     feeds: "Charge rifle, Charge lance, Beam repeater" },
      { key: "grenade",    name: "Grenades",    feeds: "Frag, EMP, Smoke, Molotov" },
      { key: "incendiary", name: "Incendiary",  feeds: "Incendiary launcher" },
      { key: "mortar",     name: "Mortar",      feeds: "Mortar shells" }
    ].map(p => ({ ...p, count: sys.ammo?.[p.key] ?? 0 }));

    ctx.autoPenalties = cfg.autoPenalties;
    ctx.canPush = !ctx.isColonist && sys.nextPushCost !== null;

    // Build the tab list ourselves so the active flag is always right.
    const active = this.tabGroups.primary ?? "main";
    ctx.tabs = this.constructor.TAB_LIST.map(t => ({ ...t, active: t.id === active }));
    ctx.activeTab = active;

    return ctx;
  }

  _preparePartContext(partId, ctx) {
    const active = this.tabGroups.primary ?? "main";
    if (this.constructor.TAB_LIST.some(t => t.id === partId)) {
      ctx.tab = { id: partId, active: partId === active };
    }
    return ctx;
  }

  /** Make sure exactly one body is visible after every render. */
  _onRender(context, options) {
    super._onRender?.(context, options);
    const active = this.tabGroups.primary ?? "main";
    for (const el of this.element.querySelectorAll(".tab-body[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === active);
    }
    for (const el of this.element.querySelectorAll(".tab-link[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === active);
    }
  }

  /* ------------------------------------------------------- actions */

  static #changeTab(event, target) {
    const tab = target.dataset.tab;
    if (!tab) return;
    this.tabGroups.primary = tab;
    for (const el of this.element.querySelectorAll(".tab-body[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === tab);
    }
    for (const el of this.element.querySelectorAll(".tab-link[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === tab);
    }
  }

  static async #editImage(event, target) {
    const current = this.document.img;
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image",
      current,
      callback: path => this.document.update({ img: path }),
      top: this.position.top + 40,
      left: this.position.left + 10
    });
    return fp.browse();
  }

  static async #rollInitiative() {
    const combat = game.combat;
    if (!combat) {
      // No encounter running — just roll it openly so the GM can note it.
      const r = await new Roll("1d8 + @mod",
        { mod: this.document.system.attributes.dex.mod }).evaluate();
      return r.toMessage({
        speaker: ChatMessage.getSpeaker({ actor: this.document }),
        flavor: "<strong>Initiative</strong>"
      });
    }
    const existing = combat.getCombatantsByActor(this.document.id);
    if (!existing.length) {
      const token = this.document.getActiveTokens()[0];
      if (!token) return ui.notifications.warn("Place a token on the scene first.");
      await combat.createEmbeddedDocuments("Combatant",
        [{ tokenId: token.id, actorId: this.document.id, sceneId: canvas.scene.id }]);
    }
    const ids = combat.getCombatantsByActor(this.document.id).map(c => c.id);
    return combat.rollInitiative(ids);
  }

  static async #rollSkill(event, target) {
    const name = target.dataset.skill;
    // The TN dropdown next to the skill list sets the target for the roll.
    const sel = this.element.querySelector(".tn-select");
    const tn = Number(sel?.value ?? target.dataset.tn ?? 8);
    await this.document.rollSkill(name, { tn, darkness: this.document.system.conditions.darkness });
  }

  static async #rollSave(event, target) {
    await this.document.rollSave(target.dataset.save);
  }

  static async #rollAttack(event, target) {
    const item = this.document.items.get(target.dataset.itemId);
    if (!item) return;
    const burst = target.dataset.burst === "1";
    const akimbo = target.dataset.akimbo === "1";
    const skill = this.document.items.find(i => i.type === "skill" &&
      i.name.toLowerCase() === (item.system.category === "melee" ? "stab" : "shoot"));
    await game.zed00.Dice.rollAttack(this.document, item, { skill, burst, akimbo });
  }

  static async #push() { await this.document.push(); }

  static async #endScene() {
    await game.zed00.Dice.endScene(this.document);
    ui.notifications.info("Scene ended. Pushes reset.");
  }

  static async #restWeek() {
    const sel = this.element.querySelector(".rest-quality");
    await this.document.restWeek({ bed: sel?.value ?? "basic" });
  }

  static async #adjustStrain(event, target) {
    const delta = Number(target.dataset.delta);
    const sys = this.document.system;
    await this.document.update({
      "system.strain.value": Math.clamp(sys.strain.value + delta, 0, sys.strain.max)
    });
  }

  static async #editItem(event, target) {
    this.document.items.get(target.closest("[data-item-id]").dataset.itemId)?.sheet.render(true);
  }

  static async #deleteItem(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Delete Item" },
      content: `<p>Delete <strong>${item.name}</strong>?</p>`
    });
    if (ok) await item.delete();
  }

  static async #createItem(event, target) {
    const type = target.dataset.type;
    await this.document.createEmbeddedDocuments("Item", [{
      name: `New ${type}`, type
    }]);
  }

  static async #postItem(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (item) await game.zed00.Dice.postItem(this.document, item);
  }

  static async #castPower(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (item) await game.zed00.Dice.castPower(this.document, item);
  }

  static async #backfillSkills() { await game.zed00.backfillSkills(this.document); }

  /** Spend the XP and take the level, if the table allows it. */
  static async #levelUp() {
    const sys = this.document.system;
    if (!sys.canLevel) {
      return ui.notifications.warn(
        `${this.document.name} needs ${sys.xpForNext} XP and has ${sys.xp}.`);
    }
    const newLevel = sys.level + 1;
    const gainsGrowth = [2, 4, 6, 8, 10].includes(newLevel);
    // Past ten, a level is one skill point and nothing else.
    const points = newLevel > 10 ? 1 : 3;
    await this.document.update({
      "system.level": newLevel,
      "system.skillPoints": sys.skillPoints + points
    });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${this.document.name} reaches level ${sys.level + 1}.</strong>` +
        `<br>${points} skill point${points === 1 ? "" : "s"}.` +
        (gainsGrowth ? `<br>An attribute point to spend.` : "") +
        (newLevel > 10 ? `<br><em>Past ten: a skill point and nothing else.</em>` : "")
    });
  }

  /** Spend banked points to raise a skill. Cost is the new level, min 1. */
  static async #buySkill(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    const lvl = item.system.level;
    if (lvl >= 4) return ui.notifications.info(`${item.name} is already at 4.`);
    const cap = this.document.system.maxSkillLevel;
    if (lvl + 1 > cap) {
      return ui.notifications.warn(
        `${item.name} cannot go past ${cap} until a higher level. Level 3 allows 2, level 6 allows 3, level 9 allows 4.`);
    }
    const cost = Math.max(1, lvl + 2);          // -1 to 0 costs 1, 0 to 1 costs 2 ...
    const bank = this.document.system.skillPoints;
    if (bank < cost) {
      return ui.notifications.warn(`${item.name} to ${lvl + 1} costs ${cost}. There are ${bank} banked.`);
    }
    await item.update({ "system.level": lvl + 1 });
    await this.document.update({ "system.skillPoints": bank - cost });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${item.name}</strong> raised to ${lvl + 1}. ${cost} skill point${cost === 1 ? "" : "s"} spent.`
    });
  }

  /** Spend one of the free growth points from levels 2, 4, 6, 8 and 10. */
  static async #buyAttribute(event, target) {
    const key = target.dataset.attr;
    const sys = this.document.system;
    if (!sys.growthUnspent) return ui.notifications.warn("No attribute growth left to spend.");
    const score = sys.attributes[key].value;
    if (score >= 18) return ui.notifications.info("That attribute is already at 18.");
    await this.document.update({
      [`system.attributes.${key}.value`]: score + 1,
      "system.attributeGrowth": sys.attributeGrowth + 1
    });
  }

  static async #removeXenotype() {
    const x = this.document.items.find(i => i.type === "xenotype");
    if (!x) return;
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Remove Xenotype" },
      content: `<p>Remove <strong>${x.name}</strong> from ${this.document.name}?</p>`
    });
    if (ok) await x.delete();
  }

  static async #addInjury() {
    await this.document.update({ "system.injuries":
      [...this.document.system.injuries, { name: "", effect: "", permanent: false, major: false }] });
  }
  static async #removeInjury(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.injuries":
      this.document.system.injuries.filter((_, n) => n !== i) });
  }
  static async #addDisease() {
    await this.document.update({ "system.diseases":
      [...this.document.system.diseases, { name: "", tier: 1, tn: 8, cap: 0, note: "" }] });
  }
  static async #removeDisease(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.diseases":
      this.document.system.diseases.filter((_, n) => n !== i) });
  }

  /** One treatment check a week. Degrees of success move the tier. */
  static async #treatDisease(event, target) {
    const i = Number(target.dataset.index);
    const list = [...this.document.system.diseases];
    const d = list[i];
    if (!d) return;
    const med = this.element.querySelector(".med-select")?.value ?? "herbal";
    const heal = this.document.items.find(x => x.type === "skill" && x.name.toLowerCase() === "heal");

    const { margin } = await game.zed00.Dice.rollSkill(this.document, {
      skill: heal, attribute: "int", tn: d.tn, medicine: med,
      label: `Treating ${d.name || "disease"}`
    });

    const shift = margin >= 4 ? -2 : margin >= 0 ? -1 : margin <= -4 ? 1 : 0;
    const cap = d.cap || 5;
    d.tier = Math.max(0, Math.min(cap, d.tier + shift));

    if (d.tier <= 0) {
      list.splice(i, 1);
      ChatMessage.create({ content: `<strong>${d.name || "The illness"} has passed.</strong>` });
    } else if (d.tier >= 5) {
      ChatMessage.create({ content: `<strong>${d.name} has reached tier 5.</strong>` });
    }
    await this.document.update({ "system.diseases": list });
  }

  static async #toggleEquip(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    // Armor is worn or not; everything else is readied or stowed.
    const key = item.type === "armor" ? "system.equipped" : "system.stowed";
    await item.update({ [key]: !foundry.utils.getProperty(item, key) });
  }
}
