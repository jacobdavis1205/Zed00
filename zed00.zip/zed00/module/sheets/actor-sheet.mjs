const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
import { cfg } from "../settings.mjs";

export class Zed00ActorSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "actor"],
    position: { width: 760, height: 820 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      rollSkill:     Zed00ActorSheet.#rollSkill,
      rollSave:      Zed00ActorSheet.#rollSave,
      rollAttack:    Zed00ActorSheet.#rollAttack,
      push:          Zed00ActorSheet.#push,
      endScene:      Zed00ActorSheet.#endScene,
      restWeek:      Zed00ActorSheet.#restWeek,
      adjustStrain:  Zed00ActorSheet.#adjustStrain,
      editItem:      Zed00ActorSheet.#editItem,
      deleteItem:    Zed00ActorSheet.#deleteItem,
      createItem:    Zed00ActorSheet.#createItem,
      toggleEquip:   Zed00ActorSheet.#toggleEquip
    }
  };

  static PARTS = {
    header:    { template: "systems/zed00/templates/actor/header.hbs" },
    tabs:      { template: "systems/zed00/templates/actor/tabs.hbs" },
    main:      { template: "systems/zed00/templates/actor/main.hbs" },
    condition: { template: "systems/zed00/templates/actor/condition.hbs" },
    gear:      { template: "systems/zed00/templates/actor/gear.hbs" },
    psionics:  { template: "systems/zed00/templates/actor/psionics.hbs" },
    bio:       { template: "systems/zed00/templates/actor/bio.hbs" }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "main",      label: "ZED00.Tab.Main" },
        { id: "condition", label: "ZED00.Tab.Condition" },
        { id: "gear",      label: "ZED00.Tab.Gear" },
        { id: "psionics",  label: "ZED00.Tab.Psionics" },
        { id: "bio",       label: "ZED00.Tab.Bio" }
      ],
      initial: "main"
    }
  };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const actor = this.document;
    const sys = actor.system;

    ctx.actor = actor;
    ctx.system = sys;
    ctx.config = CONFIG.ZED00;
    ctx.editable = this.isEditable;
    ctx.isColonist = actor.type === "colonist";

    // Sort the owned items into buckets the templates can iterate.
    ctx.items = {
      weapons:   actor.items.filter(i => i.type === "weapon"),
      armor:     actor.items.filter(i => i.type === "armor"),
      gear:      actor.items.filter(i => i.type === "gear"),
      drugs:     actor.items.filter(i => i.type === "drug"),
      cyberware: actor.items.filter(i => i.type === "cyberware"),
      powers:    actor.items.filter(i => i.type === "power"),
      foci:      actor.items.filter(i => i.type === "focus"),
      skills:    actor.items.filter(i => i.type === "skill")
                      .sort((a, b) => a.name.localeCompare(b.name)),
      xenotype:  actor.items.find(i => i.type === "xenotype") ?? null
    };

    // Encumbrance actually carried, against what the character can manage.
    const carried = actor.items.filter(i => i.system?.encumbrance !== undefined);
    ctx.encumbrance = {
      readied: carried.filter(i => !i.system.stowed)
                      .reduce((n, i) => n + (i.system.encumbrance * (i.system.quantity ?? 1)), 0),
      stowed:  carried.filter(i => i.system.stowed)
                      .reduce((n, i) => n + (i.system.encumbrance * (i.system.quantity ?? 1)), 0),
      readiedMax: sys.encumbrance.readiedMax,
      stowedMax:  sys.encumbrance.stowedMax
    };
    ctx.encumbrance.overReadied = ctx.encumbrance.readied > ctx.encumbrance.readiedMax;
    ctx.encumbrance.overStowed  = ctx.encumbrance.stowed  > ctx.encumbrance.stowedMax;

    // The Strain track renders as pips so the pool reads at a glance.
    ctx.strainPips = Array.from({ length: sys.strain.max }, (_, i) => ({
      filled: i < sys.strain.value,
      past:   i >= sys.strain.unstableAt
    }));

    ctx.exposureLadder = [0, 1, 2, 3, 4, 5].map(n => ({
      level: n,
      current: n === sys.exposure.level,
      reachable: n <= (sys.exposure.ceiling || 0)
    }));

    ctx.autoPenalties = cfg.autoPenalties;
    ctx.canPush = !ctx.isColonist && sys.nextPushCost !== null;

    return ctx;
  }

  _preparePartContext(partId, ctx) {
    if (["main", "condition", "gear", "psionics", "bio"].includes(partId)) ctx.tab = ctx.tabs?.[partId];
    return ctx;
  }

  /* ------------------------------------------------------- actions */

  static async #rollSkill(event, target) {
    const name = target.dataset.skill;
    const tn = Number(target.dataset.tn ?? 8);
    await this.document.rollSkill(name, { tn, darkness: this.document.system.conditions.darkness });
  }

  static async #rollSave(event, target) {
    await this.document.rollSave(target.dataset.save);
  }

  static async #rollAttack(event, target) {
    const item = this.document.items.get(target.dataset.itemId);
    if (!item) return;
    const skill = this.document.items.find(i => i.type === "skill" &&
      i.name.toLowerCase() === (item.system.category === "melee" ? "stab" : "shoot"));
    await game.zed00.Dice.rollAttack(this.document, item, { skill });
  }

  static async #push() { await this.document.push(); }

  static async #endScene() {
    await game.zed00.Dice.endScene(this.document);
    ui.notifications.info("Scene ended. Pushes reset.");
  }

  static async #restWeek() { await this.document.restWeek(); }

  static async #adjustStrain(event, target) {
    const delta = Number(target.dataset.delta);
    const sys = this.document.system;
    await this.document.update({
      "system.strain.value": Math.clamp(sys.strain.value + delta, 0, sys.strain.max)
    });
  }

  static async #editItem(event, target) {
    this.document.items.get(target.closest("[data-item-id]").dataset.itemId)?.sheet.render(true);
  }

  static async #deleteItem(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Delete Item" },
      content: `<p>Delete <strong>${item.name}</strong>?</p>`
    });
    if (ok) await item.delete();
  }

  static async #createItem(event, target) {
    const type = target.dataset.type;
    await this.document.createEmbeddedDocuments("Item", [{
      name: `New ${type}`, type
    }]);
  }

  static async #toggleEquip(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    const key = item.type === "armor" ? "system.equipped" : "system.stowed";
    await item.update({ [key]: !foundry.utils.getProperty(item, key) });
  }
}
