const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

/** A stat block. No pushing, no foci, no colony week. */
export class Zed00CreatureSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "creature"],
    position: { width: 540, height: 620 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      editImage:      Zed00CreatureSheet.#editImage,
      rollAttack:     Zed00CreatureSheet.#rollAttack,
      rollMorale:     Zed00CreatureSheet.#rollMorale,
      rollInitiative: Zed00CreatureSheet.#rollInitiative,
      addSpecial:     Zed00CreatureSheet.#addSpecial,
      removeSpecial:  Zed00CreatureSheet.#removeSpecial,
      rollSkill:      Zed00CreatureSheet.#rollSkill,
      rollHP:         Zed00CreatureSheet.#rollHP,
      addAttack:      Zed00CreatureSheet.#addAttack,
      removeAttack:   Zed00CreatureSheet.#removeAttack
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/actor/creature.hbs" } };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    ctx.actor = this.document;
    ctx.system = this.document.system;
    ctx.editable = this.isEditable;
    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(ctx.system.description ?? "", { async: true });
    return ctx;
  }

  static async #editImage() {
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image", current: this.document.img,
      callback: path => this.document.update({ img: path })
    });
    return fp.browse();
  }

  static async #rollAttack(event, target) {
    const i = Number(target.dataset.index ?? 0);
    const atk = this.document.system.attacks[i];
    if (!atk) return;

    // Use the targeted token's AC if there is one.
    const t = Array.from(game.user.targets)[0];
    const ac = t ? (t.actor?.system?.armorClass ?? t.actor?.system?.ac ?? 10) : null;

    const roll = await new Roll(`1d20 + ${atk.bonus}`).evaluate();
    const hit = ac === null ? null : roll.total >= ac;

    const bits = [
      `<button class="zed00-damage" data-formula="${atk.damage}" data-label="${atk.name}">Roll damage — ${atk.damage}</button>`
    ];
    if (atk.shock) {
      bits.push(`<button class="zed00-damage" data-formula="${atk.shock}" data-label="${atk.name} Shock">Shock ${atk.shock} vs AC ${atk.shockAC}</button>`);
    }
    if (atk.note) bits.push(`<em>${atk.note}</em>`);

    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>${atk.name}</strong>` +
              (t ? ` vs ${t.name} (AC ${ac}) — <em>${hit ? "Hit" : "Miss"}</em>` : "") +
              `<div class="zed00-detail">${bits.join("<br>")}</div>`
    });
  }

  static async #addAttack() {
    const list = [...this.document.system.attacks,
      { name: "Attack", bonus: this.document.system.attacks.length ? 1 : 1,
        damage: "1d6", shock: 0, shockAC: 0, range: "", note: "" }];
    await this.document.update({ "system.attacks": list });
  }

  static async #removeAttack(event, target) {
    const i = Number(target.dataset.index);
    const list = this.document.system.attacks.filter((_, n) => n !== i);
    await this.document.update({ "system.attacks": list.length ? list : undefined });
  }

  static async #rollSkill() {
    const sys = this.document.system;
    const roll = await new Roll(`2d6 + ${sys.skillBonus}`).evaluate();
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: "<strong>Skill check</strong>"
    });
  }

  /** Roll hit points from hit dice, the old-fashioned way. */
  static async #rollHP() {
    const sys = this.document.system;
    const roll = await new Roll(`${sys.hitDice}d8`).evaluate();
    await this.document.update({
      "system.health.max": roll.total,
      "system.health.value": roll.total
    });
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>Hit points</strong> — ${sys.hitDice}d8`
    });
  }

  static async #rollMorale() {
    const sys = this.document.system;
    if (sys.moraleImmune) return ui.notifications.info(`${this.document.name} does not check Morale.`);
    const roll = await new Roll("2d6").evaluate();
    const held = roll.total <= sys.morale;
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>Morale</strong> vs ${sys.morale} — <em>${held ? "holds" : "breaks"}</em>`
    });
  }

  static async #rollInitiative() {
    const roll = await new Roll("1d8").evaluate();
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: "<strong>Initiative</strong>"
    });
  }

  static async #addSpecial() {
    const list = [...this.document.system.special, ""];
    await this.document.update({ "system.special": list });
  }

  static async #removeSpecial(event, target) {
    const i = Number(target.dataset.index);
    const list = this.document.system.special.filter((_, n) => n !== i);
    await this.document.update({ "system.special": list });
  }
}
