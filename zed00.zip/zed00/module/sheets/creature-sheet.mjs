const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

/** A stat block. No pushing, no foci, no colony week. */
export class Zed00CreatureSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "creature"],
    position: { width: 540, height: 620 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      editImage:      Zed00CreatureSheet.#editImage,
      rollAttack:     Zed00CreatureSheet.#rollAttack,
      rollMorale:     Zed00CreatureSheet.#rollMorale,
      rollInitiative: Zed00CreatureSheet.#rollInitiative,
      addSpecial:     Zed00CreatureSheet.#addSpecial,
      removeSpecial:  Zed00CreatureSheet.#removeSpecial
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/actor/creature.hbs" } };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    ctx.actor = this.document;
    ctx.system = this.document.system;
    ctx.editable = this.isEditable;
    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(ctx.system.description ?? "", { async: true });
    return ctx;
  }

  static async #editImage() {
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image", current: this.document.img,
      callback: path => this.document.update({ img: path })
    });
    return fp.browse();
  }

  static async #rollAttack() {
    const sys = this.document.system;
    const roll = await new Roll(`1d20 + ${sys.attackBonus}`).evaluate();
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>Attack</strong> — damage ${sys.damage}` +
              (sys.shock.damage ? ` · Shock ${sys.shock.damage}/AC${sys.shock.ac}` : "")
    });
  }

  static async #rollMorale() {
    const sys = this.document.system;
    if (sys.moraleImmune) return ui.notifications.info(`${this.document.name} does not check Morale.`);
    const roll = await new Roll("2d6").evaluate();
    const held = roll.total <= sys.morale;
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>Morale</strong> vs ${sys.morale} — <em>${held ? "holds" : "breaks"}</em>`
    });
  }

  static async #rollInitiative() {
    const roll = await new Roll("1d8").evaluate();
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: "<strong>Initiative</strong>"
    });
  }

  static async #addSpecial() {
    const list = [...this.document.system.special, ""];
    await this.document.update({ "system.special": list });
  }

  static async #removeSpecial(event, target) {
    const i = Number(target.dataset.index);
    const list = this.document.system.special.filter((_, n) => n !== i);
    await this.document.update({ "system.special": list });
  }
}
