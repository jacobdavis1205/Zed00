const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;

import { summary } from "../colony.mjs";
import { setColonyScene, invalidateStructures } from "../structures.mjs";

/**
 * The colony at a glance — who, what, how much.
 *
 * Open to players as well as the GM, because every figure on it is
 * something they could count for themselves by walking the map; it just
 * saves them the walk. Sections fold away so a table that only cares
 * about the larder is not scrolling past the wall inventory.
 *
 * Which sections are folded is remembered per person, not per world:
 * it is a reading preference, not a fact about the colony.
 */
export class Zed00ColonySheet extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "zed00-colony",
    classes: ["zed00", "sheet", "colony-sheet"],
    position: { width: 580, height: 720 },
    window: { title: "The Colony", icon: "fas fa-house-chimney", resizable: true },
    actions: {
      fold:       Zed00ColonySheet.#fold,
      refresh:    Zed00ColonySheet.#refresh,
      claimScene: Zed00ColonySheet.#claimScene,
      openActor:  Zed00ColonySheet.#openActor,
      goHome:     Zed00ColonySheet.#goHome,
      toggleDefences: Zed00ColonySheet.#toggleDefences
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/colony.hbs" } };

  static SECTIONS = ["people", "wealth", "structures", "stores", "power"];

  /** Folded sections live in the browser, per reader. */
  #folded = new Set();

  constructor(options = {}) {
    super(options);
    try {
      const saved = JSON.parse(localStorage.getItem("zed00.colony.folded") ?? "[]");
      if (Array.isArray(saved)) this.#folded = new Set(saved);
    } catch { /* a fresh browser, or one that blocks storage. Unfolded is fine. */ }
  }

  #remember() {
    try {
      localStorage.setItem("zed00.colony.folded", JSON.stringify([...this.#folded]));
    } catch { /* not worth telling anybody about */ }
  }

  async _prepareContext() {
    const s = summary();
    s.isGM = game.user.isGM;
    s.folded = Object.fromEntries(
      this.constructor.SECTIONS.map(k => [k, this.#folded.has(k)]));
    s.currentScene = canvas?.scene?.name ?? "";
    return s;
  }

  static #fold(event, target) {
    const key = target.dataset.section;
    if (!key) return;
    if (this.#folded.has(key)) this.#folded.delete(key);
    else this.#folded.add(key);
    this.#remember();
    this.render();
  }

  static #refresh() {
    invalidateStructures();
    this.render();
  }

  /** Name the scene you are standing on as the colony. */
  static async #claimScene() {
    if (!canvas?.scene) return;
    await setColonyScene(canvas.scene);
    this.render();
  }

  /** Go and look at the colony, wherever the party has wandered to. */
  static async #goHome() {
    const s = summary().scene;
    await s?.view();
    this.render();
  }

  /** Flip whether walls and turrets make the place a bigger target. */
  static async #toggleDefences() {
    if (!game.user.isGM) return;
    const now = game.settings.get("zed00", "defencesCount") === true;
    await game.settings.set("zed00", "defencesCount", !now);
    this.render();
  }

  static async #openActor(event, target) {
    const uuid = target.closest("[data-uuid]")?.dataset.uuid;
    const actor = uuid ? await fromUuid(uuid).catch(() => null) : null;
    actor?.sheet?.render(true);
  }
}

let open = null;

export function openColony() {
  open ??= new Zed00ColonySheet();
  open.render(true);
  return open;
}

/**
 * Keep an open colony sheet honest.
 *
 * Everything on it is read live, so anything that changes the map or a
 * colonist invalidates it. Re-rendering on those hooks is cheaper than
 * asking people to remember to press refresh.
 */
export function registerColonyHooks() {
  const redraw = foundry.utils.debounce(() => {
    if (open?.rendered) open.render();
  }, 250);

  for (const hook of ["createToken", "updateToken", "deleteToken",
                      "updateActor", "createItem", "updateItem", "deleteItem",
                      "canvasReady"]) {
    Hooks.on(hook, redraw);
  }
}
