const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ItemSheetV2 } = foundry.applications.sheets;

export class Zed00ItemSheet extends HandlebarsApplicationMixin(ItemSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "item"],
    position: { width: 520, height: 520 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      durabilitySave: Zed00ItemSheet.#durabilitySave,
      degrade:        Zed00ItemSheet.#degrade,
      repair:         Zed00ItemSheet.#repair,
      openMod:        Zed00ItemSheet.#openMod
    }
  };

  static PARTS = {
    header:  { template: "systems/zed00/templates/item/header.hbs" },
    details: { template: "systems/zed00/templates/item/details.hbs" },
    description: { template: "systems/zed00/templates/item/description.hbs" }
  };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    ctx.item = this.document;
    ctx.system = this.document.system;
    ctx.config = CONFIG.ZED00;
    ctx.editable = this.isEditable;
    ctx.type = this.document.type;

    // Which fields the details panel should show.
    ctx.show = {
      combat:    ["weapon"].includes(ctx.type),
      armor:     ["armor"].includes(ctx.type),
      physical:  ["weapon", "armor", "gear", "drug"].includes(ctx.type),
      condition: ["weapon", "armor", "gear"].includes(ctx.type),
      mod:       ["weapon", "armor"].includes(ctx.type),
      drug:      ctx.type === "drug",
      cyber:     ctx.type === "cyberware",
      power:     ctx.type === "power",
      skill:     ctx.type === "skill",
      focus:     ctx.type === "focus"
    };

    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(ctx.system.description ?? "", { async: true });

    return ctx;
  }

  static async #durabilitySave() { await this.document.durabilitySave(); }
  static async #degrade()        { await this.document.degrade(); }

  static async #openMod() {
    const uuid = this.document.system.modUuid;
    if (!uuid) return;
    const doc = await fromUuid(uuid);
    if (doc) doc.sheet.render(true);
    else ui.notifications.warn("That modification can no longer be found.");
  }

  /** Dropping a Modification onto a weapon or armor fills both fields. */
  async _onDrop(event) {
    const data = foundry.applications.ux.TextEditor.implementation.getDragEventData(event);
    if (data?.type !== "Item") return super._onDrop?.(event);
    const dropped = await fromUuid(data.uuid);
    if (dropped?.type !== "modification") return super._onDrop?.(event);
    if (!["weapon", "armor"].includes(this.document.type)) return;
    await this.document.update({
      "system.mod": dropped.name,
      "system.modUuid": data.uuid
    });
    ui.notifications.info(`${dropped.name} fitted to ${this.document.name}.`);
  }

  static async #repair() {
    const order = CONFIG.ZED00.conditions;
    const i = order.indexOf(this.document.system.condition);
    if (i <= 0) return ui.notifications.info("Already pristine.");
    if (this.document.system.condition === "destroyed") {
      return ui.notifications.warn("Destroyed gear has no repair path, at any price, from anyone.");
    }
    await this.document.update({ "system.condition": order[i - 1] });
  }
}
