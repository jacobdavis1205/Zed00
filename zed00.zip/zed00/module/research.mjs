/**
 * Colony research.
 *
 * A colonist who spends a week researching banks **2d6 + Know + INT
 * modifier − 4** points. Points go into whatever project is active, and
 * a project needs its prerequisites finished before it can be started
 * at all — cost does not gate that, the dependency does.
 *
 * Everything derivable is derived: which benches exist comes off the
 * map, what is available comes off the completed list. The only stored
 * state is what has been finished, what is in progress, and how many
 * points are banked against each.
 */

import { PROJECTS, BY_NAME, TECHPRINTS } from "./research-data.mjs";

// Re-exported so research.mjs is the one door everything else knocks on.
export { PROJECTS, BY_NAME, TECHPRINTS };

/**
 * The handbook's projects, plus whatever this world has added.
 *
 * Factions keep things to themselves, and a party that prises a secret
 * out of one should be able to put it on the research board. Added
 * projects live in a world setting rather than in research-data.mjs,
 * so they survive a system update and belong to this campaign rather
 * than to the system.
 */
export function allProjects() {
  const extra = game.settings?.get?.("zed00", "extraProjects") ?? [];
  return [...PROJECTS, ...(Array.isArray(extra) ? extra : [])];
}

export function projectNamed(name) {
  return allProjects().find(p => p.name === name) ?? null;
}

/** Every tier that has anything in it, the book's and this world's alike. */
export function tierList() {
  return [...new Set(allProjects().map(p => p.tier))].sort((a, b) => a - b);
}

/**
 * Put a new project on the board.
 *
 * Deliberately thin: a name, a tier, a cost, what it unlocks, and what
 * it needs first. That is everything a handbook project has, so a
 * faction secret behaves exactly like one once it is written down.
 */
export async function addProject({ name, tier = 4, cost = 40, unlocks = "",
                                   needs = [], keystone = false,
                                   source = "" } = {}) {
  if (!game.user.isGM) return null;
  const clean = String(name ?? "").trim();
  if (!clean) return null;
  if (projectNamed(clean)) {
    ui.notifications.warn(`There is already a project called ${clean}.`);
    return null;
  }
  const extra = game.settings.get("zed00", "extraProjects") ?? [];
  const project = {
    name: clean,
    tier: Math.max(1, Number(tier) || 4),
    cost: Math.max(1, Number(cost) || 40),
    unlocks: String(unlocks ?? ""),
    needs: Array.isArray(needs) ? needs.filter(Boolean) : [],
    keystone: !!keystone,
    // Where it came from, so the board can show that this one was not in
    // the book — it was taken from somebody.
    source: String(source ?? ""),
    added: true
  };
  await game.settings.set("zed00", "extraProjects", [...extra, project]);
  ui.notifications.info(`${clean} added to the research board.`);
  return project;
}

export async function removeProject(name) {
  if (!game.user.isGM) return null;
  const extra = game.settings.get("zed00", "extraProjects") ?? [];
  const next = extra.filter(p => p.name !== name);
  if (next.length === extra.length) {
    ui.notifications.warn(
      `${name} is one of the handbook's projects and cannot be removed.`);
    return null;
  }
  await game.settings.set("zed00", "extraProjects", next);
  return next;
}
import { placedStructures } from "./structures.mjs";

const { ApplicationV2, HandlebarsApplicationMixin, DialogV2 } = foundry.applications.api;

const KEY = "research";

export function registerResearchSettings() {
  // Projects this campaign has added — faction secrets, salvage, things
  // the party talked somebody out of. Separate from the handbook's list
  // so a system update never touches them.
  game.settings.register("zed00", "extraProjects", {
    scope: "world", config: false, type: Array, default: []
  });

  game.settings.register("zed00", KEY, {
    scope: "world", config: false, type: Object,
    default: { done: [], progress: {}, active: null, techprints: 0 }
  });

  /**
   * How much faster the better benches are.
   *
   * The handbook says the Advanced Research Station is "faster
   * research" and the Multi-Analyzer "boosts that bench's research
   * speed", and gives no numbers for either. These are the module's,
   * and they are settings so a maths audit can move them without a
   * release.
   */
  game.settings.register("zed00", "advancedBenchBonus", {
    name: "Advanced Research Station bonus",
    hint: "Extra research points a week, for a colonist working at an Advanced Research Station rather than a Simple Research Bench. The handbook says it is faster and gives no number.",
    scope: "world", config: true, type: Number, default: 3,
    range: { min: 0, max: 10, step: 1 }
  });

  game.settings.register("zed00", "analyzerBonus", {
    name: "Multi-Analyzer bonus",
    hint: "Extra research points a week when a Multi-Analyzer stands next to the bench being worked at.",
    scope: "world", config: true, type: Number, default: 2,
    range: { min: 0, max: 10, step: 1 }
  });

  game.settings.register("zed00", "benchGating", {
    name: "Higher tiers need better benches",
    hint: "On: Tier 3 research needs an Advanced Research Station, and Tier 4 needs one with a Multi-Analyzer beside it. Off: any research bench studies anything. The handbook does not say either way.",
    scope: "world", config: true, type: Boolean, default: true
  });
}

/* ------------------------------------------------------------------ */
/*  State                                                              */
/* ------------------------------------------------------------------ */

export function state() {
  const s = game.settings.get("zed00", KEY) ?? {};
  return {
    done: s.done ?? [],
    progress: s.progress ?? {},
    active: s.active ?? null,
    techprints: s.techprints ?? 0
  };
}

async function save(next) {
  return game.settings.set("zed00", KEY, next);
}

/** Has this project been finished? */
export function isDone(name) {
  return state().done.includes(name);
}

/** Are this project's prerequisites all finished? */
export function isAvailable(name, done = null) {
  const list = done ?? state().done;
  const p = projectNamed(name);
  if (!p) return false;
  return p.needs.every(n => list.includes(n));
}

/* ------------------------------------------------------------------ */
/*  Benches                                                            */
/* ------------------------------------------------------------------ */

const SIMPLE = /simple research bench/i;
const ADVANCED = /advanced research station/i;
const ANALYZER = /multi-?analyz/i;

/** Two tokens are adjacent if their squares touch, corners included. */
function adjacent(a, b) {
  const ta = a?.parent?.token ?? a?.token, tb = b?.parent?.token ?? b?.token;
  if (!ta || !tb) return false;
  const ax2 = ta.x + (ta.width ?? 1) * (canvas?.grid?.size ?? 100);
  const ay2 = ta.y + (ta.height ?? 1) * (canvas?.grid?.size ?? 100);
  const bx2 = tb.x + (tb.width ?? 1) * (canvas?.grid?.size ?? 100);
  const by2 = tb.y + (tb.height ?? 1) * (canvas?.grid?.size ?? 100);
  const gap = (canvas?.grid?.size ?? 100) * 1.1;
  const overlapX = ta.x < bx2 + gap && bx2 > ta.x - gap && tb.x < ax2 + gap;
  const overlapY = ta.y < by2 + gap && by2 > ta.y - gap && tb.y < ay2 + gap;
  return overlapX && overlapY;
}

/**
 * The research benches standing on the map, best first.
 *
 * One colonist to a bench — three researchers need three benches, which
 * is what stops a colony from throwing its whole population at a Tier 4
 * project.
 */
export function benches() {
  const all = placedStructures().filter(a =>
    SIMPLE.test(a.name) || ADVANCED.test(a.name));
  const analyzers = placedStructures().filter(a => ANALYZER.test(a.name));

  return all.map(b => {
    const advanced = ADVANCED.test(b.name);
    const boosted = analyzers.some(z => z.system.working && adjacent(b, z));
    return {
      id: b.id, name: b.name, actor: b,
      working: b.system.working,
      advanced, boosted,
      // Tier 3 wants the better bench, Tier 4 wants it with an analyzer.
      maxTier: !advanced ? 2 : (boosted ? 4 : 3),
      bonus: (advanced ? game.settings.get("zed00", "advancedBenchBonus") : 0) +
             (boosted ? game.settings.get("zed00", "analyzerBonus") : 0)
    };
  }).sort((x, y) => (y.maxTier - x.maxTier) || (y.bonus - x.bonus));
}

/** The best tier the colony can study at all. */
export function bestTier() {
  if (game.settings.get("zed00", "benchGating") !== true) return 4;
  const live = benches().filter(b => b.working);
  return live.length ? Math.max(...live.map(b => b.maxTier)) : 0;
}

/* ------------------------------------------------------------------ */
/*  A week of research                                                 */
/* ------------------------------------------------------------------ */

/**
 * Roll one colonist's week and bank it.
 *
 * This is an ordinary Know check with a -4, not a Know check plus an
 * extra Intelligence. Every skill check in the game is 2d6 + skill +
 * the governing attribute, and Know's governing attribute is INT — so
 * "2d6 + Know + INT - 4" is that same roll, penalised. Intelligence is
 * added exactly once, here and in the rules.
 *
 * The -4 is what turns a pass-or-fail check into a number of points. A
 * bad roll with no skill comes out at nothing, which is the rules being
 * honest about somebody filling in.
 */
export async function researchWeek(actor, bench = null) {
  const sys = actor.system;
  const know = (actor.items ?? []).find(i =>
    i.type === "skill" && /^know$/i.test(i.name));
  const level = Number(know?.system?.level) || 0;
  const intMod = sys.attributes?.int?.mod ?? 0;
  const benchBonus = bench?.bonus ?? 0;

  const roll = await new Roll(
    `2d6 + ${level} + ${intMod} - 4 + ${benchBonus}`).evaluate();
  const points = Math.max(0, roll.total);

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>Research</strong> — Know check ` +
            `(2d6 + Know ${level} + INT ${intMod >= 0 ? "+" : ""}${intMod}), ` +
            `then −4 for the week` +
            (benchBonus ? ` + ${benchBonus} from the bench` : "") +
            (points === 0 && roll.total < 0 ? " — nothing to show for it" : "")
  });

  await bank(points);
  return points;
}

/** Put points against the active project, finishing it if they cover it. */
export async function bank(points) {
  if (!points) return null;
  const s = state();
  if (!s.active) {
    ui.notifications.warn(
      `${points} research points earned, but no project is active. ` +
      `Pick one on the Research sheet and they will go somewhere.`);
    return null;
  }

  const project = projectNamed(s.active);
  const now = (s.progress[s.active] ?? 0) + points;
  const next = { ...s, progress: { ...s.progress, [s.active]: now } };

  if (now >= project.cost) {
    next.done = [...s.done, s.active];
    next.progress = { ...next.progress };
    delete next.progress[s.active];
    next.active = null;
    await save(next);
    ChatMessage.create({
      content: `<div class="zed00-roll"><h3>${project.name} — complete</h3>` +
               `<p>${project.unlocks}</p>` +
               `<p class="hint">${now - project.cost > 0
                 ? `${now - project.cost} points over; they do not carry.`
                 : "Exactly on the nose."}</p></div>`
    });
    return { finished: true, project };
  }

  await save(next);
  return { finished: false, project, progress: now };
}

export async function setActive(name) {
  const s = state();
  if (name && !isAvailable(name, s.done)) {
    const missing = projectNamed(name).needs.filter(n => !s.done.includes(n));
    return ui.notifications.warn(
      `${name} needs ${missing.join(" and ")} first.`);
  }
  await save({ ...s, active: name });
}

export async function markDone(name, done = true) {
  const s = state();
  const list = done
    ? [...new Set([...s.done, name])]
    : s.done.filter(n => n !== name);
  const progress = { ...s.progress };
  if (done) delete progress[name];
  await save({ ...s, done: list, progress,
               active: s.active === name && done ? null : s.active });
}

/* ------------------------------------------------------------------ */
/*  The sheet                                                          */
/* ------------------------------------------------------------------ */

export class Zed00ResearchSheet extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "zed00-research",
    classes: ["zed00", "sheet", "research-sheet"],
    position: { width: 560, height: 720 },
    window: { title: "Colony Research", icon: "fas fa-flask", resizable: true },
    actions: {
      choose:   Zed00ResearchSheet.#choose,
      complete: Zed00ResearchSheet.#complete,
      undo:     Zed00ResearchSheet.#undo,
      addWeek:  Zed00ResearchSheet.#addWeek,
      addPoints: Zed00ResearchSheet.#addPoints,
      techprint: Zed00ResearchSheet.#techprint,
      addProject: Zed00ResearchSheet.#addProject,
      dropProject: Zed00ResearchSheet.#dropProject
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/research.hbs" } };

  /** Which tiers are expanded. Tier 1 and whatever is active, by default. */
  open = null;

  async _prepareContext() {
    const s = state();
    const bs = benches();
    const top = bestTier();
    const gating = game.settings.get("zed00", "benchGating") === true;

    const active = s.active ? projectNamed(s.active) : null;
    const banked = active ? (s.progress[s.active] ?? 0) : 0;

    // Tiers come from the projects themselves, so a faction secret
    // filed at tier 5 gets a row of its own rather than vanishing.
    const tiers = tierList().map(tier => {
      const locked = gating && tier > top;
      const needPrints = TECHPRINTS[tier] ?? 0;
      const projects = allProjects().filter(p => p.tier === tier).map(p => {
        const done = s.done.includes(p.name);
        const available = isAvailable(p.name, s.done);
        const missing = p.needs.filter(n => !s.done.includes(n));
        const got = s.progress[p.name] ?? 0;
        return {
          ...p, done, available, missing, got,
          percent: Math.min(100, Math.round((got / p.cost) * 100)),
          isActive: s.active === p.name,
          blocked: !available || locked
        };
      });
      return {
        tier, locked, needPrints, projects,
        doneCount: projects.filter(p => p.done).length,
        total: projects.length
      };
    });

    return {
      isGM: game.user.isGM,
      state: s, tiers, active, banked,
      activePercent: active ? Math.min(100, Math.round((banked / active.cost) * 100)) : 0,
      activeLeft: active ? Math.max(0, active.cost - banked) : 0,
      benches: bs,
      liveBenches: bs.filter(b => b.working).length,
      bestTier: top,
      gating,
      noBench: bs.length === 0,
      doneTotal: s.done.length,
      grandTotal: allProjects().length
    };
  }

  static async #choose(event, target) {
    if (!game.user.isGM) return;
    await setActive(target.closest("[data-project]")?.dataset.project ?? null);
    this.render();
  }

  static async #complete(event, target) {
    if (!game.user.isGM) return;
    await markDone(target.closest("[data-project]")?.dataset.project, true);
    this.render();
  }

  static async #undo(event, target) {
    if (!game.user.isGM) return;
    await markDone(target.closest("[data-project]")?.dataset.project, false);
    this.render();
  }

  /** Roll a researcher's week from the sheet. */
  static async #addWeek() {
    if (!game.user.isGM) return;
    const actor = [...(game.user.targets ?? [])][0]?.actor
      ?? canvas?.tokens?.controlled?.find(t => t.actor?.type !== "structure")?.actor;
    if (!actor) {
      return ui.notifications.warn(
        "Target the colonist doing the research, or select their token.");
    }
    const free = benches().filter(b => b.working);
    await researchWeek(actor, free[0] ?? null);
    this.render();
  }

  static async #addPoints() {
    if (!game.user.isGM) return;
    const value = await DialogV2.prompt({
      window: { title: "Bank research points" },
      content: `<p>Points to add to the active project.</p>
                <input type="number" name="n" value="10" autofocus>`,
      ok: { label: "Bank", callback: (e, b, d) =>
        Number((d.element ?? b.form).querySelector('[name="n"]')?.value) || 0 },
      rejectClose: false
    });
    if (value) { await bank(value); this.render(); }
  }

  static async #techprint(event, target) {
    if (!game.user.isGM) return;
    const s = state();
    const delta = Number(target.dataset.delta) || 0;
    await save({ ...s, techprints: Math.max(0, s.techprints + delta) });
    this.render();
  }

  _onFirstRender(context, options) {
    super._onFirstRender?.(context, options);
    const redraw = foundry.utils.debounce(() => this.render(), 300);
    this.#watching = [
      ["createToken", redraw], ["updateToken", redraw], ["deleteToken", redraw],
      ["canvasReady", redraw]
    ].map(([n, f]) => [n, Hooks.on(n, f)]);
  }

  #watching = [];

  _onClose(options) {
    super._onClose?.(options);
    for (const [n, id] of this.#watching) Hooks.off(n, id);
    this.#watching = [];
  }

  /**
   * Put something new on the board.
   *
   * For a secret prised out of a faction, salvaged off a wreck, or
   * traded for. It behaves exactly like a project from the book once it
   * is written down, because it is the same shape.
   */
  static async #addProject() {
    const got = await DialogV2.prompt({
      window: { title: "Add a research project", icon: "fas fa-flask" },
      position: { width: 460 },
      content: `<div class="zed00">
        <p class="hint">A faction secret, a salvaged schematic, something
        the party talked somebody out of. It sits on the board like any
        other project.</p>
        <div class="grid">
          <label>Name</label><input type="text" name="name" placeholder="Shard-lattice plating">
          <label>Tier</label><input type="number" name="tier" min="1" max="6" value="4">
          <label title="Research points. The book's tier 4 projects cost 40.">Cost</label>
          <input type="number" name="cost" min="1" value="40">
          <label>Unlocks</label><input type="text" name="unlocks" placeholder="What it lets the colony do">
          <label title="Shown on the project, so the table remembers where it came from.">Got from</label>
          <input type="text" name="source" placeholder="The Freedom Union, in trade">
        </div>
      </div>`,
      ok: { label: "Add it", callback: (ev, button) => ({
        name: button.form.elements.name.value,
        tier: button.form.elements.tier.value,
        cost: button.form.elements.cost.value,
        unlocks: button.form.elements.unlocks.value,
        source: button.form.elements.source.value
      }) }
    }).catch(() => null);
    if (!got?.name?.trim()) return;
    await addProject(got);
    this.render();
  }

  static async #dropProject(event, target) {
    const name = target.closest("[data-project]")?.dataset.project;
    if (!name) return;
    const ok = await DialogV2.confirm({
      window: { title: `Remove ${name}?` },
      content: `<div class="zed00"><p>Take ${name} off the board? Only
        projects this campaign added can be removed.</p></div>`
    }).catch(() => false);
    if (ok) { await removeProject(name); this.render(); }
  }
}

/** One board, reopened rather than stacked. */
let open = null;

export function openResearch() {
  open ??= new Zed00ResearchSheet();
  open.render(true);
  return open;
}
