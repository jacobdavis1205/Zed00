/**
 * Editing an owned item from its parent's sheet.
 *
 * The obvious way is to name the input `items.<id>.system.quantity` and let
 * the form carry it. That does not work: a sheet form submits to the
 * document it belongs to, and an actor has no `items.<id>` field, so the
 * value is quietly discarded. Worse, a submit that fires after a stack was
 * split still holds the pre-split quantity and writes it straight back over
 * the new one — which is a quantity that "resets" for no visible reason.
 *
 * So inline item fields are kept out of the form entirely. They carry
 * `data-item-id` and `data-item-field` instead of a name, and this applies
 * them on change, to the one item, with the one value the person typed.
 */

/**
 * Wire up every inline item field inside `root`.
 *
 * @param {HTMLElement} root    the rendered sheet
 * @param {Document} parent     the actor that owns the items
 * @param {AbortSignal} signal  tears the listeners down on re-render
 */
export function bindInlineItemFields(root, parent, signal) {
  for (const input of root.querySelectorAll("[data-item-field]")) {
    input.addEventListener("change", async (event) => {
      event.stopPropagation();                 // keep it out of the form submit
      const el = event.currentTarget;
      const id = el.dataset.itemId;
      const field = el.dataset.itemField;
      const item = parent.items.get(id);
      if (!item || !field) return;

      let value = el.value;
      if (el.type === "number") {
        value = el.valueAsNumber;
        if (Number.isNaN(value)) return;
      } else if (el.type === "checkbox") {
        value = el.checked;
      }

      // Nothing changed, nothing to write.
      if (foundry.utils.getProperty(item, field) === value) return;
      await item.update({ [field]: value });
    }, { signal });
  }
}
