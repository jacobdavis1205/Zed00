/**
 * Compendium population.
 *
 * Compiling LevelDB packs needs the Foundry CLI and a build step, which
 * is more machinery than this system wants. Instead the item data ships
 * as plain JSON and gets loaded into the packs the first time a world
 * runs — or whenever the GM asks for it again.
 */

const PACKS = {
  weapons:       "weapons.json",
  armor:         "armor.json",
  modifications: "modifications.json",
  drugs:         "drugs.json",
  cyberware:     "cyberware.json",
  powers:        "powers.json",
  foci:          "foci.json",
  xenotypes:     "xenotypes.json",
  gear:          "gear.json"
};

const ACTOR_PACKS = {
  bestiary: "bestiary.json",
  animals:  "animals.json"
};

const TABLE_PACKS = { tables: "tables.json" };

const FLAG = "packsVersion";
const CURRENT = 3;

/** Load one JSON file bundled with the system. */
async function readSource(file) {
  const res = await fetch(`systems/zed00/packs-source/${file}`);
  if (!res.ok) throw new Error(`Could not read packs-source/${file}`);
  return res.json();
}

/** Fill a single compendium, skipping anything already in it. */
async function fillPack(name, file) {
  const pack = game.packs.get(`zed00.${name}`);
  if (!pack) return { name, created: 0, skipped: 0, error: "pack not found" };

  const wasLocked = pack.locked;
  if (wasLocked) await pack.configure({ locked: false });

  try {
    const docs = await readSource(file);
    const index = await pack.getIndex();
    const have = new Set(index.map(e => e.name));
    const toCreate = docs.filter(d => !have.has(d.name));

    if (toCreate.length) {
      const cls = { Actor, Item, RollTable }[pack.documentName] ?? Item;
      await cls.createDocuments(toCreate, { pack: pack.collection, keepId: false });
    }
    return { name, created: toCreate.length, skipped: docs.length - toCreate.length };
  } catch (err) {
    console.error(`Zed-00 | ${name}:`, err);
    return { name, created: 0, skipped: 0, error: err.message };
  } finally {
    if (wasLocked) await pack.configure({ locked: true });
  }
}

/** Populate everything. Safe to run more than once. */
export async function populatePacks({ notify = true } = {}) {
  if (!game.user.isGM) return;
  const results = [];
  for (const [name, file] of Object.entries({ ...PACKS, ...ACTOR_PACKS, ...TABLE_PACKS })) {
    results.push(await fillPack(name, file));
  }
  const made = results.reduce((n, r) => n + r.created, 0);
  const failed = results.filter(r => r.error);

  if (notify) {
    if (made) ui.notifications.info(`Zed-00: added ${made} items to the compendiums.`);
    else if (!failed.length) ui.notifications.info("Zed-00: compendiums already up to date.");
    for (const f of failed) ui.notifications.error(`Zed-00: ${f.name} — ${f.error}`);
  }
  console.table(results);
  return results;
}

/** Run once per world, unless the GM asks again from the settings menu. */
export function registerPackHooks() {
  game.settings.register("zed00", FLAG, {
    scope: "world", config: false, type: Number, default: 0
  });

  game.settings.registerMenu("zed00", "rebuildPacks", {
    name: "Rebuild compendiums",
    label: "Rebuild now",
    hint: "Re-reads the bundled item data and adds anything missing. Existing entries are left alone.",
    icon: "fas fa-box-open",
    type: class extends FormApplication {
      render() { populatePacks(); return this; }
    },
    restricted: true
  });

  Hooks.once("ready", async () => {
    if (!game.user.isGM) return;
    if (game.settings.get("zed00", FLAG) >= CURRENT) return;
    await populatePacks({ notify: true });
    await game.settings.set("zed00", FLAG, CURRENT);
  });
}
