/**
 * Zed-00 has TWO dice scales and they are never mixed.
 *
 *   SKILL CHECKS   2d6 + skill level + attribute modifier, against a TN.
 *                  Beat by 4+ = critical success. Miss by 4+ = critical failure.
 *
 *   SAVES          A BARE d20 against a target of 16 - level - attribute mod.
 *                  The modifier is already IN the target. Do not add it to
 *                  the roll. This mistake has been made before.
 *
 * Attack rolls use d20 + attack bonus + skill + attribute vs Armor Class,
 * which is its own thing again.
 */

export const TN = { easy: 6, standard: 8, hard: 10 };

/* ------------------------------------------------------------------ */
/*  Skill checks — 2d6                                                 */
/* ------------------------------------------------------------------ */

export async function rollSkill(actor, {
  skill = null, attribute = "int", tn = TN.standard,
  bonus = 0, label = "Check", medicine = null, multitask = false
} = {}) {
  const parts = ["2d6"];
  const flavorBits = [];

  const skillLevel = skill?.system?.level ?? -1;
  parts.push(String(skillLevel));
  flavorBits.push(`skill ${skillLevel >= 0 ? "+" : ""}${skillLevel}`);

  const mod = actor.system.attributes[attribute]?.mod ?? 0;
  parts.push(String(mod));
  flavorBits.push(`${attribute.toUpperCase()} ${mod >= 0 ? "+" : ""}${mod}`);

  // Medicine is a modifier, not a gate.
  if (medicine !== null) {
    const med = { none: -2, herbal: 0, industrial: 1, glitterworld: 2 }[medicine] ?? 0;
    parts.push(String(med));
    flavorBits.push(`${medicine} ${med >= 0 ? "+" : ""}${med}`);
  }

  // Exposure, Unstable and Bloodied all stack. So does darkness.
  const pen = (actor.system.checkPenalty ?? 0) + (actor.system.darknessPenalty ?? 0);
  if (pen) { parts.push(String(pen)); flavorBits.push(`conditions ${pen}`); }

  if (multitask) { parts.push("-2"); flavorBits.push("multitasking -2"); }
  if (bonus)     { parts.push(String(bonus)); flavorBits.push(`bonus ${bonus >= 0 ? "+" : ""}${bonus}`); }

  const roll = await new Roll(parts.join(" + ")).evaluate();
  const margin = roll.total - tn;
  const outcome =
    margin >= 4 ? "Critical success" :
    margin >= 0 ? "Success" :
    margin <= -4 ? "Critical failure" : "Failure";

  // Colony labour: crit 150%, success full, failure half, crit failure nothing.
  const yieldMultiplier =
    margin >= 4 ? 1.5 : margin >= 0 ? 1 : margin <= -4 ? 0 : 0.5;

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>${label}</strong> vs TN ${tn} — <em>${outcome}</em>
             <div class="zed00-detail">${flavorBits.join(" · ")}</div>`
  });

  return { roll, margin, outcome, yieldMultiplier };
}

/* ------------------------------------------------------------------ */
/*  Saves — a bare d20                                                 */
/* ------------------------------------------------------------------ */

export async function rollSave(actor, type = "physical", { penalty = 0, label = null } = {}) {
  const target = actor.system.saves?.[type] ?? 15;
  const effective = target + penalty;          // threats raise the target

  // BARE d20. The attribute modifier is already inside the target.
  const roll = await new Roll("1d20").evaluate();
  const success = roll.total >= effective;

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>${label ?? type} save</strong> — needs ${effective}+ —
             <em>${success ? "Success" : "Failure"}</em>`
  });
  return { roll, success, target: effective };
}

/* ------------------------------------------------------------------ */
/*  Attacks                                                            */
/* ------------------------------------------------------------------ */

export async function rollAttack(actor, weapon, { skill = null, ac = null, dualWield = false, modifiers = 0 } = {}) {
  const sys = weapon.system;

  // If the player has a token targeted, use its AC rather than asking.
  let targetName = null;
  if (ac === null) {
    const t = Array.from(game.user.targets)[0];
    if (t) {
      targetName = t.name;
      ac = t.actor?.system?.armorClass ?? t.actor?.system?.ac ?? 10;
    } else ac = 10;
  }
  if (!sys.usable) return ui.notifications.warn(`${weapon.name} is destroyed.`);

  const attr = actor.system.attributes[sys.attribute]?.mod ?? 0;
  const skillLevel = skill?.system?.level ?? -2;      // untrained is -2
  const pen = (actor.system.checkPenalty ?? 0) + (actor.system.darknessPenalty ?? 0);

  const parts = ["1d20", String(actor.system.attackBonus), String(skillLevel), String(attr)];
  if (sys.penalties.toHit) parts.push(String(sys.penalties.toHit));
  if (dualWield) parts.push("-1");
  if (pen) parts.push(String(pen));
  if (modifiers) parts.push(String(modifiers));

  const roll = await new Roll(parts.join(" + ")).evaluate();
  const natural = roll.dice[0].results[0].result;
  const hit = roll.total >= ac;

  const notes = [];
  // A natural 1 puts the weapon at risk. Off-hand weapons never resolve
  // an attack and are never in danger.
  if (natural === 1) notes.push(`<strong>Natural 1 — Durability Save (${sys.durability}+ on 1d6)</strong>`);
  if (natural === 20) notes.push(`<strong>Natural 20 — the target's armor is at risk</strong>`);
  if (!hit && sys.shock.damage && !sys.penalties.noShock) {
    notes.push(`Miss, but <strong>Shock ${sys.shock.damage}</strong> applies against AC ${sys.shock.ac} or lower`);
  }
  const dmgMod = (actor.system.attributes[sys.attribute]?.mod ?? 0) + (sys.penalties.damage ?? 0);
  const dmgFormula = `${sys.damage}${dmgMod ? (dmgMod > 0 ? ` + ${dmgMod}` : ` - ${Math.abs(dmgMod)}`) : ""}`;
  notes.push(`<button class="zed00-damage" data-formula="${dmgFormula}" data-label="${weapon.name}">Roll damage — ${dmgFormula}</button>`);

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>${weapon.name}</strong> vs ${targetName ? `${targetName} (AC ${ac})` : `AC ${ac}`} — <em>${hit ? "Hit" : "Miss"}</em>
             ${notes.length ? `<div class="zed00-detail">${notes.join("<br>")}</div>` : ""}`
  });
  return { roll, hit, natural };
}

/* ------------------------------------------------------------------ */
/*  Strain                                                             */
/* ------------------------------------------------------------------ */

/**
 * Every instance of damage taken costs 1 Strain. Shock counts. Damage
 * reduced to zero does not. Non-combat damage does.
 */
export async function takeDamage(actor, amount, { source = "damage", reducedToZero = false } = {}) {
  const sys = actor.system;
  const newHp = Math.max(sys.health.value - amount, -999);
  const updates = { "system.health.value": newHp };

  if (!reducedToZero && amount > 0) {
    const buffer = sys.strain.buffer ?? 0;
    if (buffer > 0) updates["system.strain.buffer"] = buffer - 1;
    else updates["system.strain.value"] = Math.min(sys.strain.value + 1, sys.strain.max);
  }

  await actor.update(updates);

  if (newHp <= 0) {
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<strong>${actor.name} is down.</strong> Roll on the Standard Injury Chart.
                Stabilizing is a medical check — TN 8, +1 per round elapsed, and it costs a Main Action.`
    });
  }
  return newHp;
}

/** Pushing: the Warrior's negate or the Expert's reroll, past the free use. */
export async function push(actor) {
  const cost = actor.system.nextPushCost;
  if (cost === null) return ui.notifications.warn(`${actor.name} cannot push.`);
  if (actor.system.strain.value + cost > actor.system.strain.max) {
    return ui.notifications.warn(`${actor.name} does not have the Strain to push again.`);
  }
  await actor.update({
    "system.strain.value": actor.system.strain.value + cost,
    "system.pushes": actor.system.pushes + 1
  });
  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<strong>${actor.name} pushes.</strong> ${cost ? `${cost} Strain.` : "Free use."}`
  });
}

/** A scene ends: clear pushes and any Scene-committed Effort. */
export async function endScene(actor) {
  await actor.update({ "system.pushes": 0 });
}


/* ------------------------------------------------------------------ */
/*  Chat cards                                                         */
/* ------------------------------------------------------------------ */

/** Put a power, focus or any described item into chat so the table sees it. */
export async function postItem(actor, item) {
  const sys = item.system;
  const bits = [];

  if (item.type === "power") {
    bits.push(`<b>${capitalise(sys.discipline)}</b> · Tier ${sys.tier} · ` +
              `Effort ${sys.effort} · committed for the ${capitalise(sys.duration)}`);
    if (sys.duration === "day") bits.push(`<em>Gone until a night's rest.</em>`);
  }
  if (item.type === "focus") bits.push(`<b>Focus</b> · Level ${sys.level}`);
  if (item.type === "drug")  bits.push(`Buffer ${sys.buffer} · ${sys.benefit || "—"} / ${sys.drawback || "—"}`);
  if (item.type === "cyberware") bits.push(`<b>${capitalise(sys.band)}</b> · ${sys.strainCost} Strain`);

  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<div class="zed00-card">
      <header><img src="${item.img}" width="28"><strong>${item.name}</strong></header>
      ${bits.length ? `<div class="meta">${bits.join("<br>")}</div>` : ""}
      <div class="text">${sys.description || ""}</div>
    </div>`
  });
}

const capitalise = s => String(s ?? "").replace(/^\w/, c => c.toUpperCase());

/** Spend Effort for a power and post it. */
export async function castPower(actor, power) {
  const cost = power.system.effort ?? 0;
  const eff = actor.system.effort;
  if (cost > (eff.max - eff.value)) {
    return ui.notifications.warn(`${actor.name} has only ${eff.max - eff.value} Effort free.`);
  }
  if (power.system.duration !== "instant") {
    await actor.update({ "system.effort.value": eff.value + cost });
  }
  await postItem(actor, power);
}

/** Handle the damage button on an attack card. */
export function registerChatHooks() {
  Hooks.on("renderChatMessageHTML", (msg, html) => {
    for (const btn of html.querySelectorAll("button.zed00-damage")) {
      btn.addEventListener("click", async ev => {
        ev.preventDefault();
        const r = await new Roll(btn.dataset.formula).evaluate();
        r.toMessage({ flavor: `<strong>${btn.dataset.label}</strong> — damage` });
      });
    }
  });
}
