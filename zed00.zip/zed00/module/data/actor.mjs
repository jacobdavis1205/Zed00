const { SchemaField, NumberField, StringField, BooleanField, HTMLField, ArrayField, ObjectField } = foundry.data.fields;

const ATTRIBUTES = ["str", "dex", "con", "int", "wis", "cha"];

/** SWN attribute score -> modifier. 3-5:-2, 6-8:-1, 9-12:+0, 13-15:+1, 16-17:+2, 18:+3 */
export function attrMod(score) {
  if (score <= 2) return -2;
  if (score <= 5) return -2;
  if (score <= 8) return -1;
  if (score <= 12) return 0;
  if (score <= 15) return 1;
  if (score <= 17) return 2;
  return 3;
}

/** The six Exposure levels. Only a level-3 hazard can reach Fatal. */
export const EXPOSURE = [
  { level: 0, name: "Healthy",           effect: "None" },
  { level: 1, name: "Irritated",         effect: "-1 to physical, labor and perception checks" },
  { level: 2, name: "Acute Distress",    effect: "-2 to ALL skill checks. Cannot recover Strain naturally" },
  { level: 3, name: "Systemic Decay",    effect: "Max HP -25%. +2 Strain at end of every week" },
  { level: 4, name: "Systemic Collapse", effect: "Max HP halved. Physical save weekly or fall into a coma" },
  { level: 5, name: "Fatal",             effect: "Death" }
];

export const GEAR_CONDITIONS = ["pristine", "damaged", "broken", "destroyed"];

/* ------------------------------------------------------------------ */
/*  Shared pieces                                                      */
/* ------------------------------------------------------------------ */

const attributeField = () => new SchemaField({
  value: new NumberField({ required: true, integer: true, min: 3, max: 18, initial: 10 })
});

const resourceField = (init = 0) => new SchemaField({
  value: new NumberField({ required: true, integer: true, initial: init }),
  max:   new NumberField({ required: true, integer: true, initial: init })
});

/* ------------------------------------------------------------------ */
/*  Character                                                          */
/* ------------------------------------------------------------------ */

export class Zed00Character extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const s = {};

    s.biography = new HTMLField();
    s.notes = new HTMLField();

    s.level = new NumberField({ required: true, integer: true, min: 1, initial: 1 });
    s.xp = new NumberField({ required: true, integer: true, min: 0, initial: 0 });

    s.class = new StringField({
      required: true,
      choices: ["warrior", "expert", "adventurer"],
      initial: "adventurer"
    });

    s.attributes = new SchemaField(
      Object.fromEntries(ATTRIBUTES.map(a => [a, attributeField()]))
    );

    s.health = resourceField(7);

    // Strain pool is the WIS SCORE and never grows with level.
    // Stored as current only; max is derived.
    s.strain = new SchemaField({
      value: new NumberField({ required: true, integer: true, min: 0, initial: 0 }),
      max:   new NumberField({ required: true, integer: true, initial: 10 }),
      buffer: new NumberField({ required: true, integer: true, min: 0, initial: 0 })
    });

    // Six hazard categories, each 0-3 after mitigation. Weekly gain is the
    // HIGHEST remaining, never the sum.
    s.exposure = new SchemaField({
      level: new NumberField({ required: true, integer: true, min: 0, max: 5, initial: 0 }),
      hazards: new SchemaField({
        temperature:   new NumberField({ integer: true, min: 0, max: 3, initial: 0 }),
        airQuality:    new NumberField({ integer: true, min: 0, max: 3, initial: 0 }),
        precipitation: new NumberField({ integer: true, min: 0, max: 3, initial: 0 }),
        shelter:       new NumberField({ integer: true, min: 0, max: 3, initial: 0 }),
        withdrawal:    new NumberField({ integer: true, min: 0, max: 3, initial: 0 }),
        starvation:    new NumberField({ integer: true, min: 0, max: 3, initial: 0 })
      })
    });

    s.attackBonus = new NumberField({ required: true, integer: true, initial: 0 });

    // Pushing: uses within the current scene. Cost escalates 2/4/6 (8 for Adventurer).
    s.pushes = new NumberField({ required: true, integer: true, min: 0, initial: 0 });

    s.effort = resourceField(0);

    s.neuroformers = new NumberField({ required: true, integer: true, min: 0, max: 4, initial: 0 });

    s.banner = new ArrayField(new StringField(), { initial: [] });

    s.currency = new NumberField({ required: true, integer: true, min: 0, initial: 0 });

    s.conditions = new SchemaField({
      bloodied:  new BooleanField({ initial: false }),
      unstable:  new BooleanField({ initial: false }),
      prone:     new BooleanField({ initial: false }),
      darkness:  new BooleanField({ initial: false })
    });

    return s;
  }

  /** Everything derived. Runs on every data prep. */
  prepareDerivedData() {
    // --- attribute modifiers
    for (const key of ATTRIBUTES) {
      this.attributes[key].mod = attrMod(this.attributes[key].value);
    }

    // --- Strain pool is the WIS score, full stop. It does not grow.
    this.strain.max = this.attributes.wis.value;
    this.strain.unstableAt = Math.floor(this.strain.max / 2);
    this.conditions.unstable = this.strain.value >= this.strain.unstableAt;

    // --- HP: 6 + CON mod per level, +2/level for Warriors. Never rolled.
    const perLevel = 6 + this.attributes.con.mod + (this.class === "warrior" ? 2 : 0);
    let maxHp = Math.max(1, perLevel * this.level);

    // Exposure 3 cuts max HP by a quarter; Exposure 4 halves it.
    if (this.exposure.level >= 4) maxHp = Math.floor(maxHp / 2);
    else if (this.exposure.level === 3) maxHp = Math.floor(maxHp * 0.75);
    this.health.max = maxHp;
    this.conditions.bloodied = this.health.value <= Math.floor(this.health.max / 2);

    // --- Armor Class. Worn armor sets it; unarmored is 10 plus Dex.
    // Ironhide and similar foci override this elsewhere.
    const worn = this.parent?.items?.find(i => i.type === "armor" && i.system.equipped && i.system.usable);
    this.armorClass = worn
      ? worn.system.effectiveAC + this.attributes.dex.mod
      : 10 + this.attributes.dex.mod;
    this.damageReduction = worn?.system?.dr ?? 0;
    this.shockImmune = worn?.system?.shockImmune ?? false;

    // --- Attack bonus: half level rounded down; Warriors use full level.
    this.attackBonus = this.class === "warrior"
      ? this.level
      : Math.floor(this.level / 2);

    // --- Saves. Target = 16 - level - best relevant attribute modifier.
    // The modifier is IN THE TARGET. Roll a bare d20 and meet or beat it.
    const best = (a, b) => Math.max(this.attributes[a].mod, this.attributes[b].mod);
    this.saves = {
      physical: Math.max(2, 16 - this.level - best("str", "con")),
      mental:   Math.max(2, 16 - this.level - best("wis", "cha")),
      evasion:  Math.max(2, 16 - this.level - best("dex", "int"))
    };

    // --- Encumbrance. Readied is STR/2 rounded down, Stowed is full STR.
    this.encumbrance = {
      readiedMax: Math.floor(this.attributes.str.value / 2),
      stowedMax:  this.attributes.str.value,
      readied: 0,
      stowed: 0
    };

    // --- Effort: 1 + better of WIS/CON mod + neuroformers installed. Min 1.
    this.effort.max = Math.max(
      1,
      1 + Math.max(this.attributes.wis.mod, this.attributes.con.mod) + this.neuroformers
    );

    // --- Exposure ceilings. A level-1 hazard stops at 2, level-2 at 4,
    // and only a level-3 hazard reaches 5.
    const h = Object.values(this.exposure.hazards);
    const worst = Math.max(0, ...h);
    this.exposure.worstHazard = worst;
    this.exposure.ceiling = worst === 0 ? 0 : [0, 2, 4, 5][worst];
    this.exposure.recovering = worst === 0;
    this.exposure.description = EXPOSURE[this.exposure.level]?.effect ?? "";

    // --- Global check penalty from Exposure and darkness, applied to skills.
    let penalty = 0;
    if (this.exposure.level === 1) penalty -= 1;
    if (this.exposure.level >= 2) penalty -= 2;
    if (this.conditions.unstable) penalty -= 1;
    if (this.conditions.bloodied) penalty -= 1;
    this.checkPenalty = penalty;
    this.darknessPenalty = this.conditions.darkness ? -2 : 0;

    // --- Cost of the next push this scene. Adventurers never get one free.
    const ladder = this.class === "adventurer" ? [2, 4, 6, 8] : [0, 2, 4, 6];
    this.nextPushCost = ladder[Math.min(this.pushes, ladder.length - 1)];
  }
}

/* ------------------------------------------------------------------ */
/*  Colonist — a real sheet, but never pushes and gains no class ability */
/* ------------------------------------------------------------------ */

export class Zed00Colonist extends Zed00Character {
  static defineSchema() {
    const s = super.defineSchema();
    s.loyalty = new StringField({
      choices: ["hostile", "wary", "neutral", "warm", "devoted"],
      initial: "neutral"
    });
    s.bannerOf = new StringField({ initial: "" });
    s.job = new StringField({
      choices: ["work", "guard", "rest", "follow"],
      initial: "work"
    });
    return s;
  }

  prepareDerivedData() {
    super.prepareDerivedData();
    // Colonists never push. The option does not exist for them.
    this.nextPushCost = null;
    this.canPush = false;
  }
}
