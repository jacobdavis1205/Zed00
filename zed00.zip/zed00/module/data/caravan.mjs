/**
 * A caravan.
 *
 * Everything about travel in this game is already written down: 24 miles
 * a day on foot, one Pilot check a week, a running mileage tally, a hex
 * crossed every 24 miles, and the whole party moving at its slowest
 * member's pace. What was missing was somewhere to keep it. This is that
 * somewhere — a token you push across the world map with a roster, a
 * hold and a travel log.
 *
 * It is deliberately the same object for a trade run and an expedition,
 * because the handbook's travel rules do not distinguish between them.
 *
 * The roster holds references, not copies. A colonist in a caravan is
 * the same document as the colonist on the colony map, so their gear,
 * their Strength and their Exposure are the real ones and nothing has to
 * be kept in step.
 */

const { SchemaField, NumberField, StringField, BooleanField, ArrayField, HTMLField }
  = foundry.data.fields;

/** Where a week's Pilot check lands, and what it does to the pace. */
export const PACE = {
  critfail: { label: "Critical failure", factor: 0.5, ceiling: true,
              note: "Half pace — the animals are disobeying you." },
  failure:  { label: "Failure", walking: true, ceiling: true,
              note: "No better than being on foot — the animals buy you nothing." },
  success:  { label: "Success", factor: 1,
              note: "Full pace." },
  critical: { label: "Critical success", factor: 1.5,
              note: "Half again — a very good week on the road." }
};

/** Miles to a hex, which is also a day on foot. */
export const MILES_PER_HEX = 24;
export const FOOT_SPEED = 24;

export class Zed00Caravan extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),

      // The party commits to a destination before setting out — the
      // weekly roll only measures progress against something.
      destination: new StringField({ initial: "" }),
      origin:      new StringField({ initial: "" }),
      // How far it is, in miles. The GM counts hexes and multiplies.
      distance:    new NumberField({ min: 0, initial: 0 }),
      // Cumulative miles travelled. Fractional on purpose: a week's roll
      // rarely divides into 24, and leftover miles carry.
      miles:       new NumberField({ min: 0, initial: 0 }),

      // The hex being crossed now. Difficult ground costs double, so it
      // is a property of the route rather than of the caravan.
      difficult:   new BooleanField({ initial: false }),

      // Who and what is along. `uuid` points at the real actor; `mount`
      // is the uuid of the animal a person is riding, if any.
      roster: new ArrayField(new SchemaField({
        uuid:  new StringField({ initial: "" }),
        mount: new StringField({ initial: "" }),
        note:  new StringField({ initial: "" })
      }), { initial: [] }),

      // Who takes the weekly Pilot check. Blank means the best Pilot in
      // the roster, which is the sensible default and usually right.
      driverUuid: new StringField({ initial: "" }),

      // A week-by-week record. Written by the travel roll, read by
      // anybody wanting to know how the journey actually went.
      log: new ArrayField(new SchemaField({
        week:   new NumberField({ integer: true, initial: 0 }),
        date:   new StringField({ initial: "" }),
        driver: new StringField({ initial: "" }),
        result: new StringField({ initial: "success" }),
        total:  new NumberField({ integer: true, initial: 0 }),
        perDay: new NumberField({ initial: 0 }),
        miles:  new NumberField({ initial: 0 }),
        note:   new StringField({ initial: "" })
      }), { initial: [] }),

      // Boats use the same weekly check and the same tally; only the
      // vessel changes. Zero means they are walking.
      vessel: new SchemaField({
        kind:     new StringField({ choices: ["none", "wind", "fan"], initial: "none" }),
        capacity: new NumberField({ integer: true, min: 0, initial: 0 }),
        speed:    new NumberField({ integer: true, min: 0, initial: 24 })
      })
    };
  }

  /**
   * Everything derived lives here and nothing is stored twice.
   *
   * The roster's members are real documents elsewhere in the world, so
   * the pace and the capacity are worked out from them on every render
   * rather than copied onto the caravan and left to rot.
   */
  prepareDerivedData() {
    this.hexes = {
      crossed: Math.floor(this.miles / MILES_PER_HEX),
      intoNext: Math.round((this.miles % MILES_PER_HEX) * 10) / 10,
      total: this.distance ? Math.ceil(this.distance / MILES_PER_HEX) : 0
    };
    this.remaining = Math.max(0, Math.round((this.distance - this.miles) * 10) / 10);
    this.arrived = this.distance > 0 && this.miles >= this.distance;
    this.progress = this.distance
      ? Math.min(100, Math.round((this.miles / this.distance) * 100))
      : 0;
  }
}
