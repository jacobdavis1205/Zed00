const { SchemaField, NumberField, StringField, BooleanField, HTMLField } = foundry.data.fields;

const BENCHES = ["none", "forge", "hand-tailor", "machining", "fabrication"];
const CONDITIONS = ["pristine", "damaged", "broken", "destroyed"];

const price = () => new SchemaField({
  buy:  new NumberField({ integer: true, min: 0, initial: 0 }),
  sell: new NumberField({ integer: true, min: 0, initial: 0 })
});

const physical = () => ({
  description: new HTMLField(),
  encumbrance: new NumberField({ integer: true, min: 0, initial: 1 }),
  quantity:    new NumberField({ integer: true, min: 0, initial: 1 }),
  bench:       new StringField({ choices: BENCHES, initial: "none" }),
  price:       price(),
  stowed:      new BooleanField({ initial: false }),
  homemade:    new BooleanField({ initial: false })   // only homemade gear takes a mod
});

/* ------------------------------------------------------------------ */

export class Zed00Weapon extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      category:  new StringField({ choices: ["melee", "ranged", "heavy"], initial: "melee" }),
      damage:    new StringField({ initial: "1d6" }),
      shock:     new SchemaField({
        damage: new NumberField({ integer: true, min: 0, initial: 0 }),
        ac:     new NumberField({ integer: true, min: 0, initial: 0 })
      }),
      range:     new SchemaField({
        short: new NumberField({ integer: true, min: 0, initial: 0 }),
        long:  new NumberField({ integer: true, min: 0, initial: 0 })
      }),
      magazine:  new NumberField({ integer: true, min: 0, initial: 0 }),
      ammo:      new NumberField({ integer: true, min: 0, initial: 0 }),
      ammoPool:  new StringField({ initial: "" }),
      attribute: new StringField({ initial: "str" }),
      burst:     new BooleanField({ initial: false }),
      ballistic: new BooleanField({ initial: false }),
      tl4:       new BooleanField({ initial: false }),
      twoHanded: new BooleanField({ initial: false }),
      reach:     new BooleanField({ initial: false }),
      condition: new StringField({ choices: CONDITIONS, initial: "pristine" }),
      mod:       new StringField({ initial: "" })
    };
  }

  prepareDerivedData() {
    // Broken gear still works, badly. Destroyed gear does not work at all.
    const c = this.condition;
    this.penalties = {
      toHit:  c === "damaged" ? -1 : c === "broken" ? -1 : 0,
      damage: c === "broken" ? -2 : 0,
      noShock: c === "broken"
    };
    this.usable = c !== "destroyed";
    // Enc 1 weapons can be used one-handed; anything heavier needs both.
    this.oneHanded = this.encumbrance <= 1;
    this.canOffhand = this.oneHanded && this.mod !== "Stripped Frame";
    // Durability Save threshold by bench tier.
    this.durability = { none: 5, forge: 4, "hand-tailor": 4, machining: 3, fabrication: 2 }[this.bench] ?? 5;
  }
}

export class Zed00Armor extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      ac:        new NumberField({ integer: true, min: 10, initial: 13 }),
      powered:   new BooleanField({ initial: false }),
      condition: new StringField({ choices: CONDITIONS, initial: "pristine" }),
      mod:       new StringField({ initial: "" }),
      equipped:  new BooleanField({ initial: false })
    };
  }

  prepareDerivedData() {
    const c = this.condition;
    this.effectiveAC = this.ac + (c === "damaged" ? -1 : c === "broken" ? -2 : 0);
    this.usable = c !== "destroyed";
    // Powered armor: DR 7 and total Shock immunity vs primitive and TL3.
    this.dr = this.powered && c !== "broken" ? 7 : 0;
    this.shockImmune = this.powered && c !== "broken";
    // Enc 1 armor can be slept in. Anything heavier cannot.
    this.sleepable = this.encumbrance <= 1;
  }
}

export class Zed00Modification extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      drawback:    new StringField({ initial: "" }),
      materials:   new StringField({ initial: "" }),
      bench:       new StringField({ choices: BENCHES, initial: "forge" }),
      slot:        new StringField({ choices: ["weapon", "armor"], initial: "weapon" }),
      restriction: new StringField({ initial: "" })   // e.g. "ballistic only"
    };
  }
}

export class Zed00Drug extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      buffer:    new NumberField({ integer: true, min: 0, initial: 0 }),
      benefit:   new StringField({ initial: "" }),
      drawback:  new StringField({ initial: "" }),
      freeDoses: new NumberField({ integer: true, min: 0, initial: 4 }),
      taken:     new NumberField({ integer: true, min: 0, initial: 0 })
    };
  }
  prepareDerivedData() {
    this.overLimit = Math.max(0, this.taken - this.freeDoses);
    this.dependencyRisk = this.overLimit * 5;   // roll 1d20, dependent on <= this
  }
}

export class Zed00Cyberware extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      band:     new StringField({ choices: ["minor", "standard", "major"], initial: "standard" }),
      slot:     new StringField({ initial: "" }),
      installed: new BooleanField({ initial: false }),
      price:    price()
    };
  }
  prepareDerivedData() {
    // Strain cost is permanent and comes off the maximum pool.
    this.strainCost = this.band === "major" ? 2 : 1;
    this.installTN = 10;
    this.removeTN = 14;
  }
}

export class Zed00Power extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      discipline: new StringField({
        choices: ["biopsionics", "telepathy", "telekinesis"], initial: "biopsionics" }),
      tier:     new NumberField({ integer: true, min: 1, max: 4, initial: 1 }),
      effort:   new NumberField({ integer: true, min: 0, initial: 1 }),
      duration: new StringField({ choices: ["instant", "scene", "day"], initial: "instant" })
    };
  }
}

export class Zed00Gear extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return { ...physical(), condition: new StringField({ choices: CONDITIONS, initial: "pristine" }) };
  }
}

export class Zed00Focus extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      level:   new NumberField({ integer: true, min: 1, max: 2, initial: 1 }),
      combat:  new BooleanField({ initial: false })
    };
  }
}

export class Zed00Xenotype extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return { description: new HTMLField() };
  }
}

export class Zed00Skill extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      level:     new NumberField({ integer: true, min: -1, max: 4, initial: -1 }),
      attribute: new StringField({ initial: "int" }),
      combat:    new BooleanField({ initial: false })
    };
  }
}
