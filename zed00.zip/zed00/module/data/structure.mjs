const { SchemaField, NumberField, StringField, BooleanField, HTMLField, ArrayField } =
  foundry.data.fields;

/**
 * How much one grid square of stockpile holds, in Encumbrance.
 *
 * Measured in the same unit a character carries things in, so "will this
 * fit in the warehouse" and "can I carry it there" are the same question
 * asked twice. Ten Enc a square puts a 3×3 shed at 90 Enc — comfortably
 * more than one colony's working stock, and nowhere near a whole base.
 */
export const ENC_PER_SQUARE = 10;

/** Kept so old worlds keep loading. Nothing reads it any more. */
export const UNITS_PER_SQUARE = 50;

export const FUNCTIONS = [
  "stockpile", "generator", "battery", "bench", "bed", "turret",
  "farm", "light", "climate", "recreation", "defence", "other", "wall"
];

/**
 * What a thing is built out of, and what that means when it is attacked.
 *
 * Straight from the Walls & Barriers table. The important column isn't
 * hit points — it's `fabricatedProof`. A Charge Rifle does not care that your
 * stone wall has 42 HP, and only Plasteel changes that.
 */
export const MATERIALS = {
  wood:     { label: "Wood",     fire: "flammable",      fabricatedProof: false },
  textile:  { label: "Textiles", fire: "flammable",      fabricatedProof: false,
              explosiveResistant: true },
  metal:    { label: "Metal",    fire: "fire-retardant", fabricatedProof: false },
  stone:    { label: "Stone",    fire: "inflammable",    fabricatedProof: false },
  plasteel: { label: "Plasteel", fire: "inflammable",    fabricatedProof: true },
  mixed:    { label: "Mixed",    fire: "flammable",      fabricatedProof: false }
};

/**
 * A colony structure.
 *
 * Terrain is not this. Walls, floors and doors stay as tiles and wall
 * segments — there are hundreds of them and they hold nothing worth
 * tracking. A structure actor is for the fifteen or thirty things that
 * have hit points, draw power, hold goods or shoot at people.
 */
/** Encumbrance is fractional, and 7.300000000000001 is not a weight. */
const round1 = n => Math.round(n * 10) / 10;

export class Zed00Structure extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),

      function: new StringField({ choices: FUNCTIONS, initial: "other" }),

      material: new StringField({
        choices: Object.keys(MATERIALS), initial: "metal" }),

      // What it does for somebody standing behind it. Combat gives -2 for
      // half cover and -4 for near-total; this is where a barrier earns
      // its materials, since a wall you cannot shoot over is also a wall
      // you cannot shoot from.
      cover: new StringField({
        choices: ["none", "half", "total"], initial: "none" }),

      health: new SchemaField({
        value: new NumberField({ integer: true, initial: 20 }),
        max:   new NumberField({ integer: true, initial: 20 })
      }),
      condition: new StringField({
        choices: ["pristine", "damaged", "broken", "destroyed"], initial: "pristine" }),

      // Footprint in grid squares. Drives stockpile capacity.
      squares: new NumberField({ integer: true, min: 1, initial: 1 }),

      // Power. Generators give, everything else takes.
      power: new SchemaField({
        output: new NumberField({ integer: true, min: 0, initial: 0 }),
        draw:   new NumberField({ integer: true, min: 0, initial: 0 }),
        /**
         * A battery adds Capacity without producing anything.
         *
         * There is no grid: the colony's Capacity is everything producing
         * plus every battery, and as long as total Draw stays under it,
         * everything runs. What a battery buys is a cushion for the week
         * the solar array sits under a storm — which is why it belongs
         * here and not in `output`.
         */
        capacity: new NumberField({ integer: true, min: 0, initial: 0 }),

        /**
         * Power actually sitting in this battery.
         *
         * The rules as written have no such thing — "batteries provide
         * their capacity whatever the weather" and that is the end of
         * it. This exists for the optional storage rule, which charges
         * batteries from a surplus and drains them to cover a shortfall.
         * With the rule off nothing reads it, and a new battery starts
         * empty either way rather than arriving mysteriously full.
         */
        stored: new NumberField({ integer: true, min: 0, initial: 0 }),
        // Solar and wind stop in bad weather; the week engine knows which.
        weatherDependent: new BooleanField({ initial: false }),
        running: new BooleanField({ initial: true })
      }),

      // How many colonists can use it at once, and the area it covers,
      // both straight off the handbook's own columns.
      users: new NumberField({ integer: true, min: 0, initial: 0 }),
      area:  new StringField({ initial: "" }),

      // Upkeep per week, as a material and an amount.
      upkeep: new SchemaField({
        material: new StringField({ initial: "" }),
        amount:   new NumberField({ integer: true, min: 0, initial: 0 })
      }),

      build: new SchemaField({
        materials: new StringField({ initial: "" }),
        bench:     new StringField({ initial: "none" }),
        weeks:     new NumberField({ integer: true, min: 0, initial: 0 }),
        // What it costs to buy, for the handful of structures the book
        // calls trade-only — high-tier recreation furniture with no local
        // crafting recipe at all. Everything else is valued from its
        // materials, which is a number already written down.
        trade:     new NumberField({ min: 0, initial: 0 })
      }),

      // --- stockpile ---------------------------------------------------
      // Goods are held as batches so spoilage has something to expire.
      contents: new ArrayField(new SchemaField({
        name:   new StringField({ initial: "" }),
        units:  new NumberField({ integer: true, min: 0, initial: 0 }),
        spoils: new NumberField({ integer: true, min: 0, initial: 0 })   // 0 = never
      }), { initial: [] }),
      freezing: new BooleanField({ initial: false }),
      covered:  new BooleanField({ initial: true }),

      // --- turret ------------------------------------------------------
      attacks: new ArrayField(new SchemaField({
        name:    new StringField({ initial: "Turret" }),
        bonus:   new NumberField({ integer: true, initial: 2 }),
        damage:  new StringField({ initial: "1d8" }),
        count:   new NumberField({ integer: true, min: 1, initial: 1 }),
        shock:   new NumberField({ integer: true, min: 0, initial: 0 }),
        shockAC: new NumberField({ integer: true, min: 0, initial: 0 }),
        range:   new StringField({ initial: "" }),
        note:    new StringField({ initial: "" })
      }), { initial: [] }),
      armorClass: new NumberField({ integer: true, initial: 14 }),

      /**
       * Turret ammunition.
       *
       * A turret that never runs dry is a wall that shoots, and walls
       * are cheaper. So it carries a belt: each shot spends a round, and
       * reloading pulls the matching ammunition out of a stockpile.
       * Set `magazine` to 0 and it feeds itself, for a GM who would
       * rather not track it.
       */
      ammo: new SchemaField({
        type:     new StringField({ initial: "Rifle" }),
        loaded:   new NumberField({ integer: true, min: 0, initial: 0 }),
        magazine: new NumberField({ integer: true, min: 0, initial: 0 }),
        perShot:  new NumberField({ integer: true, min: 0, initial: 1 })
      }),

      // --- farm --------------------------------------------------------
      crop: new SchemaField({
        name:    new StringField({ initial: "" }),
        yield:   new NumberField({ integer: true, min: 0, initial: 175 }),
        checks:  new NumberField({ integer: true, min: 0, max: 4, initial: 0 }),
        steps:   new NumberField({ integer: true, initial: 0 }),   // 25% each
        failures: new NumberField({ integer: true, min: 0, initial: 0 }),
        lost:    new BooleanField({ initial: false })
      }),

      // --- bed ---------------------------------------------------------
      quality: new StringField({
        choices: ["none", "bedroll", "basic", "private"], initial: "basic" }),
      sleeps: new NumberField({ integer: true, min: 0, initial: 1 }),

      // --- light -------------------------------------------------------
      // Straight off the Area Lit column. A Torch Lamp covers 3×3, a
      // Standing Lamp 5×5 and a Flood Light 10×10 — which is the whole
      // reason to pay for power, and why a free torch is not a free
      // floodlight. Radius in feet.
      lit: new SchemaField({
        bright: new NumberField({ integer: true, min: 0, initial: 0 }),
        dim:    new NumberField({ integer: true, min: 0, initial: 0 }),
        flame:  new BooleanField({ initial: false })   // burns rather than draws
      })
    };
  }

  prepareDerivedData() {
    const c = this.condition;
    this.usable = c !== "destroyed";
    this.bloodied = this.health.value <= Math.floor(this.health.max / 2);

    // --- what it is made of ------------------------------------------
    const m = MATERIALS[this.material] ?? MATERIALS.metal;
    this.materialLabel = m.label;
    this.fire = m.fire;
    this.fabricatedProof = m.fabricatedProof;
    this.explosiveResistant = !!m.explosiveResistant;
    // The one sentence a GM needs when someone shoots the wall.
    // What a condition actually means. Broken is the only one that stops
    // the building working; damaged costs materials and nothing else.
    // Deliberately shallow — a full table of per-condition penalties is a
    // can of worms, and the repair bill is enough of a consequence.
    this.conditionNote = {
      pristine:  "Working.",
      damaged:   "Still working. The only cost is the repair bill.",
      broken:    "Does not work until repaired. It still occupies the squares.",
      destroyed: "Gone. Rebuild it from scratch — repairs will not do."
    }[c] ?? "";

    this.coverNote = {
      none:  "",
      half:  "Half cover — ranged attacks past it take -2. Fire over it freely.",
      total: "Near-total cover — ranged attacks past it take -4, and you cannot shoot over it either."
    }[this.cover] ?? "";
    this.coverPenalty = { none: 0, half: -2, total: -4 }[this.cover] ?? 0;

    this.defenceNote = m.fabricatedProof
      ? "Stands up to Fabricated weapons."
      : "Takes full damage from Fabricated weapons — armour and hit points do not apply.";

    // Broken buildings do not do their job.
    this.working = this.usable && c !== "broken" && this.power.running;

    // --- stockpile ---------------------------------------------------
    // Goods are the items this structure owns, so they can be dragged in
    // off a character and dragged back out again.
    this.capacity = round1(this.squares * ENC_PER_SQUARE);
    const goods = this.parent?.items ?? [];
    this.stored = round1(goods.reduce((n, i) => {
      const s = i.system ?? {};
      return n + (Number(s.encumbrance) || 0) * (Number(s.quantity) || 0);
    }, 0));
    this.spare = round1(this.capacity - this.stored);
    this.overCapacity = this.stored > this.capacity;
    this.fillPercent = this.capacity ? Math.round((this.stored / this.capacity) * 100) : 0;

    // --- power -------------------------------------------------------
    // --- turret ------------------------------------------------------
    // A magazine of 0 means the GM would rather not track it.
    this.tracksAmmo = this.ammo.magazine > 0;
    this.dry = this.tracksAmmo && this.ammo.loaded < this.ammo.perShot;
    this.canFire = this.working && !this.dry;
    this.ammoNote = !this.tracksAmmo ? "Feeds itself"
      : this.dry ? "Out of ammunition"
      : `${this.ammo.loaded} / ${this.ammo.magazine} ${this.ammo.type}`;

    // What this one building does to the colony's books. A battery
    // contributes capacity; a generator contributes production; a bench
    // takes. All three are "net" in different directions, so keep them
    // apart and let the colony tally add them up.
    this.produces = this.working ? this.power.output : 0;
    this.adds = this.working ? this.power.capacity : 0;
    this.takes = this.working ? this.power.draw : 0;
    this.netPower = this.produces - this.takes;
    this.isBattery = this.power.capacity > 0;
    this.charge = Math.min(this.power.stored, this.power.capacity);
    this.chargePercent = this.power.capacity
      ? Math.round((this.charge / this.power.capacity) * 100) : 0;
    this.powerNote =
      this.adds ? `+${this.adds} Capacity`
      : this.produces && this.power.weatherDependent
        ? `${this.produces} Power, and nothing on a bad week`
      : this.produces ? `${this.produces} Power`
      : this.takes ? `Draws ${this.takes} Power`
      : "";
    this.effectiveOutput = this.working ? this.power.output : 0;
    this.effectiveDraw = this.usable ? this.power.draw : 0;

    // --- farm --------------------------------------------------------
    // Each result moves the harvest a 25% step, capped at 150%.
    const mult = Math.max(0, Math.min(6, 4 + (this.crop.steps ?? 0))) / 4;
    this.crop.multiplier = mult;
    this.crop.projected = this.crop.lost ? 0 : Math.floor(this.crop.yield * mult);
    this.crop.ready = (this.crop.checks ?? 0) >= 4 && !this.crop.lost;
    this.crop.weeksLeft = Math.max(0, 4 - (this.crop.checks ?? 0));
  }
}
