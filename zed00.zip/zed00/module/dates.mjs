/**
 * The colony calendar.
 *
 * Real months and real dates, because a calendar's job is to be
 * invisible. "14 August" tells the whole table it is high summer with no
 * translation step; "the second week of the Burning" has to be looked up
 * every time.
 *
 * It is a 365-day year with no leap day. That is not a simplification so
 * much as a detail: this is an Earth calendar being kept on a world that
 * has no reason to share Earth's year, by people who brought it with
 * them and have never had cause to recalibrate it. The drift is the
 * point.
 *
 * Week 1 begins on the epoch and every week is seven days, so week
 * boundaries wander through the months over the years, exactly as they
 * would if you kept counting sevens from a fixed morning.
 */

export const MONTHS = [
  { name: "January",   days: 31 }, { name: "February",  days: 28 },
  { name: "March",     days: 31 }, { name: "April",     days: 30 },
  { name: "May",       days: 31 }, { name: "June",      days: 30 },
  { name: "July",      days: 31 }, { name: "August",    days: 31 },
  { name: "September", days: 30 }, { name: "October",   days: 31 },
  { name: "November",  days: 30 }, { name: "December",  days: 31 }
];

export const DAYS_IN_YEAR = 365;

/** Cumulative day-of-year on which each month starts. */
const MONTH_START = (() => {
  let n = 1;
  return MONTHS.map(m => { const s = n; n += m.days; return s; });
})();

/** Meteorological seasons: three whole months each. */
export function seasonOfMonth(monthIndex) {
  if (monthIndex >= 2 && monthIndex <= 4) return "Spring";   // Mar–May
  if (monthIndex >= 5 && monthIndex <= 7) return "Summer";   // Jun–Aug
  if (monthIndex >= 8 && monthIndex <= 10) return "Autumn";  // Sep–Nov
  return "Winter";                                           // Dec–Feb
}

/** Turn a day-of-year (1–365) into a month index and day of month. */
export function splitDayOfYear(dayOfYear) {
  const d = ((dayOfYear - 1) % DAYS_IN_YEAR + DAYS_IN_YEAR) % DAYS_IN_YEAR + 1;
  let i = MONTHS.length - 1;
  while (i > 0 && MONTH_START[i] > d) i--;
  return { monthIndex: i, day: d - MONTH_START[i] + 1, dayOfYear: d };
}

/** The day-of-year a month and day fall on. 1 March is 60. */
export function dayOfYearFor(monthIndex, day) {
  return MONTH_START[monthIndex] + day - 1;
}

/**
 * Everything about a given colony week.
 *
 * @param {number} week        1-based week counter
 * @param {number} epochDay    day-of-year week 1 starts on (1 March = 60)
 * @param {number} epochYear   the year label week 1 falls in
 */
export function dateForWeek(week, { epochDay = 60, epochYear = 1 } = {}) {
  const w = Math.max(1, Math.round(week));
  const absoluteDay = (epochDay - 1) + (w - 1) * 7;   // 0-based from year start
  const yearsPassed = Math.floor(absoluteDay / DAYS_IN_YEAR);
  const startOfYear = absoluteDay - yearsPassed * DAYS_IN_YEAR;

  const first = splitDayOfYear(startOfYear + 1);
  const lastDay = startOfYear + 7;
  const rolls = lastDay > DAYS_IN_YEAR;
  const last = splitDayOfYear(lastDay);

  const year = epochYear + yearsPassed;
  const season = seasonOfMonth(first.monthIndex);

  // "14–20 August" when the week sits in one month, "29 July – 4 August"
  // when it straddles two.
  const sameMonth = first.monthIndex === last.monthIndex && !rolls;
  const span = sameMonth
    ? `${first.day}–${last.day} ${MONTHS[first.monthIndex].name}`
    : `${first.day} ${MONTHS[first.monthIndex].name} – ` +
      `${last.day} ${MONTHS[last.monthIndex].name}`;

  return {
    week: w, year, season,
    monthIndex: first.monthIndex,
    month: MONTHS[first.monthIndex].name,
    day: first.day,
    dayOfYear: first.dayOfYear,
    endMonthIndex: last.monthIndex,
    endDay: last.day,
    span,
    crossesYear: rolls,
    label: `${span}, Year ${year}`,
    short: `${first.day} ${MONTHS[first.monthIndex].name.slice(0, 3)} ${year}`
  };
}

/**
 * Which colony week a given date falls in — the inverse, for putting a
 * note on "the 3rd of September" rather than on a week number.
 */
export function weekForDate(monthIndex, day, year, { epochDay = 60, epochYear = 1 } = {}) {
  const absolute = (year - epochYear) * DAYS_IN_YEAR + dayOfYearFor(monthIndex, day) - 1;
  return Math.floor((absolute - (epochDay - 1)) / 7) + 1;
}

/** Every week that touches a given month, for drawing a month view. */
export function weeksInMonth(monthIndex, year, epoch) {
  const first = weekForDate(monthIndex, 1, year, epoch);
  const last = weekForDate(monthIndex, MONTHS[monthIndex].days, year, epoch);
  const out = [];
  for (let w = Math.max(1, first); w <= last; w++) out.push(w);
  return out;
}

/* ------------------------------------------------------------------ */
/*  Where the calendar is now                                          */
/* ------------------------------------------------------------------ */

/*
 * These three used to live in week.mjs, which meant anything wanting to
 * know today's date imported the entire week engine — the weather
 * table, the upkeep sheet, the rations planner. A caravan asking what
 * week it is should not drag all that in behind it, so they live here
 * with the rest of the calendar.
 */

/** Where the campaign's week 1 sits in the year. */
export function epoch() {
  return {
    epochDay: game.settings.get("zed00", "epochDay") ?? 60,
    epochYear: game.settings.get("zed00", "epochYear") ?? 1
  };
}

/** How far into the current season this week is. */
export function weekOfSeason(week) {
  const here = dateForWeek(week, epoch()).season;
  let n = 1;
  while (n < 20 && dateForWeek(week - n, epoch()).season === here && week - n >= 1) n++;
  return n;
}

/**
 * The current date, as a date.
 *
 * The season comes off the month rather than off week-number-modulo-13,
 * which matters: it means spring starts in March and the seasons land
 * where a player's intuition already puts them.
 */
export function currentDate() {
  const week = game.settings.get("zed00", "week");
  const d = dateForWeek(week, epoch());
  return {
    ...d,
    weekOfSeason: weekOfSeason(week),
    label: `${d.span}, Year ${d.year}`,
    full: `Week ${week} · ${d.span}, Year ${d.year} · ${d.season}`
  };
}
