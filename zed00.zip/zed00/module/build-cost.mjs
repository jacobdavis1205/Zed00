/**
 * What a structure is worth.
 *
 * Structures carry a build recipe and no price, so a colony of
 * eighty buildings was contributing nothing at all to its own wealth —
 * the sheds counted, the walls and the fabrication bench did not. A
 * building is worth what it took to put up, which is a number already
 * written down in its recipe.
 *
 * Priced at the cost of the materials rather than at a markup. Nobody
 * is buying a wall; the figure exists to answer "how much is this place
 * worth to somebody who wants it", and raw materials is the honest
 * floor for that.
 */

/** Material prices, from the Materials & Goods compendium. */
export const MATERIAL_PRICE = {
  wood: 0.75,
  "stone chunk": 1.5,
  stone: 1.5,
  brick: 3,
  bricks: 3,
  metal: 2.25,
  textiles: 1.5,
  devilstrand: 6,
  plasteel: 7.5,
  "basic components": 4.5,
  "advanced components": 12,
  hyperweave: 15,
  fuel: 1.5,
  silver: 1
};

/**
 * Read a recipe string into priced parts.
 *
 * The strings are written for people, so they say things like
 * "15 Wood or Metal, 15 Textiles" and "5 Wood or Metal per square".
 * An "or" is a choice the builder made and we cannot see, so it is
 * priced at the cheaper option — a wealth figure should err low rather
 * than inflate a colony into a raid it did not earn.
 */
export function parseRecipe(text, { squares = 1 } = {}) {
  if (!text) return { parts: [], cost: 0, perSquare: false };

  const perSquare = /per\s+square/i.test(text);
  const parts = [];

  for (const chunk of String(text).split(/,|\band\b/i)) {
    const m = chunk.match(/(\d+(?:\.\d+)?)\s+([A-Za-z][A-Za-z\s]*?)(?:\s+per\s+square)?\s*$/);
    if (!m) continue;

    const qty = Number(m[1]);
    // "Wood or Metal" — the builder chose one and we do not know which.
    const names = m[2].split(/\s+or\s+/i)
      .map(n => n.trim().toLowerCase())
      .filter(Boolean);

    let unit = null, chosen = null;
    for (const n of names) {
      const p = MATERIAL_PRICE[n] ?? MATERIAL_PRICE[n.replace(/s$/, "")];
      if (p === undefined) continue;
      if (unit === null || p < unit) { unit = p; chosen = n; }
    }
    if (unit === null) continue;

    parts.push({ qty, material: chosen, unit, cost: qty * unit });
  }

  const base = parts.reduce((n, p) => n + p.cost, 0);
  const cost = perSquare ? base * Math.max(1, squares) : base;
  return { parts, cost: Math.round(cost * 100) / 100, perSquare };
}

/**
 * What one placed structure is worth right now.
 *
 * A damaged building is worth less: what is left of it. A destroyed one
 * is rubble and worth nothing — which also means a raid that burns the
 * place down visibly lowers the colony's wealth, and the next raid is
 * smaller. That feedback is the point.
 */
export function structureWorth(actor) {
  const sys = actor?.system ?? {};
  const squares = Number(sys.squares) || Number(sys.area) || 1;
  // A trade-only structure has no recipe to price, so it carries what it
  // cost to buy instead.
  const cost = Number(sys.build?.trade) ||
               parseRecipe(sys.build?.materials, { squares }).cost;
  if (!cost) return 0;

  const max = Number(sys.health?.max) || 0;
  const hp = Number(sys.health?.value);
  if (!max || !Number.isFinite(hp)) return Math.round(cost);

  if (hp <= 0) return 0;
  return Math.round(cost * Math.min(1, hp / max));
}

/** The intact cost, for a catalogue entry or a build estimate. */
export function buildCost(actor) {
  const sys = actor?.system ?? {};
  const squares = Number(sys.squares) || Number(sys.area) || 1;
  return Math.round(Number(sys.build?.trade) ||
                    parseRecipe(sys.build?.materials, { squares }).cost);
}
