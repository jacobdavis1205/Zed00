/**
 * Crafting — the rules half.
 *
 * Two lines from the handbook do most of the work:
 *
 *   "Forty materials is one week of dedicated work. Divide an item's
 *    total materials by 40 and round up — that's how many weeks it
 *    takes. Anything under fifteen materials is trivial."
 *
 *   "Progress carries over. A colonist can spend three weeks on one
 *    thing, or put a week in, do something else, and come back to it."
 *
 * The craft check is a MODULE RULING and not in the book. The book's
 * crafting is deterministic — have the materials, spend the weeks, get
 * the item — which means a colonist with no Fix skill at all can
 * produce Marine Armor through persistence alone. The check is here to
 * stop that, and nothing else about the book's model changes.
 *
 * One deliberate structural decision runs through all of this: a job is
 * a SNAPSHOT, not a reference. When work starts, the bench records the
 * whole thing — inputs, outputs, TN, weeks — rather than remembering
 * "a Longsword" and looking the recipe up later. Three reasons:
 * editing a recipe must not silently rewrite work already in progress;
 * a job has to be possible for something that has no recipe entry yet,
 * which today is everything; and when recipes do arrive they become a
 * thing that WRITES a job rather than a thing the job depends on.
 */

import { parseRecipe } from "./build-cost.mjs";
import { PROJECTS } from "./research-data.mjs";

/* ------------------------------------------------------------------ */
/*  What each bench asks of the person standing at it                  */
/* ------------------------------------------------------------------ */

/**
 * The difficulty ladder, keyed to the bench a recipe demands.
 *
 * Keyed that way because the bench requirement is ALREADY a difficulty
 * scale and is already on every craftable item — nothing new had to be
 * invented or entered to get a per-item TN.
 *
 * 7/9/11 rather than something gentler because a crafter is not an
 * average character. Creation hands out an array with a 14 in it, and
 * anyone building a crafter puts that 14 in Intelligence, so +1 is the
 * floor and not a lucky roll. On top of that they stack the Specialist
 * focus (which changes the dice, not the modifier), a Lead check worth
 * +1 to everyone that week, and an Expert's free reroll once per
 * four-week scene. A ladder set for the bare case would be decoration
 * by the time a real crafter stood at the bench.
 */
export const BENCH_TN = {
  none: 0,                // no check at all — a club is a club
  "hand-tailor": 7,
  forge: 7,
  machining: 9,
  fabrication: 11
};

export const BENCH_NAME = {
  none: "no bench",
  "hand-tailor": "a Hand Tailor Table",
  forge: "a Forge or Smelter",
  machining: "a Machining Table",
  fabrication: "a Fabrication Bench"
};

/* ------------------------------------------------------------------ */
/*  Time                                                               */
/* ------------------------------------------------------------------ */

/** Everything a recipe asks for, added up. */
export function materialTotal(recipe) {
  const { parts } = parseRecipe(recipe ?? "");
  return parts.reduce((n, p) => n + (Number(p.qty) || 0), 0);
}

/**
 * How long a job takes, straight from the book.
 *
 * The trivial band is not a rounding artefact — the handbook says
 * anything under fifteen materials "gets made alongside other work, no
 * dedicated week required", so it finishes the moment it is started.
 */
export function weeksFor(recipe) {
  const total = materialTotal(recipe);
  if (total <= 0) return { total: 0, weeks: 1, trivial: false };
  if (total < 15) return { total, weeks: 0, trivial: true };
  return { total, weeks: Math.ceil(total / 40), trivial: false };
}

/* ------------------------------------------------------------------ */
/*  Outcomes                                                           */
/* ------------------------------------------------------------------ */

/**
 * Read a skill check as a crafting result.
 *
 * The bands are the ones rollSkill already uses, which is why crafting
 * does not roll its own dice: a critical failure is a botch, an
 * ordinary failure is a week lost to doing it over, and anything from a
 * success upward proceeds at the book's pace.
 *
 * Note what a failure is NOT: the job does not end and the materials
 * are not lost. A week in colony time is a long thing to hand somebody
 * nothing for, and "it took longer than you hoped" tells the same story
 * without the dead air.
 */
export function readOutcome(margin) {
  if (margin <= -4) return {
    state: "botched", extraWeeks: 0, spoils: true,
    line: "Botched — half the materials are ruined and the job is off the bench."
  };
  if (margin < 0) return {
    state: "working", extraWeeks: 1, spoils: false,
    line: "Harder than it looked — one extra week on the job."
  };
  return {
    state: "working", extraWeeks: 0, spoils: false,
    line: "Good to go — the work runs at its proper pace."
  };
}

/** Half, rounded up, is what a botch takes with it. */
export function spoilage(recipe) {
  const { parts } = parseRecipe(recipe ?? "");
  return parts
    .map(p => ({ name: p.material, lost: Math.ceil((Number(p.qty) || 0) / 2) }))
    .filter(p => p.lost > 0);
}

/* ------------------------------------------------------------------ */
/*  Hints                                                              */
/* ------------------------------------------------------------------ */

/**
 * Which research project mentions this item.
 *
 * Deliberately a HINT and never a gate. The research tree records what
 * each project unlocks as prose — "Longsword, Warhammer", "**The
 * Forge/Smelter**, smelting, plus Spear, Gladius, Ikwa, Axe, Mace" —
 * so finding the item means matching against that prose, and prose
 * matching is wrong often enough that it must never stop anybody doing
 * anything. It says "you probably want this researched", and the person
 * at the table decides.
 *
 * When recipes get entered as data this is replaced by a field on the
 * item, and then it can be a gate if that is wanted.
 */
export function researchHint(itemName) {
  if (!itemName) return null;
  const needle = itemName.trim().toLowerCase();
  if (needle.length < 3) return null;
  for (const p of PROJECTS) {
    const unlocks = String(p.unlocks ?? "").toLowerCase();
    // Word-boundary match, so "Axe" does not find "Battleaxe" and
    // "Bed" does not find "Bedroll".
    const re = new RegExp(`(^|[^a-z])${needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z]|$)`);
    if (re.test(unlocks)) return p;
  }
  return null;
}

/** Everything the bench can tell you about an item dropped on it. */
export function adviseOn(item, benchKind) {
  const wants = item?.system?.bench ?? "none";
  const tn = BENCH_TN[wants] ?? 0;
  const research = researchHint(item?.name);
  const notes = [];

  if (wants === "none") {
    notes.push("Needs no bench at all — this can be made anywhere.");
  } else if (benchKind && wants !== benchKind) {
    notes.push(`Wants ${BENCH_NAME[wants] ?? wants}, and this is ` +
               `${BENCH_NAME[benchKind] ?? benchKind}.`);
  }
  if (research) {
    notes.push(`Probably needs <b>${research.name}</b> researched — ${research.unlocks}`);
  }
  return { wants, tn, research, notes };
}
