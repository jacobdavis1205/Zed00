/**
 * Everything here is adjustable by the GM at runtime, in the Foundry
 * settings menu. No reinstall, no server access, no zip file.
 *
 * The rule of thumb: if a number might move after a few sessions at the
 * table, it lives here. If it's architecture, it lives in the data model.
 */

export const SETTINGS = "zed00";

export function registerSettings() {
  const reg = (key, name, hint, type, dflt, extra = {}) =>
    game.settings.register(SETTINGS, key, {
      name, hint, scope: "world", config: true, type, default: dflt, ...extra
    });

  /* ---------------- Strain ---------------- */

  reg("unstableFraction", "Unstable threshold",
      "Fraction of the Strain pool at which a character becomes Unstable. 0.5 is half.",
      Number, 0.5, { range: { min: 0.25, max: 1, step: 0.05 } });

  reg("unstablePenalty", "Unstable penalty",
      "Applied to checks while Unstable.", Number, -1);

  reg("strainPerDamage", "Strain per instance of damage",
      "Every instance of damage taken costs this much Strain. Shock counts; damage reduced to zero does not.",
      Number, 1);

  reg("pushLadder", "Push cost ladder",
      "Comma-separated Strain cost per use in a scene, for Warriors and Experts. Adventurers are shifted one step along.",
      String, "0,2,4,6");

  /* ---------------- Exposure ---------------- */

  reg("exposurePenalty1", "Exposure 1 penalty",
      "Applied to physical, labour and perception checks at Exposure 1.", Number, -1);

  reg("exposurePenalty2", "Exposure 2+ penalty",
      "Applied to all skill checks at Exposure 2 and above.", Number, -2);

  reg("exposureHpLoss3", "Exposure 3 max HP loss",
      "Fraction of maximum HP lost at Exposure 3.", Number, 0.25,
      { range: { min: 0, max: 0.5, step: 0.05 } });

  /* ---------------- Conditions ---------------- */

  reg("darknessPenalty", "Darkness penalty",
      "Applied to every skill except the talking ones when working in the dark.", Number, -2);

  reg("bloodiedPenalty", "Bloodied penalty",
      "Applied while at or below half hit points.", Number, -1);

  reg("multitaskPenalty", "Multitasking penalty",
      "Applied to both checks when a colonist takes two jobs in a week.", Number, -2);

  /* ---------------- Medicine ---------------- */

  reg("medicineNone", "Medicine — bare-handed", "Modifier with no supplies at all.", Number, -2);
  reg("medicineHerbal", "Medicine — Herbal", "", Number, 0);
  reg("medicineIndustrial", "Medicine — Industrial", "", Number, 1);
  reg("medicineGlitterworld", "Medicine — Glitterworld", "", Number, 2);

  reg("healingMultiplier", "Field treatment healing",
      "Hit points restored per character level, per medicine grade: Herbal, Industrial, Glitterworld.",
      String, "1,2,3");

  /* ---------------- Automation ---------------- */

  reg("autoApplyPenalties", "Apply condition penalties automatically",
      "When on, Exposure, Unstable, Bloodied and darkness are folded into rolls. Turn this off to apply them by hand at the table.",
      Boolean, true);

  reg("autoStrainOnDamage", "Apply Strain automatically on damage",
      "When on, taking damage costs Strain without asking.", Boolean, true);

  reg("autoDurabilitySave", "Prompt for Durability Saves",
      "When on, a natural 1 on an attack prompts a Durability Save for the weapon.", Boolean, true);

  /* ---------------- Colony ---------------- */

  reg("colonyYields", "Colony yield multipliers",
      "Output on a critical success, success, failure and critical failure.",
      String, "1.5,1,0.5,0");

  reg("bannerSize", "Colonists per Banner",
      "How many Roster colonists each player character manages.", Number, 4);

  reg("weekLength", "Days in a colony week", "", Number, 7);
}

/* ------------------------------------------------------------------ */

const get = k => game.settings.get(SETTINGS, k);
const list = k => String(get(k)).split(",").map(Number);

/** Read the live settings rather than hard-coded numbers. */
export const cfg = {
  get unstableFraction()  { return get("unstableFraction"); },
  get unstablePenalty()   { return get("unstablePenalty"); },
  get strainPerDamage()   { return get("strainPerDamage"); },
  get pushLadder()        { return list("pushLadder"); },
  get darknessPenalty()   { return get("darknessPenalty"); },
  get bloodiedPenalty()   { return get("bloodiedPenalty"); },
  get multitaskPenalty()  { return get("multitaskPenalty"); },
  get exposureHpLoss3()   { return get("exposureHpLoss3"); },
  get colonyYields()      { return list("colonyYields"); },
  get healingPerLevel()   { return list("healingMultiplier"); },
  get autoPenalties()     { return get("autoApplyPenalties"); },
  get autoStrain()        { return get("autoStrainOnDamage"); },
  get autoDurability()    { return get("autoDurabilitySave"); },
  get bannerSize()        { return get("bannerSize"); },

  medicine(grade) {
    return {
      none: get("medicineNone"),
      herbal: get("medicineHerbal"),
      industrial: get("medicineIndustrial"),
      glitterworld: get("medicineGlitterworld")
    }[grade] ?? 0;
  },

  exposurePenalty(level) {
    if (level <= 0) return 0;
    if (level === 1) return get("exposurePenalty1");
    return get("exposurePenalty2");
  }
};
