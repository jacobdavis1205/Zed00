/**
 * TL4 became Fabricated in v1.20.
 *
 * "TL4" was a leftover from Stars Without Number, and nothing else in
 * this game is measured in tech levels. The tier it names has a precise
 * definition here already: every one of the handbook's armour-piercing
 * weapons is built at a Fabrication Bench, with no exceptions. So the
 * bench is the tier, and the tier is now called what the bench makes.
 *
 * The flag moves from `system.tl4` to `system.fabricated`. A rename is
 * the kind of change that looks free and quietly resets a world, so the
 * old field is still in the schema for this release and gets copied
 * across on load. It comes out next release, once every world has been
 * through this once.
 */

export function pendingRename() {
  const out = [];
  const look = (doc) => {
    const s = doc.system ?? {};
    if (s.tl4 && !s.fabricated) out.push(doc);
  };
  for (const item of game.items ?? []) look(item);
  for (const actor of game.actors ?? []) {
    for (const item of actor.items ?? []) look(item);
  }
  for (const scene of game.scenes ?? []) {
    for (const token of scene.tokens ?? []) {
      if (token.actorLink) continue;            // counted through the actor
      for (const item of token.actor?.items ?? []) look(item);
    }
  }
  return out;
}

export async function migrateFabricated() {
  if (!game.user.isGM) return null;
  const pending = pendingRename();
  if (!pending.length) return { moved: 0 };

  // Grouped by parent, because one update per item on a large world is
  // a lot of round trips for a boolean.
  const byParent = new Map();
  for (const item of pending) {
    const key = item.parent ?? null;
    if (!byParent.has(key)) byParent.set(key, []);
    byParent.get(key).push({ _id: item.id, "system.fabricated": true, "system.tl4": false });
  }

  let moved = 0;
  for (const [parent, updates] of byParent) {
    try {
      if (parent) await parent.updateEmbeddedDocuments("Item", updates);
      else await Item.updateDocuments(updates);
      moved += updates.length;
    } catch (err) {
      console.error("zed00 | could not move TL4 flags on", parent?.name ?? "the sidebar", err);
    }
  }

  ui.notifications.info(
    `TL4 is called Fabricated now. ${moved} item${moved === 1 ? "" : "s"} moved over — ` +
    `nothing changed about what they do.`);
  return { moved };
}
