/**
 * Caravan logic: who is along, how fast they go, what they can carry,
 * and what one week on the road does.
 *
 * All of it comes out of the handbook's Travel & Movement rules. The
 * three that shape everything else:
 *
 *   - A caravan moves at its slowest member's pace. A cargo train cannot
 *     outrun its own cargo.
 *   - One Pilot check per week, not per day. The result governs the
 *     whole week.
 *   - Progress is cumulative miles, never hex by hex. Leftover miles
 *     always carry, because a week's roll rarely divides into 24.
 *
 * The roster is references to real actors, so nothing here copies a
 * Strength or an Enc onto the caravan where it could go stale.
 */

import { PACE, MILES_PER_HEX, FOOT_SPEED } from "./data/caravan.mjs";
import { currentDate } from "./dates.mjs";

export { PACE, MILES_PER_HEX, FOOT_SPEED };

const DialogV2 = foundry.applications.api.DialogV2;

/* ------------------------------------------------------------------ */
/*  The roster                                                         */
/* ------------------------------------------------------------------ */

/**
 * Resolve the roster into something the sheet can show.
 *
 * A member whose actor has been deleted comes back as a stub rather than
 * breaking the sheet — a caravan that outlives one of its animals should
 * still open.
 */
export async function readRoster(caravan) {
  const out = [];
  for (const entry of caravan.system.roster) {
    const actor = await fromUuid(entry.uuid).catch(() => null);
    if (!actor) {
      out.push({ uuid: entry.uuid, missing: true, name: "(gone)",
                 kind: "person", speed: 0, capacity: 0 });
      continue;
    }
    const animal = actor.type === "creature";
    const sys = actor.system ?? {};

    // An animal's speed and cargo are on its own stat block, straight
    // from the roster table. A person walks and carries what their
    // Strength allows.
    const speed = animal ? (Number(sys.speed) || 0) : FOOT_SPEED;

    // What a person brings to the caravan is their spare capacity, not
    // their whole limit. Somebody already lugging a rifle, armour and a
    // week of food cannot also shoulder 12 Enc of trade goods, and
    // counting their full Stowed limit was quietly inventing room that
    // does not exist.
    const limit = animal
      ? (Number(sys.cargo) || 0)
      : (Number(sys.encumbrance?.stowedMax) || Number(sys.attributes?.str?.value) || 0);
    const carried = animal ? 0 : Number(sys.encumbrance?.stowed) || 0;
    const capacity = Math.max(0, Math.round((limit - carried) * 10) / 10);

    out.push({
      uuid: entry.uuid,
      id: actor.id,
      name: actor.name,
      img: actor.img,
      kind: animal ? (Number(sys.cargo) >= 20 ? "pack" : "mount") : "person",
      animal,
      speed,
      capacity,
      limit,
      carried,
      // An animal with no travel speed is livestock, not transport.
      travels: !animal || speed > 0,
      temperament: sys.temperament ?? "",
      // Read off the stat block's Special column. "Mountain variant
      // ignores mountainous-terrain penalties" is a conditional on one
      // sub-type rather than a blanket immunity, so a line naming a
      // variant does not count.
      terrainImmune: (sys.special ?? []).some(
        s => /ignores\s+(rough|difficult|mountainous)?\s*terrain/i.test(s) &&
             !/variant/i.test(s)),
      mount: entry.mount,
      mountName: "",
      note: entry.note,
      actor
    });
  }
  // Fill in who is riding what, now that every name is known.
  const byUuid = new Map(out.map(m => [m.uuid, m]));
  for (const m of out) {
    if (m.mount) m.mountName = byUuid.get(m.mount)?.name ?? "";
  }
  return out;
}

/**
 * The caravan's pace: the slowest thing travelling with it.
 *
 * Livestock with no travel speed is skipped — a Woolpup in a crate is
 * cargo, not a member setting the pace. Anybody riding is moving at
 * their mount's speed rather than their own feet, which is the only way
 * a mount changes the number at all.
 */
export function paceOf(roster, { vessel = null } = {}) {
  if (vessel && vessel.kind !== "none") {
    return { speed: Number(vessel.speed) || FOOT_SPEED, by: "the boat", animals: [] };
  }

  const travelling = roster.filter(m => m.travels && !m.missing);
  if (!travelling.length) return { speed: FOOT_SPEED, by: "nobody", animals: [] };

  const mounted = new Set(roster.filter(m => m.mount).map(m => m.mount));

  // What each member actually moves at. A rider moves at their mount's
  // pace; an animal being ridden is already counted through its rider.
  const speeds = [];
  for (const m of travelling) {
    if (m.animal && mounted.has(m.uuid)) continue;      // counted via its rider
    if (m.mount) {
      const mount = roster.find(x => x.uuid === m.mount);
      speeds.push({ name: `${m.name} on ${mount?.name ?? "a mount"}`,
                    speed: mount?.speed || FOOT_SPEED });
    } else {
      speeds.push({ name: m.name, speed: m.speed || FOOT_SPEED });
    }
  }
  if (!speeds.length) return { speed: FOOT_SPEED, by: "nobody", animals: [] };

  speeds.sort((a, b) => a.speed - b.speed);
  const slowest = speeds[0];

  // Who the brake is, and what the pace would be without them. The
  // slowest-member rule is correct but silent: a Grandes pins a column
  // of Ridgehounds to 18 miles a day and nothing on the sheet said why,
  // or what leaving it behind would buy.
  const faster = speeds.filter(s => s.speed > slowest.speed);
  return {
    speed: slowest.speed,
    by: slowest.name,
    brake: slowest,
    without: faster.length ? faster[0].speed : slowest.speed,
    heldBack: faster.length > 0,
    animals: speeds
  };
}

/**
 * Does difficult ground actually cost this caravan anything?
 *
 * A Megasloth's stat block says it ignores rough terrain. That only
 * means something if the whole column can — one person on foot in a
 * marsh slows everybody, the same way one slow animal does.
 */
export function terrainBites(roster) {
  const travelling = roster.filter(m => m.travels && !m.missing);
  if (!travelling.length) return true;
  const mounted = new Set(roster.filter(m => m.mount).map(m => m.mount));
  for (const m of travelling) {
    if (m.animal && mounted.has(m.uuid)) continue;    // counted via its rider
    // A rider is carried over the bad ground by whatever they are on.
    if (m.mount) {
      const mount = roster.find(x => x.uuid === m.mount);
      if (!mount?.terrainImmune) return true;
    } else if (!m.terrainImmune) {
      return true;
    }
  }
  return false;
}

/** What the caravan can carry, and what it is actually carrying. */
export function holdOf(caravan, roster) {
  let capacity = 0;
  for (const m of roster) {
    if (m.missing) continue;
    // An animal being ridden carries its rider, not freight.
    const ridden = roster.some(x => x.mount === m.uuid);
    if (m.animal && ridden) continue;
    capacity += m.capacity;
  }
  const vessel = caravan.system.vessel;
  if (vessel.kind !== "none") {
    // A raft's capacity replaces legs, it does not add to them: what is
    // aboard is aboard. A passenger counts as 10 Enc, an animal as 30.
    const people = roster.filter(m => !m.animal && !m.missing).length;
    const animals = roster.filter(m => m.animal && !m.missing).length;
    capacity = Math.max(0, (Number(vessel.capacity) || 0) - people * 10 - animals * 30);
  }

  let load = 0;
  for (const i of caravan.items) {
    const s = i.system ?? {};
    if (s.encumbrance === undefined) continue;
    load += i.type === "ammo"
      ? (Number(s.bulk) || 0)
      : (Number(s.encumbrance) || 0) * (Number(s.quantity) || 0);
  }
  load = Math.round(load * 10) / 10;

  return {
    capacity: Math.round(capacity * 10) / 10,
    load,
    over: load > capacity,
    spare: Math.round((capacity - load) * 10) / 10,
    percent: capacity ? Math.min(100, Math.round((load / capacity) * 100)) : 0
  };
}

/**
 * Caravan Wealth, for gating what comes out of the hills at you.
 *
 * The same tier bands Colony Wealth uses, scoped to what is on the road.
 */
export const WEALTH_BANDS = [
  { tier: 0, upto: 500,   label: "Not worth robbing" },
  { tier: 1, upto: 2000,  label: "Worth a look" },
  { tier: 2, upto: 6000,  label: "Worth following" },
  { tier: 3, upto: 15000, label: "Worth planning for" },
  { tier: 4, upto: 40000, label: "Worth an ambush" },
  { tier: 5, upto: Infinity, label: "Worth a war party" }
];

export function wealthOf(caravan, roster) {
  // Cargo, priced the way everything else in this economy is priced.
  let cargo = 0;
  for (const i of caravan.items) {
    const buy = Number(i.system?.price?.buy) || 0;
    const qty = Number(i.system?.quantity) || 0;
    cargo += buy * (i.type === "ammo" ? qty / (Number(i.system.per) || 20) : qty);
  }
  // An animal is worth stealing on its own account.
  const animals = roster.filter(m => m.animal && !m.missing)
    .reduce((n, m) => n + (m.capacity >= 40 ? 300 : m.capacity >= 10 ? 200 : 100), 0);
  // Travellers bring their own kit, as a flat bump by best owned tier —
  // the same shape Colony Wealth already uses rather than a new formula.
  const people = roster.filter(m => !m.animal && !m.missing);
  const gear = people.reduce((n, m) => {
    const best = (m.actor?.items ?? []).reduce(
      (t, i) => Math.max(t, Number(i.system?.price?.buy) || 0), 0);
    return n + (best >= 3000 ? 1000 : best >= 800 ? 400 : best >= 200 ? 150 : 0);
  }, 0);

  const total = Math.round(cargo + animals + gear);
  const band = WEALTH_BANDS.find(b => total < b.upto) ?? WEALTH_BANDS.at(-1);
  return { total, cargo: Math.round(cargo), animals, gear, ...band };
}

/* ------------------------------------------------------------------ */
/*  A week on the road                                                 */
/* ------------------------------------------------------------------ */

/** Who takes the check: the nominated driver, else the best Pilot aboard. */
export function driverFor(caravan, roster) {
  const named = caravan.system.driverUuid
    ? roster.find(m => m.uuid === caravan.system.driverUuid)
    : null;
  if (named && !named.missing) return named;

  const people = roster.filter(m => !m.animal && !m.missing);
  let best = null, bestLevel = -2;
  for (const m of people) {
    const skill = (m.actor?.items ?? []).find(
      i => i.type === "skill" && /^pilot$/i.test(i.name));
    const level = Number(skill?.system?.level ?? -1);
    if (level > bestLevel) { bestLevel = level; best = m; }
  }
  return best;
}

/**
 * Work out a week's mileage from a Pilot result.
 *
 * Two rules bite here and both are easy to get wrong by hand. An
 * untrained handler never beats walking pace even on a success — Pilot
 * has to be invested for an animal to be worth more than your own two
 * feet. And difficult ground costs double its mileage, which is the same
 * thing as halving the pace.
 */
export function mileageFor({ result, pace, trained, difficult }) {
  const band = PACE[result] ?? PACE.success;

  // "Same as walking speed — no better than being on foot" is a ceiling,
  // not a fixed number. The rules table is written for somebody riding
  // something faster than they can walk, and reads as a penalty there.
  // Taken literally it is nonsense for a slow pack animal: a Grandes
  // makes 18 miles a day, and a fumbled check was making it 24, so
  // failing the roll was better than passing it.
  const onFoot = Math.min(pace, FOOT_SPEED);

  let perDay = band.walking ? onFoot : Math.round(pace * (band.factor ?? 1));

  // A fumble is "half the animal's normal speed", which on anything
  // faster than 48 comes out above a plain failure's walking pace — a
  // disobedient animal outrunning a good week on foot. Both bad results
  // share the same ceiling, so a worse roll is never a better week.
  if (band.ceiling) perDay = Math.min(perDay, onFoot);

  // "An untrained rider or handler never beats walking pace, even on a
  // success." Straight walking pace, not the caravan's own pace — so an
  // untrained handler who rolls a critical on a Grandes still gets 24,
  // more than the beast's ordinary 18. That reads oddly for a moment,
  // but it is what the sentence says and it never inverts the ordering:
  // a trained handler beats an untrained one at every result.
  const capped = !trained && perDay > FOOT_SPEED;
  if (capped) perDay = FOOT_SPEED;

  const total = perDay * 7;
  // Difficult ground costs twice the mileage, so the same week of
  // walking buys half the distance.
  const miles = difficult ? total / 2 : total;

  const made = Math.round(miles * 10) / 10;
  return {
    perDay, total,
    miles: made,
    // How many hexes that is. Counting hexes by hand from a mileage is
    // the one piece of arithmetic nobody should be doing at the table,
    // and on difficult ground it is already halved.
    hexes: Math.floor(made / MILES_PER_HEX),
    spare: Math.round((made % MILES_PER_HEX) * 10) / 10,
    capped,
    note: band.note +
          (capped ? " Held to a failed check's pace — the handler is untrained." : "") +
          (difficult ? " Difficult ground — half the distance for the same week." : "")
  };
}

/**
 * Seven daily interruption checks, 1d6 each, on a 1.
 *
 * Rolled here rather than left to the GM's memory because it is seven
 * dice a week and forgetting them is how a journey becomes a cutscene.
 * What actually happens is still the GM's call — this says which days
 * and how many.
 */
export async function interruptions({ trigger = 1 } = {}) {
  const roll = await new Roll("7d6").evaluate();
  const dice = roll.dice[0].results.map(r => r.result);
  const days = dice.map((v, i) => ({ day: i + 1, v, hit: v <= trigger }))
                   .filter(d => d.hit);
  return { dice, days, roll };
}

/**
 * Run one week of travel for a caravan.
 *
 * Rolls the Pilot check as the driver — the player holding that
 * character gets the roll, which is the point — then writes the mileage,
 * the log line and the chat card.
 */
export async function travelWeek(caravan, { trigger = 1 } = {}) {
  const roster = await readRoster(caravan);
  const driver = driverFor(caravan, roster);
  if (!driver) {
    ui.notifications.warn(
      "Nobody in the roster can take the Pilot check. Add a character first.");
    return null;
  }

  const pace = paceOf(roster, { vessel: caravan.system.vessel });
  const skill = (driver.actor.items ?? []).find(
    i => i.type === "skill" && /^pilot$/i.test(i.name));
  const level = Number(skill?.system?.level ?? -1);
  const trained = level >= 0;

  // Pilot is a Dex skill, and the week's pace is an ordinary check
  // against TN 8. The driver's player makes this roll.
  const check = await game.zed00.Dice.rollSkill(driver.actor, {
    skill, attribute: "dex", tn: 8, label: "Pilot — the week's pace"
  });

  const result = check.margin >= 4 ? "critical"
               : check.margin >= 0 ? "success"
               : check.margin <= -4 ? "critfail" : "failure";

  const rough = caravan.system.difficult && terrainBites(roster);
  const out = mileageFor({ result, pace: pace.speed, trained, difficult: rough });

  const before = Number(caravan.system.miles) || 0;
  const after = Math.round((before + out.miles) * 10) / 10;
  const date = currentDate();

  const crossed = Math.floor(after / MILES_PER_HEX) - Math.floor(before / MILES_PER_HEX);
  const interrupt = await interruptions({ trigger });

  const line = {
    week: date.week, date: date.label, driver: driver.name,
    result, total: out.total, perDay: out.perDay, miles: out.miles,
    note: out.note
  };

  await caravan.update({
    "system.miles": after,
    "system.log": [...caravan.system.log, line]
  });

  const arrived = caravan.system.distance > 0 && after >= caravan.system.distance;

  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor: caravan }),
    content: `<div class="zed00-card caravan-week">
      <header><strong>${caravan.name}</strong> — ${date.label}</header>
      <div class="meta">${driver.name} at the reins · ${PACE[result].label}</div>
      <div class="text">
        <b>${out.perDay} miles a day</b>, ${out.miles} this week.
        <span class="hint">${out.note}</span><br>
        Pace set by ${pace.by} at ${pace.speed} a day.<br>
        <b>Move the token up to ${out.hexes} hex${out.hexes === 1 ? "" : "es"}</b>${
          out.spare ? `, with ${out.spare} miles left over to carry` : ""}.
        ${crossed > 0
          ? `<span class="hint">That is ${crossed} more than last week's tally.</span> `
          : ""}<br>
        ${caravan.system.distance
          ? (arrived
              ? `<b>Arrived at ${caravan.system.destination || "the destination"}.</b>`
              : `${Math.round((caravan.system.distance - after) * 10) / 10} miles still to go.`)
          : `${after} miles out.`}
      </div>
      ${interrupt.days.length
        ? `<div class="text"><b>Interrupted on day${
            interrupt.days.length === 1 ? "" : "s"} ${
            interrupt.days.map(d => d.day).join(", ")}.</b>
           <span class="hint">Roll 1d6 for the category — 1-2 Environmental,
           3-4 Wildlife, 5 Hostile, 6 Mechanical. Read it against the hex
           they were actually in that day.</span></div>`
        : `<div class="text hint">Seven quiet days.</div>`}
      ${result === "critfail" || result === "failure"
        ? `<div class="text hint">A Failure or Critical Failure means any
           Hostile interruption this week is faced at Disadvantage.</div>`
        : ""}
    </div>`
  });

  if (arrived) {
    ui.notifications.info(
      `${caravan.name} has arrived at ${caravan.system.destination || "its destination"}.`);
  }
  return { ...out, result, after, crossed, interrupt };
}

/* ------------------------------------------------------------------ */

/** Make a caravan, pre-loaded with whoever is selected on the canvas. */
export async function createCaravan() {
  if (!game.user.isGM) return;
  const picked = (canvas?.tokens?.controlled ?? [])
    .map(t => t.actor)
    .filter(a => a && ["character", "colonist", "creature"].includes(a.type));

  const caravan = await Actor.create({
    name: picked.length ? `${picked[0].name}'s caravan` : "Caravan",
    type: "caravan",
    img: "icons/environment/settlement/wagon-cart-blue.webp",
    system: {
      roster: picked.map(a => ({ uuid: a.uuid, mount: "", note: "" })),
      origin: "The colony"
    },
    prototypeToken: { actorLink: true, width: 1, height: 1 }
  });

  caravan?.sheet?.render(true);
  if (picked.length) {
    ui.notifications.info(
      `Caravan made with ${picked.length} member${picked.length === 1 ? "" : "s"} ` +
      `from the selected tokens. Drop its token on the world map.`);
  }
  return caravan;
}
