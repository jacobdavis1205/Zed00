const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
import { ENC_PER_SQUARE } from "../data/structure.mjs";
import { currentDate } from "../week.mjs";
import { syncLights, isPinned } from "../structures.mjs";

export class Zed00StructureSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "structure"],
    position: { width: 560, height: 640 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      editImage:    Zed00StructureSheet.#editImage,
      editGood:     Zed00StructureSheet.#editGood,
      removeGood:   Zed00StructureSheet.#removeGood,
      togglePin:    Zed00StructureSheet.#togglePin,
      addAttack:    Zed00StructureSheet.#addAttack,
      removeAttack: Zed00StructureSheet.#removeAttack,
      rollAttack:   Zed00StructureSheet.#rollAttack,
      rollCrop:     Zed00StructureSheet.#rollCrop,
      harvest:      Zed00StructureSheet.#harvest,
      damage:       Zed00StructureSheet.#damage,
      repair:       Zed00StructureSheet.#repair
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/actor/structure.hbs" } };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const sys = this.document.system;
    ctx.actor = this.document;
    ctx.system = sys;
    ctx.editable = this.isEditable;
    ctx.encPerSquare = ENC_PER_SQUARE;
    ctx.week = currentDate().week;
    ctx.pinned = isPinned(this.document.prototypeToken) &&
                 isPinned(this.document.token ?? this.document.prototypeToken);

    // Which panels this structure needs.
    const f = sys.function;
    ctx.show = {
      stockpile: f === "stockpile",
      power: ["generator", "battery", "bench", "light", "climate", "turret", "recreation"].includes(f),
      turret: f === "turret",
      farm: f === "farm",
      bed: f === "bed",
      wall: f === "wall",
      light: f === "light" || sys.lit?.bright > 0 || sys.lit?.dim > 0
    };

    // What is actually in here. Goods are items the structure owns, so
    // they drag in off a character and drag back out again.
    ctx.goods = this.document.items.map(i => {
      const s = i.system ?? {};
      const qty = Number(s.quantity) || 0;
      const each = Number(s.encumbrance) || 0;
      const spoilsOn = Number(s.spoilsOn) || 0;
      return {
        id: i.id, name: i.name, img: i.img, type: i.type,
        quantity: qty,
        each,
        enc: Math.round(each * qty * 10) / 10,
        left: spoilsOn ? spoilsOn - ctx.week : null,
        expired: spoilsOn ? spoilsOn <= ctx.week : false,
        perishable: !!(Number(s.shelfLife) || 0)
      };
    }).sort((a, b) => b.enc - a.enc);

    ctx.spoiling = ctx.goods.filter(g => g.left !== null && g.left <= 1 && !g.expired);
    ctx.spoiled = ctx.goods.filter(g => g.expired);

    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(sys.description ?? "", { async: true });
    return ctx;
  }

  /** Footprint follows the token, so capacity follows the map. */
  async _onRender(context, options) {
    await super._onRender?.(context, options);

    // A placed token knows its own size; an unplaced one falls back to
    // the prototype. Either way the squares drive the capacity.
    const t = this.document.token ?? this.document.prototypeToken;
    const squares = Math.max(1, Math.round((t.width ?? 1) * (t.height ?? 1)));
    if (squares !== this.document.system.squares && this.isEditable) {
      await this.document.update({ "system.squares": squares }, { render: false });
    }

    const el = this.element;
    if (!el) return;

    // Drag goods in.
    el.addEventListener("dragover", ev => {
      ev.preventDefault();
      el.classList.add("drop-target");
    });
    el.addEventListener("dragleave", () => el.classList.remove("drop-target"));
    el.addEventListener("drop", ev => {
      el.classList.remove("drop-target");
      this.#onDrop(ev);
    });

    // And drag them back out, onto a character or another stockpile.
    for (const row of el.querySelectorAll("[data-good-id]")) {
      row.setAttribute("draggable", "true");
      row.addEventListener("dragstart", ev => {
        const item = this.document.items.get(row.dataset.goodId);
        if (!item) return;
        ev.dataTransfer.setData("text/plain", JSON.stringify({
          type: "Item", uuid: item.uuid
        }));
      });
    }
  }

  /**
   * Something was dropped on the sheet.
   *
   * Dragged off a character, the goods move — they leave the pack and
   * arrive in the shed, because that is what putting something away is.
   * Dragged in from a compendium, they are simply created.
   */
  async #onDrop(event) {
    event.preventDefault();
    if (!this.isEditable) return;

    const TE = foundry.applications.ux.TextEditor.implementation;
    let data;
    try { data = TE.getDragEventData(event); } catch { return; }
    if (data?.type !== "Item") return;

    const item = await fromUuid(data.uuid);
    if (!item) return;

    const sys = item.system ?? {};
    if (sys.encumbrance === undefined) {
      return ui.notifications.warn(`${item.name} is not something you can store.`);
    }
    if (this.document.system.function !== "stockpile") {
      return ui.notifications.warn(
        `${this.document.name} is not a stockpile. Goods go in a stockpile or a shelf.`);
    }

    const source = item.parent;
    if (source?.id === this.document.id) return;        // already here

    const qty = Number(sys.quantity) || 1;
    const each = Number(sys.encumbrance) || 0;
    const incoming = each * qty;
    if (incoming > this.document.system.spare) {
      ui.notifications.warn(
        `${this.document.name} has ${this.document.system.spare} Enc spare and that is ` +
        `${Math.round(incoming * 10) / 10}. Putting it in anyway — it is over capacity.`);
    }

    // Stamp the spoilage clock the moment it is put away.
    const shelf = Number(sys.shelfLife) || 0;
    const payload = item.toObject();
    delete payload._id;
    payload.system.stowed = true;
    payload.system.spoilsOn = shelf ? currentDate().week + shelf : 0;

    // Merge into a matching pile rather than making a second row.
    const match = this.document.items.find(i =>
      i.name === item.name && i.type === item.type &&
      (Number(i.system.spoilsOn) || 0) === (payload.system.spoilsOn || 0));

    if (match) {
      await match.update({ "system.quantity": (Number(match.system.quantity) || 0) + qty });
    } else {
      await this.document.createEmbeddedDocuments("Item", [payload]);
    }

    // If it came off somebody, it is no longer on them.
    if (source && source.id !== this.document.id && source.documentName === "Actor") {
      await item.delete();
    }

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${qty} × ${item.name}</strong> into ${this.document.name}` +
               (source?.documentName === "Actor" ? ` from ${source.name}` : "") + "."
    });
  }

  static async #editGood(event, target) {
    this.document.items.get(target.closest("[data-good-id]")?.dataset.goodId)
      ?.sheet.render(true);
  }

  static async #removeGood(event, target) {
    const id = target.closest("[data-good-id]")?.dataset.goodId;
    await this.document.items.get(id)?.delete();
  }

  /** Let the GM shove a building two squares left without unpinning it twice. */
  static async #togglePin() {
    const token = this.document.token ?? this.document.prototypeToken;
    const now = isPinned(token);
    await token.setFlag("zed00", "pinned", !now);
    ui.notifications.info(now
      ? `${this.document.name} unpinned — you can move it now.`
      : `${this.document.name} pinned in place.`);
    this.render();
  }

  static async #editImage() {
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image", current: this.document.img,
      callback: path => this.document.update({ img: path })
    });
    return fp.browse();
  }

  /** Shelf lives, in weeks. Cooking is what resets the clock. */
  static SHELF = {
    "animal product": 1, "raw food": 1,
    "edible plant product": 4, "plant product": 4,
    "simple meal": 4, "fine meal": 4, "lavish meal": 4,
    "preserved food": 0
  };

  static async #addAttack() {
    await this.document.update({ "system.attacks":
      [...this.document.system.attacks,
       { name: "Turret", bonus: 2, damage: "1d8", count: 1, shock: 0, shockAC: 0, range: "", note: "" }] });
  }

  static async #removeAttack(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.attacks":
      this.document.system.attacks.filter((_, n) => n !== i) });
  }

  static async #rollAttack(event, target) {
    const atk = this.document.system.attacks[Number(target.dataset.index)];
    if (!atk) return;
    if (!this.document.system.working) {
      return ui.notifications.warn(`${this.document.name} is not working.`);
    }
    const t = Array.from(game.user.targets)[0];
    const ac = t ? (t.actor?.system?.armorClass ?? t.actor?.system?.ac ?? 10) : null;
    const roll = await new Roll(`1d20 + ${atk.bonus}`).evaluate();
    const hit = ac === null ? null : roll.total >= ac;
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>${atk.name}</strong>` +
        (t ? ` vs ${t.name} (AC ${ac}) — <em>${hit ? "Hit" : "Miss"}</em>` : "") +
        `<div class="zed00-detail">
          <button class="zed00-damage" data-formula="${atk.damage}" data-label="${atk.name}">
            Roll damage — ${atk.damage}</button>
          ${atk.shock ? `<br>Shock ${atk.shock} vs AC ${atk.shockAC}` : ""}
        </div>`
    });
  }

  /** One of the four weekly checks before a harvest. */
  static async #rollCrop() {
    const sys = this.document.system;
    if (sys.crop.lost) return ui.notifications.warn("That crop is already lost.");
    if (sys.crop.checks >= 4) return ui.notifications.info("Ready to harvest.");

    const farmer = game.user.character;
    const skill = farmer?.items?.find(i => i.type === "skill" && i.name === "Survive");
    const { margin } = await game.zed00.Dice.rollSkill(farmer ?? this.document, {
      skill, attribute: "wis", tn: 8, label: `${this.document.name} — week ${sys.crop.checks + 1} of 4`
    });

    const step = margin >= 4 ? 1 : margin >= 0 ? 0 : margin <= -4 ? -2 : -1;
    const failures = sys.crop.failures + (margin <= -4 ? 1 : 0);
    const lost = failures >= 2;

    await this.document.update({
      "system.crop.checks": sys.crop.checks + 1,
      "system.crop.steps": sys.crop.steps + step,
      "system.crop.failures": failures,
      "system.crop.lost": lost
    });

    if (lost) {
      ChatMessage.create({ content:
        `<strong>${this.document.name}</strong> — the crop is lost. Blight, rot, or a hard frost.` });
    }
  }

  /** Bring the harvest in and clear the field. */
  static async #harvest() {
    const sys = this.document.system;
    if (!sys.crop.ready) return ui.notifications.warn("Not ready. Four weekly checks first.");
    const amount = sys.crop.projected;
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${this.document.name}</strong> brings in <b>${amount}</b> ` +
               `${sys.crop.name || "plant product"} — ${Math.round(sys.crop.multiplier * 100)}% of the listed yield.`
    });
    await this.document.update({
      "system.crop.checks": 0, "system.crop.steps": 0,
      "system.crop.failures": 0, "system.crop.lost": false
    });
  }

  static async #damage(event, target) {
    const n = Number(target.dataset.amount ?? 5);
    const sys = this.document.system;
    const hp = Math.max(0, sys.health.value - n);
    const frac = sys.health.max ? hp / sys.health.max : 0;
    const cond = hp <= 0 ? "destroyed" : frac <= 0.25 ? "broken" : frac <= 0.6 ? "damaged" : "pristine";
    await this.document.update({ "system.health.value": hp, "system.condition": cond });
    await syncLights(this.document);          // a wrecked lamp stops glowing
  }

  static async #repair() {
    const sys = this.document.system;
    if (sys.condition === "destroyed") {
      return ui.notifications.warn("Destroyed. Rebuild it rather than repairing it.");
    }
    await this.document.update({
      "system.health.value": sys.health.max, "system.condition": "pristine" });
    await syncLights(this.document);
  }
}
