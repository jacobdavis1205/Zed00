const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
import { UNITS_PER_SQUARE } from "../data/structure.mjs";
import { currentDate } from "../week.mjs";

export class Zed00StructureSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "structure"],
    position: { width: 560, height: 640 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      editImage:    Zed00StructureSheet.#editImage,
      addBatch:     Zed00StructureSheet.#addBatch,
      removeBatch:  Zed00StructureSheet.#removeBatch,
      addAttack:    Zed00StructureSheet.#addAttack,
      removeAttack: Zed00StructureSheet.#removeAttack,
      rollAttack:   Zed00StructureSheet.#rollAttack,
      rollCrop:     Zed00StructureSheet.#rollCrop,
      harvest:      Zed00StructureSheet.#harvest,
      damage:       Zed00StructureSheet.#damage,
      repair:       Zed00StructureSheet.#repair
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/actor/structure.hbs" } };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const sys = this.document.system;
    ctx.actor = this.document;
    ctx.system = sys;
    ctx.editable = this.isEditable;
    ctx.unitsPerSquare = UNITS_PER_SQUARE;
    ctx.week = currentDate().week;

    // Which panels this structure needs.
    const f = sys.function;
    ctx.show = {
      stockpile: f === "stockpile",
      power: ["generator", "battery", "bench", "light", "climate", "turret", "recreation"].includes(f),
      turret: f === "turret",
      farm: f === "farm",
      bed: f === "bed"
    };

    // Batches, with how long each has left.
    ctx.batches = (sys.contents ?? []).map((b, i) => ({
      ...b, index: i,
      left: b.spoils ? b.spoils - ctx.week : null,
      expired: b.spoils ? b.spoils <= ctx.week : false
    }));

    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(sys.description ?? "", { async: true });
    return ctx;
  }

  /** Footprint follows the token, so capacity follows the map. */
  async _onRender(context, options) {
    await super._onRender?.(context, options);
    const t = this.document.prototypeToken;
    const squares = Math.max(1, Math.round((t.width ?? 1) * (t.height ?? 1)));
    if (squares !== this.document.system.squares && this.isEditable) {
      await this.document.update({ "system.squares": squares }, { render: false });
    }
  }

  static async #editImage() {
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image", current: this.document.img,
      callback: path => this.document.update({ img: path })
    });
    return fp.browse();
  }

  /** Shelf lives, in weeks. Cooking is what resets the clock. */
  static SHELF = {
    "animal product": 1, "raw food": 1,
    "edible plant product": 4, "plant product": 4,
    "simple meal": 4, "fine meal": 4, "lavish meal": 4,
    "preserved food": 0
  };

  static async #addBatch() {
    const week = currentDate().week;
    await this.document.update({ "system.contents":
      [...this.document.system.contents, { name: "", units: 0, spoils: 0 }] });
  }

  static async #removeBatch(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.contents":
      this.document.system.contents.filter((_, n) => n !== i) });
  }

  static async #addAttack() {
    await this.document.update({ "system.attacks":
      [...this.document.system.attacks,
       { name: "Turret", bonus: 2, damage: "1d8", count: 1, shock: 0, shockAC: 0, range: "", note: "" }] });
  }

  static async #removeAttack(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.attacks":
      this.document.system.attacks.filter((_, n) => n !== i) });
  }

  static async #rollAttack(event, target) {
    const atk = this.document.system.attacks[Number(target.dataset.index)];
    if (!atk) return;
    if (!this.document.system.working) {
      return ui.notifications.warn(`${this.document.name} is not working.`);
    }
    const t = Array.from(game.user.targets)[0];
    const ac = t ? (t.actor?.system?.armorClass ?? t.actor?.system?.ac ?? 10) : null;
    const roll = await new Roll(`1d20 + ${atk.bonus}`).evaluate();
    const hit = ac === null ? null : roll.total >= ac;
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>${atk.name}</strong>` +
        (t ? ` vs ${t.name} (AC ${ac}) — <em>${hit ? "Hit" : "Miss"}</em>` : "") +
        `<div class="zed00-detail">
          <button class="zed00-damage" data-formula="${atk.damage}" data-label="${atk.name}">
            Roll damage — ${atk.damage}</button>
          ${atk.shock ? `<br>Shock ${atk.shock} vs AC ${atk.shockAC}` : ""}
        </div>`
    });
  }

  /** One of the four weekly checks before a harvest. */
  static async #rollCrop() {
    const sys = this.document.system;
    if (sys.crop.lost) return ui.notifications.warn("That crop is already lost.");
    if (sys.crop.checks >= 4) return ui.notifications.info("Ready to harvest.");

    const farmer = game.user.character;
    const skill = farmer?.items?.find(i => i.type === "skill" && i.name === "Survive");
    const { margin } = await game.zed00.Dice.rollSkill(farmer ?? this.document, {
      skill, attribute: "wis", tn: 8, label: `${this.document.name} — week ${sys.crop.checks + 1} of 4`
    });

    const step = margin >= 4 ? 1 : margin >= 0 ? 0 : margin <= -4 ? -2 : -1;
    const failures = sys.crop.failures + (margin <= -4 ? 1 : 0);
    const lost = failures >= 2;

    await this.document.update({
      "system.crop.checks": sys.crop.checks + 1,
      "system.crop.steps": sys.crop.steps + step,
      "system.crop.failures": failures,
      "system.crop.lost": lost
    });

    if (lost) {
      ChatMessage.create({ content:
        `<strong>${this.document.name}</strong> — the crop is lost. Blight, rot, or a hard frost.` });
    }
  }

  /** Bring the harvest in and clear the field. */
  static async #harvest() {
    const sys = this.document.system;
    if (!sys.crop.ready) return ui.notifications.warn("Not ready. Four weekly checks first.");
    const amount = sys.crop.projected;
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${this.document.name}</strong> brings in <b>${amount}</b> ` +
               `${sys.crop.name || "plant product"} — ${Math.round(sys.crop.multiplier * 100)}% of the listed yield.`
    });
    await this.document.update({
      "system.crop.checks": 0, "system.crop.steps": 0,
      "system.crop.failures": 0, "system.crop.lost": false
    });
  }

  static async #damage(event, target) {
    const n = Number(target.dataset.amount ?? 5);
    const sys = this.document.system;
    const hp = Math.max(0, sys.health.value - n);
    const order = ["pristine", "damaged", "broken", "destroyed"];
    const frac = sys.health.max ? hp / sys.health.max : 0;
    const cond = hp <= 0 ? "destroyed" : frac <= 0.25 ? "broken" : frac <= 0.6 ? "damaged" : "pristine";
    await this.document.update({ "system.health.value": hp, "system.condition": cond });
  }

  static async #repair() {
    const sys = this.document.system;
    if (sys.condition === "destroyed") {
      return ui.notifications.warn("Destroyed. Rebuild it rather than repairing it.");
    }
    await this.document.update({
      "system.health.value": sys.health.max, "system.condition": "pristine" });
  }
}
