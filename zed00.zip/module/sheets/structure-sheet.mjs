const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
import { ENC_PER_SQUARE } from "../data/structure.mjs";
import { currentDate } from "../week.mjs";
import { syncLights, isPinned } from "../structures.mjs";
import { bindInlineItemFields } from "../inline-edit.mjs";

export class Zed00StructureSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "structure"],
    position: { width: 560, height: 640 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      editImage:    Zed00StructureSheet.#editImage,
      editGood:     Zed00StructureSheet.#editGood,
      removeGood:   Zed00StructureSheet.#removeGood,
      togglePin:    Zed00StructureSheet.#togglePin,
      addAttack:    Zed00StructureSheet.#addAttack,
      reloadTurret: Zed00StructureSheet.#reloadTurret,
      removeAttack: Zed00StructureSheet.#removeAttack,
      rollAttack:   Zed00StructureSheet.#rollAttack,
      rollCrop:     Zed00StructureSheet.#rollCrop,
      recordCrop:   Zed00StructureSheet.#recordCrop,
      undoCrop:     Zed00StructureSheet.#undoCrop,
      killCrop:     Zed00StructureSheet.#killCrop,
      harvest:      Zed00StructureSheet.#harvest,
      damage:       Zed00StructureSheet.#damage,
      repair:       Zed00StructureSheet.#repair
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/actor/structure.hbs" } };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const sys = this.document.system;
    ctx.actor = this.document;
    ctx.system = sys;
    ctx.editable = this.isEditable;
    ctx.encPerSquare = ENC_PER_SQUARE;
    ctx.week = currentDate().week;
    ctx.pinned = isPinned(this.document.prototypeToken) &&
                 isPinned(this.document.token ?? this.document.prototypeToken);

    // Which panels this structure needs.
    const f = sys.function;
    ctx.show = {
      stockpile: f === "stockpile",
      power: ["generator", "battery", "bench", "light", "climate", "turret", "recreation"].includes(f),
      turret: f === "turret",
      farm: f === "farm",
      bed: f === "bed",
      wall: f === "wall",
      light: f === "light" || sys.lit?.bright > 0 || sys.lit?.dim > 0
    };

    // What is actually in here. Goods are items the structure owns, so
    // they drag in off a character and drag back out again.
    ctx.goods = this.document.items.map(i => {
      const s = i.system ?? {};
      const qty = Number(s.quantity) || 0;
      const each = Number(s.encumbrance) || 0;
      const spoilsOn = Number(s.spoilsOn) || 0;
      return {
        id: i.id, name: i.name, img: i.img, type: i.type,
        quantity: qty,
        each,
        enc: Math.round(each * qty * 10) / 10,
        left: spoilsOn ? spoilsOn - ctx.week : null,
        expired: spoilsOn ? spoilsOn <= ctx.week : false,
        perishable: !!(Number(s.shelfLife) || 0)
      };
    }).sort((a, b) => b.enc - a.enc);

    ctx.spoiling = ctx.goods.filter(g => g.left !== null && g.left <= 1 && !g.expired);
    ctx.spoiled = ctx.goods.filter(g => g.expired);

    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(sys.description ?? "", { async: true });
    return ctx;
  }

  /** Footprint follows the token, so capacity follows the map. */
  async _onRender(context, options) {
    await super._onRender?.(context, options);

    // A placed token knows its own size; an unplaced one falls back to
    // the prototype. Either way the squares drive the capacity.
    const t = this.document.token ?? this.document.prototypeToken;
    const squares = Math.max(1, Math.round((t.width ?? 1) * (t.height ?? 1)));
    if (squares !== this.document.system.squares && this.isEditable) {
      await this.document.update({ "system.squares": squares }, { render: false });
    }

    const el = this.element;
    if (!el) return;

    // Every render used to bolt another set of listeners onto the same
    // element, so by the fifth render one drop fired five times and five
    // lots of steel appeared. Tear the old ones down first.
    this.#listeners?.abort();
    this.#listeners = new AbortController();
    const { signal } = this.#listeners;

    // Drag goods in.
    el.addEventListener("dragover", ev => {
      ev.preventDefault();
      el.classList.add("drop-target");
    }, { signal });
    el.addEventListener("dragleave", () => el.classList.remove("drop-target"), { signal });
    el.addEventListener("drop", ev => {
      el.classList.remove("drop-target");
      this.#onDrop(ev);
    }, { signal });

    // And drag them back out, onto a character or another stockpile.
    for (const row of el.querySelectorAll("[data-good-id]")) {
      row.setAttribute("draggable", "true");
      row.addEventListener("dragstart", ev => {
        const item = this.document.items.get(row.dataset.goodId);
        if (!item) return;
        ev.dataTransfer.setData("text/plain", JSON.stringify({
          type: "Item", uuid: item.uuid
        }));
      }, { signal });
    }

    // Quantities are written straight onto the goods, outside the form.
    bindInlineItemFields(el, this.document, signal);
  }

  /** Teardown handle for this render's listeners. */
  #listeners;

  /** The last drop acted on, so the same one is never banked twice. */
  #lastDrop = { key: "", at: 0 };

  /**
   * Something was dropped on the sheet.
   *
   * Dragged off a character, the goods move — they leave the pack and
   * arrive in the shed, because that is what putting something away is.
   * Dragged in from a compendium, they are simply created.
   *
   * Both this and Foundry's own sheet drop handling can see the same
   * event, which is how one sack of steel became two. Rather than guess
   * which handler is in play, the same drop is only ever banked once:
   * identical payloads inside half a second are the same gesture.
   */
  async _onDrop(event) {
    return this.#onDrop(event);
  }

  async #onDrop(event) {
    event.preventDefault();
    if (!this.isEditable) return;

    const TE = foundry.applications.ux.TextEditor.implementation;
    let data;
    try { data = TE.getDragEventData(event); } catch { return; }
    if (data?.type !== "Item") return;

    const key = data.uuid ?? JSON.stringify(data);
    const now = Date.now();
    if (this.#lastDrop.key === key && now - this.#lastDrop.at < 500) return;
    this.#lastDrop = { key, at: now };

    await this.#deposit(data);
  }

  async #deposit(data) {

    const item = await fromUuid(data.uuid);
    if (!item) return;

    const sys = item.system ?? {};
    if (sys.encumbrance === undefined) {
      return ui.notifications.warn(`${item.name} is not something you can store.`);
    }
    if (this.document.system.function !== "stockpile") {
      return ui.notifications.warn(
        `${this.document.name} is not a stockpile. Goods go in a stockpile or a shelf.`);
    }

    const source = item.parent;
    if (source?.id === this.document.id) return;        // already here

    const qty = Number(sys.quantity) || 1;
    const each = Number(sys.encumbrance) || 0;
    const incoming = each * qty;
    if (incoming > this.document.system.spare) {
      ui.notifications.warn(
        `${this.document.name} has ${this.document.system.spare} Enc spare and that is ` +
        `${Math.round(incoming * 10) / 10}. Putting it in anyway — it is over capacity.`);
    }

    // Stamp the spoilage clock the moment it is put away.
    const shelf = Number(sys.shelfLife) || 0;
    const payload = item.toObject();
    delete payload._id;
    payload.system.stowed = true;
    payload.system.spoilsOn = shelf ? currentDate().week + shelf : 0;

    // Merge into a matching pile rather than making a second row.
    const match = this.document.items.find(i =>
      i.name === item.name && i.type === item.type &&
      (Number(i.system.spoilsOn) || 0) === (payload.system.spoilsOn || 0));

    if (match) {
      await match.update({ "system.quantity": (Number(match.system.quantity) || 0) + qty });
    } else {
      await this.document.createEmbeddedDocuments("Item", [payload]);
    }

    // If it came off somebody, it is no longer on them.
    if (source && source.id !== this.document.id && source.documentName === "Actor") {
      await item.delete();
    }

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${qty} × ${item.name}</strong> into ${this.document.name}` +
               (source?.documentName === "Actor" ? ` from ${source.name}` : "") + "."
    });
  }

  static async #editGood(event, target) {
    this.document.items.get(target.closest("[data-good-id]")?.dataset.goodId)
      ?.sheet.render(true);
  }

  static async #removeGood(event, target) {
    const id = target.closest("[data-good-id]")?.dataset.goodId;
    await this.document.items.get(id)?.delete();
  }

  /** Let the GM shove a building two squares left without unpinning it twice. */
  static async #togglePin() {
    const token = this.document.token ?? this.document.prototypeToken;
    const now = isPinned(token);
    await token.setFlag("zed00", "pinned", !now);
    ui.notifications.info(now
      ? `${this.document.name} unpinned — you can move it now.`
      : `${this.document.name} pinned in place.`);
    this.render();
  }

  static async #editImage() {
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image", current: this.document.img,
      callback: path => this.document.update({ img: path })
    });
    return fp.browse();
  }

  /** Shelf lives, in weeks. Cooking is what resets the clock. */
  static SHELF = {
    "animal product": 1, "raw food": 1,
    "edible plant product": 4, "plant product": 4,
    "simple meal": 4, "fine meal": 4, "lavish meal": 4,
    "preserved food": 0
  };

  static async #addAttack() {
    await this.document.update({ "system.attacks":
      [...this.document.system.attacks,
       { name: "Turret", bonus: 2, damage: "1d8", count: 1, shock: 0, shockAC: 0, range: "", note: "" }] });
  }

  static async #removeAttack(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.attacks":
      this.document.system.attacks.filter((_, n) => n !== i) });
  }

  static async #rollAttack(event, target) {
    const sys = this.document.system;
    const atk = sys.attacks[Number(target.dataset.index)];
    if (!atk) return;
    if (!sys.working) {
      return ui.notifications.warn(`${this.document.name} is not working.`);
    }
    if (sys.dry) {
      return ui.notifications.warn(
        `${this.document.name} is out of ${sys.ammo.type} ammunition. Reload it from a stockpile.`);
    }

    // A belt-fed turret spends rounds whether or not it connects.
    if (sys.tracksAmmo) {
      const spend = sys.ammo.perShot * (atk.count || 1);
      await this.document.update({
        "system.ammo.loaded": Math.max(0, sys.ammo.loaded - spend) });
    }

    const t = Array.from(game.user.targets)[0];
    const ac = t ? (t.actor?.system?.armorClass ?? t.actor?.system?.ac ?? 10) : null;
    const roll = await new Roll(`1d20 + ${atk.bonus}`).evaluate();
    const hit = ac === null ? null : roll.total >= ac;
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>${atk.name}</strong>` +
        (t ? ` vs ${t.name} (AC ${ac}) — <em>${hit ? "Hit" : "Miss"}</em>` : "") +
        `<div class="zed00-detail">
          <button class="zed00-damage" data-formula="${atk.damage}" data-label="${atk.name}">
            Roll damage — ${atk.damage}</button>
          ${atk.shock ? `<br>Shock ${atk.shock} vs AC ${atk.shockAC}` : ""}
        </div>` +
        (this.document.system.tracksAmmo
          ? `<div class="zed00-ammo">${this.document.system.ammoNote}</div>` : "")
    });
  }

  /**
   * Feed the turret out of a stockpile.
   *
   * Looks through every stockpile for ammunition matching this turret's
   * type and takes what it needs off the top of the nearest full one. No
   * ammunition anywhere means the turret stays dry — which is the point
   * of making it eat something.
   */
  static async #reloadTurret() {
    const sys = this.document.system;
    if (!sys.tracksAmmo) {
      return ui.notifications.info(`${this.document.name} feeds itself — nothing to reload.`);
    }
    const need = sys.ammo.magazine - sys.ammo.loaded;
    if (need <= 0) return ui.notifications.info("Already full.");

    const wanted = sys.ammo.type.trim().toLowerCase();
    const piles = game.actors.filter(a =>
      a.type === "structure" && a.system.function === "stockpile");

    let taken = 0;
    for (const pile of piles) {
      if (taken >= need) break;
      for (const good of pile.items) {
        if (taken >= need) break;
        const name = good.name.trim().toLowerCase();
        if (!name.includes(wanted) && !wanted.includes(name)) continue;
        const have = Number(good.system.quantity) || 0;
        if (have <= 0) continue;
        const grab = Math.min(have, need - taken);
        taken += grab;
        if (grab >= have) await good.delete();
        else await good.update({ "system.quantity": have - grab });
      }
    }

    if (!taken) {
      return ui.notifications.warn(
        `No ${sys.ammo.type} ammunition in any stockpile.`);
    }
    await this.document.update({ "system.ammo.loaded": sys.ammo.loaded + taken });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `Loaded <strong>${taken} ${sys.ammo.type}</strong> — ` +
               `${sys.ammo.loaded + taken} / ${sys.ammo.magazine}.` +
               (taken < need ? ` <span class="hint">Stores ran short.</span>` : "")
    });
  }

  /**
   * Who is working this field?
   *
   * Target a token and it is them. Otherwise whatever is selected, then
   * whatever character the user owns. A GM running the colony has no
   * assigned character, which is why this button used to do nothing at
   * all — it was rolling a Survive check on the field itself.
   */
  #farmer() {
    const targeted = [...(game.user.targets ?? [])][0]?.actor;
    if (targeted) return targeted;
    const selected = canvas?.tokens?.controlled
      ?.map(t => t.actor)
      .find(a => a && a.type !== "structure");
    if (selected) return selected;
    return game.user.character ?? null;
  }

  /** One of the four weekly checks before a harvest. */
  static async #rollCrop() {
    const sys = this.document.system;
    if (sys.crop.lost) return ui.notifications.warn("That crop is already lost.");
    if (sys.crop.checks >= 4) return ui.notifications.info("Ready to harvest.");

    const farmer = this.#farmer();
    if (!farmer) {
      return ui.notifications.warn(
        "Target the colonist working this field — or select their token — then tend it.");
    }

    const skill = farmer.items?.find(i => i.type === "skill" && i.name === "Survive");
    let margin;
    try {
      ({ margin } = await game.zed00.Dice.rollSkill(farmer, {
        skill, attribute: "wis", tn: 8,
        label: `${this.document.name} — week ${sys.crop.checks + 1} of 4, tended by ${farmer.name}`
      }));
    } catch (err) {
      console.error("Zed-00 | tend field:", err);
      return ui.notifications.error(
        `${farmer.name} could not make that check — see the console. ` +
        `You can set the weeks and steps by hand on the sheet.`);
    }

    const outcome = margin >= 4 ? "crit" : margin >= 0 ? "pass"
                  : margin <= -4 ? "critfail" : "fail";
    await this.#recordWeek(outcome);
  }

  /**
   * Write one week's outcome onto the field.
   *
   * The four outcomes are the readable unit here, not the steps they
   * happen to move. A GM fixing a misclick should be able to say "that
   * was a critical success" rather than work out that it means +1 step.
   */
  async #recordWeek(outcome) {
    const sys = this.document.system;
    const STEP = { crit: 1, pass: 0, fail: -1, critfail: -2 };
    const step = STEP[outcome] ?? 0;
    const failures = sys.crop.failures + (outcome === "critfail" ? 1 : 0);
    const lost = failures >= 2;

    await this.document.update({
      "system.crop.checks": Math.min(4, sys.crop.checks + 1),
      "system.crop.steps": sys.crop.steps + step,
      "system.crop.failures": failures,
      "system.crop.lost": lost
    });

    if (lost) {
      ChatMessage.create({ content:
        `<strong>${this.document.name}</strong> — the crop is lost. Blight, rot, or a hard frost.` });
    }
  }

  /** The same four outcomes, recorded by hand. */
  static async #recordCrop(event, target) {
    const sys = this.document.system;
    if (sys.crop.lost) return ui.notifications.warn("That crop is already lost.");
    if (sys.crop.checks >= 4) return ui.notifications.info("Four weeks already tended.");
    await this.#recordWeek(target.dataset.outcome);
  }

  /** Undo the last week, for when a button was pressed by mistake. */
  static async #undoCrop() {
    const sys = this.document.system;
    if (sys.crop.checks <= 0 && !sys.crop.lost) {
      return ui.notifications.info("Nothing to undo.");
    }
    await this.document.update({
      "system.crop.checks": Math.max(0, sys.crop.checks - 1),
      "system.crop.lost": false
    });
    ui.notifications.info(
      "Dropped a week. Steps and critical failures are left alone — set those " +
      "by hand if the week you removed changed them.");
  }

  /** Kill it outright. */
  static async #killCrop() {
    await this.document.update({ "system.crop.lost": true });
  }

  /** Bring the harvest in and clear the field. */
  static async #harvest() {
    const sys = this.document.system;
    if (!sys.crop.ready) return ui.notifications.warn("Not ready. Four weekly checks first.");
    const amount = sys.crop.projected;
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${this.document.name}</strong> brings in <b>${amount}</b> ` +
               `${sys.crop.name || "plant product"} — ${Math.round(sys.crop.multiplier * 100)}% of the listed yield.`
    });
    await this.document.update({
      "system.crop.checks": 0, "system.crop.steps": 0,
      "system.crop.failures": 0, "system.crop.lost": false
    });
  }

  static async #damage(event, target) {
    const n = Number(target.dataset.amount ?? 5);
    const sys = this.document.system;
    const hp = Math.max(0, sys.health.value - n);
    const frac = sys.health.max ? hp / sys.health.max : 0;
    const cond = hp <= 0 ? "destroyed" : frac <= 0.25 ? "broken" : frac <= 0.6 ? "damaged" : "pristine";
    await this.document.update({ "system.health.value": hp, "system.condition": cond });
    await syncLights(this.document);          // a wrecked lamp stops glowing
  }

  /**
   * Patch it up, and say what that should cost.
   *
   * Nothing is deducted automatically — the colony's books are the
   * players' job, as they are for everything else. But a repair that
   * quietly costs nothing is a repair nobody budgets for, so the cost
   * goes to chat the way a harvest does.
   */
  static async #repair() {
    const sys = this.document.system;
    if (sys.condition === "destroyed") {
      return ui.notifications.warn("Destroyed. Rebuild it rather than repairing it.");
    }
    if (sys.health.value >= sys.health.max) {
      return ui.notifications.info(`${this.document.name} is already sound.`);
    }

    const missing = sys.health.max - sys.health.value;
    const share = sys.health.max ? missing / sys.health.max : 0;
    const bill = repairBill(sys.build.materials, share);

    await this.document.update({
      "system.health.value": sys.health.max, "system.condition": "pristine" });
    await syncLights(this.document);

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content:
        `<div class="zed00-roll"><h3>${this.document.name} repaired</h3>` +
        `<p>${missing} hit points back, from ${Math.round(share * 100)}% damaged.</p>` +
        (bill
          ? `<p><strong>Materials:</strong> ${bill}</p>`
          : `<p><strong>Materials:</strong> the build cost is not recorded — ` +
            `charge a share of whatever it took to put up.</p>`) +
        `<p class="hint">Nothing has been taken out of your stores. Deduct it yourself.</p>` +
        `</div>`
    });
  }
}

/**
 * A share of the original build cost, rounded up.
 *
 * Repairing half a wrecked bench should cost about half a bench. The
 * build cost is free text — "30 Metal, 10 Basic Components" — so pull the
 * numbers out, scale them, and put the string back together.
 */
function repairBill(materials, share) {
  if (!materials) return "";
  const parts = materials.split(",").map(chunk => {
    const m = chunk.trim().match(/^(\d+)\s+(.*)$/);
    if (!m) return chunk.trim();
    const n = Math.max(1, Math.ceil(Number(m[1]) * share));
    return `${n} ${m[2]}`;
  });
  return parts.filter(Boolean).join(", ");
}
