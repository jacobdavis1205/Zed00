const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;

import { currentDate } from "../dates.mjs";
import { bindInlineItemFields } from "../inline-edit.mjs";
import { moveItem, askAmount } from "../transfer.mjs";
import { readRoster, paceOf, holdOf, wealthOf, driverFor, travelWeek,
         mileageFor, PACE, MILES_PER_HEX, FOOT_SPEED } from "../caravan.mjs";

/**
 * The caravan sheet.
 *
 * Three tabs, which is the shape Jake asked for and also the shape the
 * rules want: who is along, what is aboard, and how the journey is
 * going. Membership drives the pace and the capacity, so the roster tab
 * is the one that decides what the other two can say.
 */
export class Zed00CaravanSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "caravan"],
    position: { width: 640, height: 680 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      changeTab:    Zed00CaravanSheet.#changeTab,
      editImage:    Zed00CaravanSheet.#editImage,
      travel:       Zed00CaravanSheet.#travel,
      addSelected:  Zed00CaravanSheet.#addSelected,
      removeMember: Zed00CaravanSheet.#removeMember,
      openMember:   Zed00CaravanSheet.#openMember,
      setDriver:    Zed00CaravanSheet.#setDriver,
      editGood:     Zed00CaravanSheet.#editGood,
      removeGood:   Zed00CaravanSheet.#removeGood,
      unload:       Zed00CaravanSheet.#unload,
      arrive:       Zed00CaravanSheet.#arrive,
      resetJourney: Zed00CaravanSheet.#resetJourney,
      clearLog:     Zed00CaravanSheet.#clearLog
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/actor/caravan.hbs" } };

  static TAB_LIST = [
    { id: "roster", label: "Who is along" },
    { id: "hold",   label: "The hold" },
    { id: "road",   label: "The road" }
  ];

  tabGroups = { primary: "roster" };

  #lastDrop = { key: "", at: 0 };

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const caravan = this.document;
    const sys = caravan.system;

    ctx.actor = caravan;
    ctx.system = sys;
    ctx.editable = this.isEditable;
    ctx.isGM = game.user.isGM;
    ctx.week = currentDate().week;
    ctx.milesPerHex = MILES_PER_HEX;

    const roster = await readRoster(caravan);
    ctx.roster = roster;
    ctx.people = roster.filter(m => !m.animal);
    ctx.animals = roster.filter(m => m.animal);

    // Mount choices: an animal that can actually carry somebody and is
    // not already being ridden by someone else.
    const taken = new Set(roster.filter(m => m.mount).map(m => m.mount));
    for (const m of ctx.people) {
      m.mountChoices = ctx.animals
        .filter(a => a.travels && (!taken.has(a.uuid) || a.uuid === m.mount))
        .map(a => ({ uuid: a.uuid, name: `${a.name} — ${a.speed} mi/day`,
                     chosen: a.uuid === m.mount }));
    }

    ctx.pace = paceOf(roster, { vessel: sys.vessel });
    ctx.hold = holdOf(caravan, roster);
    ctx.wealth = wealthOf(caravan, roster);

    const driver = driverFor(caravan, roster);
    ctx.driver = driver;
    const skill = driver
      ? (driver.actor.items ?? []).find(i => i.type === "skill" && /^pilot$/i.test(i.name))
      : null;
    ctx.driverLevel = Number(skill?.system?.level ?? -1);
    ctx.driverTrained = ctx.driverLevel >= 0;
    ctx.driverChoices = ctx.people.map(m => ({
      uuid: m.uuid, name: m.name, chosen: m.uuid === sys.driverUuid }));

    // What each result would actually buy this week, so the table can see
    // the shape of the gamble before anyone rolls.
    ctx.outlook = Object.entries(PACE).map(([key, band]) => ({
      key, label: band.label,
      ...mileageFor({ result: key, pace: ctx.pace.speed,
                      trained: ctx.driverTrained, difficult: sys.difficult })
    }));

    // The hold, as rows. Ammunition weighs by the batch, not the round.
    ctx.goods = caravan.items.map(i => {
      const s = i.system ?? {};
      const qty = Number(s.quantity) || 0;
      const spoilsOn = Number(s.spoilsOn) || 0;
      return {
        id: i.id, name: i.name, img: i.img, type: i.type,
        quantity: qty,
        enc: i.type === "ammo"
          ? (Number(s.bulk) || 0)
          : Math.round((Number(s.encumbrance) || 0) * qty * 10) / 10,
        unit: i.type === "ammo" && !s.ordnance ? "rounds" : "",
        left: spoilsOn ? spoilsOn - ctx.week : null,
        expired: spoilsOn ? spoilsOn <= ctx.week : false,
        perishable: !!(Number(s.shelfLife) || 0)
      };
    }).sort((a, b) => b.enc - a.enc);

    ctx.spoiling = ctx.goods.filter(g => g.left !== null && g.left <= 1 && !g.expired);

    // Food is what a journey actually runs out of, so the hold says how
    // long it can feed the people in the roster.
    const meals = caravan.items.reduce((n, i) => {
      const m = Number(i.system?.meals);
      if (Number.isFinite(m) && m > 0) return n + m * (Number(i.system.quantity) || 0);
      return n;
    }, 0);
    const heads = ctx.people.length;
    ctx.provisions = {
      meals,
      heads,
      // Seven meals a head a week, which is the colony rule and does not
      // change for being on the road.
      weeks: heads ? Math.floor(meals / (heads * 7)) : 0,
      days: heads ? Math.floor(meals / heads) : 0
    };

    ctx.log = [...sys.log].reverse();

    const active = this.tabGroups.primary ?? "roster";
    ctx.tabs = this.constructor.TAB_LIST.map(t => ({ ...t, active: t.id === active }));
    ctx.activeTab = active;

    ctx.enrichedDescription = await foundry.applications.ux.TextEditor.implementation
      .enrichHTML(sys.description ?? "", { async: true });
    return ctx;
  }

  async _onRender(context, options) {
    await super._onRender?.(context, options);
    bindInlineItemFields(this.element, this.document);

    // Mount and driver pickers write straight through rather than riding
    // on the form, because the roster is an array and a select inside an
    // array field submits as the wrong shape.
    for (const sel of this.element.querySelectorAll(".mount-pick")) {
      sel.addEventListener("change", async (ev) => {
        const uuid = ev.currentTarget.dataset.uuid;
        const roster = this.document.system.roster.map(r =>
          r.uuid === uuid ? { ...r, mount: ev.currentTarget.value } : r);
        await this.document.update({ "system.roster": roster });
      });
    }
  }

  /* ---------------------------------------------------------------- */

  static #changeTab(event, target) {
    const tab = target.dataset.tab;
    if (!tab) return;
    this.tabGroups.primary = tab;
    this.render();
  }

  static async #editImage() {
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image", current: this.document.img,
      callback: (path) => this.document.update({ img: path })
    });
    return fp.browse();
  }

  /** Add whatever tokens are selected on the canvas. */
  static async #addSelected() {
    const picked = (canvas?.tokens?.controlled ?? [])
      .map(t => t.actor)
      .filter(a => a && ["character", "colonist", "creature"].includes(a.type));
    if (!picked.length) {
      return ui.notifications.warn(
        "Select the tokens you want in the caravan first, then press this.");
    }
    const have = new Set(this.document.system.roster.map(r => r.uuid));
    const add = picked.filter(a => !have.has(a.uuid))
      .map(a => ({ uuid: a.uuid, mount: "", note: "" }));
    if (!add.length) return ui.notifications.info("They are all in it already.");
    await this.document.update({
      "system.roster": [...this.document.system.roster, ...add] });
  }

  static async #removeMember(event, target) {
    const uuid = target.closest("[data-uuid]")?.dataset.uuid;
    if (!uuid) return;
    // Anybody riding the animal that just left is back on their feet.
    const roster = this.document.system.roster
      .filter(r => r.uuid !== uuid)
      .map(r => r.mount === uuid ? { ...r, mount: "" } : r);
    await this.document.update({ "system.roster": roster });
  }

  static async #openMember(event, target) {
    const uuid = target.closest("[data-uuid]")?.dataset.uuid;
    const actor = uuid ? await fromUuid(uuid).catch(() => null) : null;
    actor?.sheet?.render(true);
  }

  static async #setDriver(event, target) {
    await this.document.update({ "system.driverUuid": target.value ?? "" });
  }

  /** One week on the road. */
  static async #travel() {
    await travelWeek(this.document);
    this.render();
  }

  static async #editGood(event, target) {
    this.document.items.get(target.closest("[data-good-id]")?.dataset.goodId)
      ?.sheet.render(true);
  }

  static async #removeGood(event, target) {
    const id = target.closest("[data-good-id]")?.dataset.goodId;
    await this.document.items.get(id)?.delete();
  }

  /** Hand a load from the caravan to one of its own members. */
  static async #unload(event, target) {
    const item = this.document.items.get(
      target.closest("[data-good-id]")?.dataset.goodId);
    if (!item) return;

    const roster = await readRoster(this.document);
    const people = roster.filter(m => !m.animal && !m.missing);
    if (!people.length) {
      return ui.notifications.warn("Nobody in the roster to hand it to.");
    }

    const who = people.length === 1 ? people[0].uuid : await foundry.applications.api
      .DialogV2.prompt({
        window: { title: `Hand over ${item.name}` },
        position: { width: 340 },
        content: `<div class="zed00"><p>Who takes it?</p>
          <select name="who" style="width:100%">
            ${people.map(m => `<option value="${m.uuid}">${m.name}</option>`).join("")}
          </select></div>`,
        ok: { label: "Hand it over",
              callback: (ev, button) => button.form.elements.who.value }
      }).catch(() => null);
    if (!who) return;

    const to = await fromUuid(who).catch(() => null);
    if (!to) return;

    const have = Number(item.system.quantity) || 1;
    const amount = await askAmount(item, have, { verb: "Hand over" });
    if (!amount) return;
    await moveItem(item, to, { amount, stowed: true });
  }

  /**
   * Arrived: bank the journey in the log and zero the tally.
   *
   * The miles are the thing worth keeping — where the caravan is now is
   * the token's job, not a number's.
   */
  static async #arrive() {
    const sys = this.document.system;
    const where = sys.destination || "its destination";
    await this.document.update({
      "system.log": [...sys.log, {
        week: currentDate().week, date: currentDate().label,
        driver: "", result: "success", total: 0, perDay: 0, miles: 0,
        note: `Arrived at ${where} — ${sys.miles} miles out of ${sys.origin || "the colony"}.`
      }],
      "system.miles": 0,
      "system.origin": where,
      "system.destination": "",
      "system.distance": 0
    });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${this.document.name}</strong> arrives at ${where}.`
    });
  }

  static async #resetJourney() {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Start the tally again" },
      content: `<div class="zed00"><p>Set the mileage back to zero? The log
        is kept — this only clears the running total.</p></div>`
    });
    if (ok) await this.document.update({ "system.miles": 0 });
  }

  static async #clearLog() {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Clear the travel log" },
      content: `<div class="zed00"><p>Delete every week in the log? This
        cannot be undone.</p></div>`
    });
    if (ok) await this.document.update({ "system.log": [] });
  }

  /* ---------------------------------------------------------------- */

  /**
   * Loading the caravan.
   *
   * Same double-fire guard as the stockpile: both this handler and
   * Foundry's own can see one drop, and one sack of steel must not
   * become two.
   */
  async _onDrop(event) {
    event.preventDefault();
    if (!this.isEditable) return;

    const TE = foundry.applications.ux.TextEditor.implementation;
    let data;
    try { data = TE.getDragEventData(event); } catch { return; }

    // An actor dropped on the sheet joins the roster — the obvious
    // gesture, and otherwise the only way in is selecting tokens.
    if (data?.type === "Actor") return this.#enlist(data);
    if (data?.type !== "Item") return;

    const key = data.uuid ?? JSON.stringify(data);
    const now = Date.now();
    if (this.#lastDrop.key === key && now - this.#lastDrop.at < 500) return;
    this.#lastDrop = { key, at: now };

    await this.#load(data, event.shiftKey === true);
  }

  async #enlist(data) {
    const actor = await fromUuid(data.uuid).catch(() => null);
    if (!actor) return;
    if (!["character", "colonist", "creature"].includes(actor.type)) {
      return ui.notifications.warn(
        `${actor.name} is not somebody who can travel. People, colonists and animals only.`);
    }
    if (this.document.system.roster.some(r => r.uuid === actor.uuid)) {
      return ui.notifications.info(`${actor.name} is already along.`);
    }
    await this.document.update({
      "system.roster": [...this.document.system.roster,
                        { uuid: actor.uuid, mount: "", note: "" }] });
    ui.notifications.info(`${actor.name} joins ${this.document.name}.`);
  }

  async #load(data, shift) {
    const item = await fromUuid(data.uuid);
    if (!item) return;

    const sys = item.system ?? {};
    if (sys.encumbrance === undefined) {
      return ui.notifications.warn(`${item.name} is not something you can haul.`);
    }
    const source = item.parent;
    if (source?.id === this.document.id) return;

    const have = Number(sys.quantity) || 1;
    const amount = await askAmount(item, have, { shift, verb: "Load" });
    if (!amount) return;

    const roster = await readRoster(this.document);
    const hold = holdOf(this.document, roster);
    const incoming = item.type === "ammo"
      ? Math.ceil(amount / (Number(sys.per) || 20)) * (Number(sys.encumbrance) || 0)
      : (Number(sys.encumbrance) || 0) * amount;
    if (incoming > hold.spare) {
      ui.notifications.warn(
        `${this.document.name} has ${hold.spare} Enc spare and that is ` +
        `${Math.round(incoming * 10) / 10}. Loading it anyway — it is over capacity, ` +
        `which is the GM's problem to rule on.`);
    }

    const moved = await moveItem(item, this.document, {
      amount, stowed: true, stampWeek: currentDate().week });
    if (!moved) return;

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${moved.moving} × ${moved.name}</strong> loaded onto ` +
               `${this.document.name}` +
               (source?.documentName === "Actor" ? ` from ${source.name}` : "") + "."
    });
  }
}
