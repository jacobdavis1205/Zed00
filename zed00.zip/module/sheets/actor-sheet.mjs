const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
import { bindInlineItemFields } from "../inline-edit.mjs";
import { moveItem, askAmount } from "../transfer.mjs";
import { applyStrain } from "../pools.mjs";
import { currentDate } from "../week.mjs";
import { cfg } from "../settings.mjs";
import { POOLS, POOL_KEYS, poolName, roundsOf, reload as reloadWeapon,
         ammoData, promptMigration, canBePlasteel, unload as unloadWeapon }
  from "../ammo.mjs";

export class Zed00ActorSheet extends HandlebarsApplicationMixin(ActorSheetV2) {

  static DEFAULT_OPTIONS = {
    classes: ["zed00", "sheet", "actor"],
    position: { width: 760, height: 820 },
    window: { resizable: true },
    form: { submitOnChange: true },
    actions: {
      changeTab:     Zed00ActorSheet.#changeTab,
      editImage:     Zed00ActorSheet.#editImage,
      rollInitiative: Zed00ActorSheet.#rollInitiative,
      rollSkill:     Zed00ActorSheet.#rollSkill,
      rollSave:      Zed00ActorSheet.#rollSave,
      rollAttack:    Zed00ActorSheet.#rollAttack,
      push:          Zed00ActorSheet.#push,
      endScene:      Zed00ActorSheet.#endScene,
      restWeek:      Zed00ActorSheet.#restWeek,
      adjustStrain:  Zed00ActorSheet.#adjustStrain,
      editItem:      Zed00ActorSheet.#editItem,
      deleteItem:    Zed00ActorSheet.#deleteItem,
      createItem:    Zed00ActorSheet.#createItem,
      toggleEquip:   Zed00ActorSheet.#toggleEquip,
      postItem:      Zed00ActorSheet.#postItem,
      castPower:     Zed00ActorSheet.#castPower,
      backfillSkills: Zed00ActorSheet.#backfillSkills,
      levelUp:       Zed00ActorSheet.#levelUp,
      buySkill:      Zed00ActorSheet.#buySkill,
      buyAttribute:  Zed00ActorSheet.#buyAttribute,
      removeXenotype: Zed00ActorSheet.#removeXenotype,
      addInjury:     Zed00ActorSheet.#addInjury,
      removeInjury:  Zed00ActorSheet.#removeInjury,
      addDisease:    Zed00ActorSheet.#addDisease,
      removeDisease: Zed00ActorSheet.#removeDisease,
      treatDisease:  Zed00ActorSheet.#treatDisease,
      reload:        Zed00ActorSheet.#reload,
      addAmmo:       Zed00ActorSheet.#addAmmo,
      unloadWeapon:  Zed00ActorSheet.#unloadWeapon,
      migrateAmmo:   Zed00ActorSheet.#migrateAmmo,
      addFeature:    Zed00ActorSheet.#addFeature,
      removeFeature: Zed00ActorSheet.#removeFeature,
      postFeature:   Zed00ActorSheet.#postFeature,
      importXenotype: Zed00ActorSheet.#importXenotype,
      levelFocus:    Zed00ActorSheet.#levelFocus,
      addAddiction:  Zed00ActorSheet.#addAddiction,
      removeAddiction: Zed00ActorSheet.#removeAddiction,
      rollDependency: Zed00ActorSheet.#rollDependency,
      splitStack:    Zed00ActorSheet.#splitStack
    }
  };

  static PARTS = {
    header:    { template: "systems/zed00/templates/actor/header.hbs" },
    tabs:      { template: "systems/zed00/templates/actor/tabs.hbs" },
    main:      { template: "systems/zed00/templates/actor/main.hbs" },
    condition: { template: "systems/zed00/templates/actor/condition.hbs" },
    gear:      { template: "systems/zed00/templates/actor/gear.hbs" },
    psionics:  { template: "systems/zed00/templates/actor/psionics.hbs" },
    features:  { template: "systems/zed00/templates/actor/features.hbs" },
    injury:    { template: "systems/zed00/templates/actor/injury.hbs" },
    bio:       { template: "systems/zed00/templates/actor/bio.hbs" }
  };

  static TAB_LIST = [
    { id: "main",      label: "ZED00.Tab.Main" },
    { id: "condition", label: "ZED00.Tab.Condition" },
    { id: "gear",      label: "ZED00.Tab.Gear" },
    { id: "psionics",  label: "ZED00.Tab.Psionics" },
    { id: "features",  label: "ZED00.Tab.Features" },
    { id: "injury",    label: "ZED00.Tab.Injury" },
    { id: "bio",       label: "ZED00.Tab.Bio" }
  ];

  /** Which tab is showing. Survives re-render. */
  tabGroups = { primary: "main" };

  /**
   * Taking something out of a stockpile is a move, not a copy.
   *
   * Foundry's default drop creates a duplicate, which would quietly
   * double the colony's metal every time somebody collected some. If
   * the item came off a structure, it leaves that structure.
   */
  async _onDrop(event) {
    event.preventDefault();
    if (!this.isEditable) return;

    // Both this listener and Foundry's own sheet drop handling can see
    // the same event, which is how one sack of metal arrived as two
    // rows. The same payload inside half a second is one gesture.
    const key = event.dataTransfer?.getData("text/plain") ?? "";
    const now = Date.now();
    if (this.#lastDrop.key === key && now - this.#lastDrop.at < 500) return;
    this.#lastDrop = { key, at: now };

    const TE = foundry.applications.ux.TextEditor.implementation;
    let data;
    try { data = TE.getDragEventData(event); } catch { return; }
    if (data?.type !== "Item") return;

    const item = await fromUuid(data.uuid);
    if (!item) return;
    const source = item.parent;

    // Dropped onto its own owner: nothing to do, and certainly not a
    // second copy of itself.
    if (source?.id === this.document.id) return;

    // From a compendium or the sidebar: an ordinary copy.
    if (source?.documentName !== "Actor" || source.type !== "structure") {
      const payload = item.toObject();
      delete payload._id;
      await this.document.createEmbeddedDocuments("Item", [payload]);
      return;
    }

    if (!source.isOwner) {
      return ui.notifications.warn(
        `You do not have permission to take things out of ${source.name}.`);
    }

    const have = Number(item.system.quantity) || 1;
    const amount = await askAmount(item, have,
      { shift: event.shiftKey === true, verb: "Take" });
    if (!amount) return;

    const moved = await moveItem(item, this.document, { amount, stowed: true });
    if (!moved) return;

    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${moved.moving} × ${moved.name}</strong> out of ${source.name}.`
    });

  }

  async _prepareContext(options) {
    const ctx = await super._prepareContext(options);
    const actor = this.document;
    const sys = actor.system;

    ctx.actor = actor;
    ctx.system = sys;
    ctx.config = CONFIG.ZED00;
    ctx.editable = this.isEditable;
    ctx.isColonist = actor.type === "colonist";

    // Sort the owned items into buckets the templates can iterate.
    // Weapons carry the name of whatever they are paired with, so the
    // "dual" tag disappears on its own once the off-hand is gone.
    const weapons = actor.items.filter(i => i.type === "weapon");
    for (const w of weapons) {
      const id = w.system.offhandId;
      const mate = id ? actor.items.get(id) : null;
      // A weapon can pair with itself when you own two of them.
      w.offhand = (id === w.id && (Number(w.system.quantity) || 1) >= 2)
        ? `a second ${w.name}`
        : (mate?.name ?? "");
    }

    // How long perishables have left, so a pack of food is readable at a
    // glance rather than needing each item opened.
    const week = currentDate().week;
    for (const it of actor.items) {
      const on = Number(it.system?.spoilsOn) || 0;
      if (!on) { it.spoil = null; continue; }
      const left = on - week;
      it.spoil = left <= 0
        ? { label: "spoiled", tone: "bad", title: `Went off in week ${on}.` }
        : left === 1
          ? { label: "1w left", tone: "bad", title: `Goes off next week.` }
          : { label: `${left}w left`, tone: left <= 2 ? "warn" : "",
              title: `Goes off in week ${on}.` };
    }

    ctx.items = {
      weapons,
      armor:     actor.items.filter(i => i.type === "armor"),
      gear:      actor.items.filter(i => i.type === "gear"),
      ammo:      actor.items.filter(i => i.type === "ammo")
                      .sort((a, b) => POOL_KEYS.indexOf(a.system.pool) -
                                      POOL_KEYS.indexOf(b.system.pool)),
      drugs:     actor.items.filter(i => i.type === "drug"),
      cyberware: actor.items.filter(i => i.type === "cyberware"),
      powers:    actor.items.filter(i => i.type === "power"),
      foci:      actor.items.filter(i => i.type === "focus"),
      skills:    actor.items.filter(i => i.type === "skill")
                      .sort((a, b) => a.name.localeCompare(b.name)),
      xenotype:  actor.items.find(i => i.type === "xenotype") ?? null
    };

    // Worked out on the data model so the sheet, the token and any macro
    // all read the same numbers.
    ctx.encumbrance = sys.encumbrance;

    // The Strain track renders as pips so the pool reads at a glance.
    ctx.strainPips = Array.from({ length: sys.strain.max }, (_, i) => ({
      filled: i < sys.strain.value,
      past:   i >= sys.strain.unstableAt
    }));

    ctx.exposureLadder = [0, 1, 2, 3, 4, 5].map(n => ({
      level: n,
      current: n === sys.exposure.level,
      reachable: n <= (sys.exposure.ceiling || 0)
    }));

    // Ammunition is items now, so the weapons table reads what is being
    // carried rather than a counter — "3/6, 42 to hand".
    //
    // Named ammoPack, not pack: Document#pack is Foundry's own getter for
    // the compendium a document came from, and assigning over a
    // getter-only accessor throws in strict mode, which every ES module
    // is. That is what stopped these sheets opening in v1.16.0.
    for (const w of weapons) {
      if (!w.system.magazine) { w.ammoPack = null; continue; }
      const pool = (w.system.ammoPool || "").toLowerCase();
      w.ammoPack = {
        pool,
        name: poolName(pool),
        rounds: roundsOf(actor, pool),
        known: !!POOLS[pool]
      };
    }

    // Anything left in the old counters, so a world that has not been
    // migrated yet says so on the sheet instead of silently losing it.
    ctx.legacyAmmo = POOL_KEYS
      .map(k => ({ key: k, name: poolName(k), count: Number(sys.ammo?.[k]) || 0 }))
      .filter(p => p.count > 0);

    // Arrows and grenades have no Metal in the recipe, so there is
    // nothing to replace with plasteel — the sheet says so rather than
    // offering an upgrade that cannot be made.
    ctx.ammoChoices = POOL_KEYS.map(k => ({
      key: k, name: POOLS[k].name, plasteel: canBePlasteel(k) }));
    ctx.anyPlasteel = ctx.ammoChoices.some(c => c.plasteel);
    for (const a of ctx.items.ammo) a.feeds = POOLS[a.system.pool]?.feeds ?? "";

    ctx.system.addictions = (sys.addictions ?? []).map(a =>
      ({ ...a, over: Math.max(0, (a.taken ?? 0) - (a.free ?? 0)) }));

    ctx.autoPenalties = cfg.autoPenalties;
    ctx.canPush = !ctx.isColonist && sys.nextPushCost !== null;

    // Build the tab list ourselves so the active flag is always right.
    const active = this.tabGroups.primary ?? "main";
    ctx.tabs = this.constructor.TAB_LIST.map(t => ({ ...t, active: t.id === active }));
    ctx.activeTab = active;

    return ctx;
  }

  _preparePartContext(partId, ctx) {
    const active = this.tabGroups.primary ?? "main";
    if (this.constructor.TAB_LIST.some(t => t.id === partId)) {
      ctx.tab = { id: partId, active: partId === active };
    }
    return ctx;
  }

  /** Teardown handle for this render's listeners. */
  #listeners;

  /** The last drop acted on, so the same one is never taken twice. */
  #lastDrop = { key: "", at: 0 };

  /** Make sure exactly one body is visible after every render. */
  _onRender(context, options) {
    super._onRender?.(context, options);
    const active = this.tabGroups.primary ?? "main";
    for (const el of this.element.querySelectorAll(".tab-body[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === active);
    }
    for (const el of this.element.querySelectorAll(".tab-link[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === active);
    }

    // Quantities and skill bonuses are edited straight onto their items,
    // outside the form. Abort the previous render's listeners first or
    // they stack up and one keystroke fires several writes.
    this.#listeners?.abort();
    this.#listeners = new AbortController();
    const { signal } = this.#listeners;
    bindInlineItemFields(this.element, this.document, signal);

    // --- dragging gear off the sheet -------------------------------
    // ApplicationV2 only runs _onDragStart / _onDrop through a DragDrop
    // handler configured in DEFAULT_OPTIONS. Rather than depend on that
    // plumbing, the listeners go on directly — the same approach the
    // stockpile sheet already uses, which is the half that worked.
    for (const row of this.element.querySelectorAll("[data-item-id]")) {
      const item = this.document.items.get(row.dataset.itemId);
      if (!item) continue;
      row.setAttribute("draggable", "true");
      row.addEventListener("dragstart", (ev) => {
        ev.stopPropagation();
        ev.dataTransfer.setData("text/plain", JSON.stringify({
          type: "Item", uuid: item.uuid
        }));
        ev.dataTransfer.effectAllowed = "move";
      }, { signal });
    }

    // --- and dropping things onto it -------------------------------
    this.element.addEventListener("dragover", (ev) => ev.preventDefault(), { signal });
    this.element.addEventListener("drop", (ev) => this._onDrop(ev), { signal });
  }

  /* ------------------------------------------------------- actions */

  static #changeTab(event, target) {
    const tab = target.dataset.tab;
    if (!tab) return;
    this.tabGroups.primary = tab;
    for (const el of this.element.querySelectorAll(".tab-body[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === tab);
    }
    for (const el of this.element.querySelectorAll(".tab-link[data-tab]")) {
      el.classList.toggle("active", el.dataset.tab === tab);
    }
  }

  static async #editImage(event, target) {
    const current = this.document.img;
    const fp = new foundry.applications.apps.FilePicker.implementation({
      type: "image",
      current,
      callback: path => this.document.update({ img: path }),
      top: this.position.top + 40,
      left: this.position.left + 10
    });
    return fp.browse();
  }

  static async #rollInitiative() {
    const combat = game.combat;
    if (!combat) {
      // No encounter running — just roll it openly so the GM can note it.
      const r = await new Roll("1d8 + @mod",
        { mod: this.document.system.attributes.dex.mod }).evaluate();
      return r.toMessage({
        speaker: ChatMessage.getSpeaker({ actor: this.document }),
        flavor: "<strong>Initiative</strong>"
      });
    }
    const existing = combat.getCombatantsByActor(this.document.id);
    if (!existing.length) {
      const token = this.document.getActiveTokens()[0];
      if (!token) return ui.notifications.warn("Place a token on the scene first.");
      await combat.createEmbeddedDocuments("Combatant",
        [{ tokenId: token.id, actorId: this.document.id, sceneId: canvas.scene.id }]);
    }
    const ids = combat.getCombatantsByActor(this.document.id).map(c => c.id);
    return combat.rollInitiative(ids);
  }

  static async #rollSkill(event, target) {
    const name = target.dataset.skill;
    // The TN dropdown next to the skill list sets the target for the roll.
    const sel = this.element.querySelector(".tn-select");
    const tn = Number(sel?.value ?? target.dataset.tn ?? 8);
    await this.document.rollSkill(name, { tn, darkness: this.document.system.conditions.darkness });
  }

  static async #rollSave(event, target) {
    await this.document.rollSave(target.dataset.save);
  }

  static async #rollAttack(event, target) {
    const item = this.document.items.get(target.dataset.itemId);
    if (!item) return;
    const burst = target.dataset.burst === "1";
    // The weapon says which skill swings it.
    const want = (item.system.skillName ?? "Stab").toLowerCase();
    const skill = this.document.items.find(i => i.type === "skill" &&
      i.name.toLowerCase() === want);
    await game.zed00.Dice.rollAttack(this.document, item, { skill, burst });
  }

  /** Fill a magazine from the boxes of ammunition being carried. */
  static async #reload(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    await reloadWeapon(this.document, item);
  }

  /** Move the old per-sheet counters into real boxes. */
  static async #migrateAmmo() {
    await promptMigration();
  }

  /**
   * Add a batch of ammunition.
   *
   * This used to be a dropdown, a checkbox and a plus sign sitting in the
   * panel heading, which read like a filter rather than a way to make
   * something. One button and one dialog says what it is.
   */
  static async #addAmmo() {
    const rows = POOL_KEYS.map(k => {
      const p = POOLS[k];
      return `<label class="check" style="display:block;padding:2px 0">
        <input type="radio" name="pool" value="${k}" ${k === "rifle" ? "checked" : ""}>
        <b>${p.name}</b> <span class="hint">${p.feeds}</span>
        ${canBePlasteel(k) ? "" : `<span class="hint">· no plasteel version</span>`}
      </label>`;
    }).join("");

    const got = await foundry.applications.api.DialogV2.prompt({
      window: { title: "Add ammunition", icon: "fas fa-box" },
      position: { width: 460 },
      content: `<div class="zed00">
        ${rows}
        <hr>
        <label class="check"><input type="checkbox" name="plasteel"> Plasteel —
          goes through powered armour. <span class="hint">Fabrication Bench only.
          Not possible for arrows or grenades, which use no metal.</span></label>
        <label class="check">Rounds
          <input type="number" name="rounds" min="1" value="20" style="width:5em"></label>
      </div>`,
      ok: { label: "Add it", callback: (ev, button) => ({
        pool: button.form.elements.pool.value,
        plasteel: button.form.elements.plasteel.checked,
        rounds: Number(button.form.elements.rounds.value) || 20
      }) }
    }).catch(() => null);
    if (!got || !POOLS[got.pool]) return;

    const fabricated = got.plasteel && canBePlasteel(got.pool);
    if (got.plasteel && !fabricated) {
      ui.notifications.warn(
        `${POOLS[got.pool].name} cannot be made in plasteel — ` +
        `${POOLS[got.pool].metal ? "the weapons it feeds already go through powered armour" : "the recipe uses no metal to replace"}. ` +
        `Adding the ordinary kind.`);
    }
    await this.document.createEmbeddedDocuments(
      "Item", [ammoData(got.pool, got.rounds, { fabricated })]);
  }

  /** Empty a magazine back onto the sheet. */
  static async #unloadWeapon(event, target) {
    const item = this.document.items.get(
      target.closest("[data-item-id]").dataset.itemId);
    if (item) await unloadWeapon(this.document, item);
  }

  static async #push() { await this.document.push(); }

  static async #endScene() {
    await game.zed00.Dice.endScene(this.document);
    ui.notifications.info("Scene ended. Pushes reset.");
  }

  static async #restWeek() {
    const sel = this.element.querySelector(".rest-quality");
    await this.document.restWeek({ bed: sel?.value ?? "basic" });
  }

  /** The + button spends the buffer before the real pool. */
  static async #adjustStrain(event, target) {
    const delta = Number(target.dataset.delta);
    const out = await applyStrain(this.document, delta);
    if (out.absorbed) {
      ui.notifications.info(
        `${out.absorbed} absorbed by the buffer` +
        (out.buffer ? ` — ${out.buffer} left.` : ", now spent."));
    }
  }

  static async #editItem(event, target) {
    this.document.items.get(target.closest("[data-item-id]").dataset.itemId)?.sheet.render(true);
  }

  static async #deleteItem(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Delete Item" },
      content: `<p>Delete <strong>${item.name}</strong>?</p>`
    });
    if (ok) await item.delete();
  }

  static async #createItem(event, target) {
    const type = target.dataset.type;
    await this.document.createEmbeddedDocuments("Item", [{
      name: `New ${type}`, type
    }]);
  }

  static async #postItem(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (item) await game.zed00.Dice.postItem(this.document, item);
  }

  static async #castPower(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (item) await game.zed00.Dice.castPower(this.document, item);
  }

  static async #backfillSkills() { await game.zed00.backfillSkills(this.document); }

  /** Spend the XP and take the level, if the table allows it. */
  static async #levelUp() {
    const sys = this.document.system;
    if (!sys.canLevel) {
      return ui.notifications.warn(
        `${this.document.name} needs ${sys.xpForNext} XP and has ${sys.xp}.`);
    }
    const newLevel = sys.level + 1;
    const gainsGrowth = [2, 4, 6, 8, 10].includes(newLevel);
    // Past ten, a level is one skill point and nothing else.
    const points = newLevel > 10 ? 1 : 3;
    const gainsFocus = [2, 5, 7, 10].includes(newLevel);
    await this.document.update({
      "system.level": newLevel,
      "system.skillPoints": sys.skillPoints + points
    });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${this.document.name} reaches level ${sys.level + 1}.</strong>` +
        `<br>${points} skill point${points === 1 ? "" : "s"}.` +
        (gainsGrowth ? `<br>An attribute point to spend.` : "") +
        (gainsFocus ? `<br>A focus — a new one, or a second level in one you have.` : "") +
        (newLevel > 10 ? `<br><em>Past ten: a skill point and nothing else.</em>` : "")
    });
  }

  /** Spend banked points to raise a skill. Cost is the new level, min 1. */
  static async #buySkill(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;
    const lvl = item.system.level;
    if (lvl >= 4) return ui.notifications.info(`${item.name} is already at 4.`);
    const cap = this.document.system.maxSkillLevel;
    if (lvl + 1 > cap) {
      return ui.notifications.warn(
        `${item.name} cannot go past ${cap} until a higher level. Level 3 allows 2, level 6 allows 3, level 9 allows 4.`);
    }
    const cost = Math.max(1, lvl + 2);          // -1 to 0 costs 1, 0 to 1 costs 2 ...
    const bank = this.document.system.skillPoints;
    if (bank < cost) {
      return ui.notifications.warn(`${item.name} to ${lvl + 1} costs ${cost}. There are ${bank} banked.`);
    }
    await item.update({ "system.level": lvl + 1 });
    await this.document.update({ "system.skillPoints": bank - cost });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${item.name}</strong> raised to ${lvl + 1}. ${cost} skill point${cost === 1 ? "" : "s"} spent.`
    });
  }

  /** Spend one of the free growth points from levels 2, 4, 6, 8 and 10. */
  static async #buyAttribute(event, target) {
    const key = target.dataset.attr;
    const sys = this.document.system;
    if (!sys.growthUnspent) return ui.notifications.warn("No attribute growth left to spend.");
    const score = sys.attributes[key].value;
    if (score >= 18) return ui.notifications.info("That attribute is already at 18.");
    await this.document.update({
      [`system.attributes.${key}.value`]: score + 1,
      "system.attributeGrowth": sys.attributeGrowth + 1
    });
  }

  static async #removeXenotype() {
    const x = this.document.items.find(i => i.type === "xenotype");
    if (!x) return;
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Remove Xenotype" },
      content: `<p>Remove <strong>${x.name}</strong> from ${this.document.name}?</p>`
    });
    if (ok) await x.delete();
  }

  static async #addFeature() {
    await this.document.update({ "system.features":
      [...this.document.system.features, { name: "", kind: "other", text: "" }] });
  }
  static async #removeFeature(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.features":
      this.document.system.features.filter((_, n) => n !== i) });
  }
  static async #postFeature(event, target) {
    const f = this.document.system.features[Number(target.dataset.index)];
    if (!f) return;
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<div class="zed00-card"><header><strong>${f.name}</strong></header>
                <div class="meta">${f.kind}</div><div class="text">${f.text}</div></div>`
    });
  }

  /** Copy a xenotype's parsed traits into the features list. */
  static async #importXenotype() {
    const x = this.document.items.find(i => i.type === "xenotype");
    if (!x) return;
    const have = new Set(this.document.system.features.map(f => f.name.toLowerCase()));
    const add = (x.system.features ?? [])
      .filter(f => f.name && !have.has(f.name.toLowerCase()))
      .map(f => ({ name: f.name, kind: "xenotype", text: f.text }));
    if (!add.length) return ui.notifications.info("Those traits are already listed.");
    await this.document.update({ "system.features": [...this.document.system.features, ...add] });
    ui.notifications.info(`Added ${add.length} trait${add.length === 1 ? "" : "s"} from ${x.name}.`);
  }

  /** Foci arrive free at levels 2, 5, 7 and 10. They are never bought. */
  static async #levelFocus(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item || item.system.level >= 2) return;
    const sys = this.document.system;
    if (!sys.fociUnspent) {
      return ui.notifications.warn(
        `No focus pick available. They come at levels 2, 5, 7 and 10 — ${this.document.name} has used all ${sys.fociEarned}.`);
    }
    await item.update({ "system.level": 2 });
    await this.document.update({ "system.fociTaken": sys.fociTaken + 1 });
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${item.name}</strong> taken to level 2.`
    });
  }

  static async #addAddiction() {
    await this.document.update({ "system.addictions":
      [...this.document.system.addictions, { drug: "", free: 4, taken: 0, dependent: false }] });
  }
  static async #removeAddiction(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.addictions":
      this.document.system.addictions.filter((_, n) => n !== i) });
  }

  /** End of the week: roll against the overage. */
  static async #rollDependency(event, target) {
    const i = Number(target.dataset.index);
    const list = [...this.document.system.addictions];
    const a = list[i];
    if (!a) return;
    const over = Math.max(0, a.taken - a.free);
    if (!over) return ui.notifications.info(`${a.drug || "That"} stayed within the free doses.`);
    const roll = await new Roll("1d20").evaluate();
    const caught = roll.total <= over * 5;
    await roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      flavor: `<strong>${a.drug || "Dependency"}</strong> — ${over} over, dependent on ${over * 5} or less — ` +
              `<em>${caught ? "dependent" : "clear"}</em>`
    });
    if (caught) { a.dependent = true; }
    a.taken = 0;
    await this.document.update({ "system.addictions": list });
  }

  /** Take one out of a stack and ready it, leaving the rest stowed. */
  static async #splitStack(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item || (item.system.quantity ?? 1) < 2) return;
    const copy = item.toObject();
    delete copy._id;
    copy.system.quantity = 1;
    copy.system.stowed = !item.system.stowed;
    await item.update({ "system.quantity": item.system.quantity - 1 });
    await this.document.createEmbeddedDocuments("Item", [copy]);
  }

  static async #addInjury() {
    await this.document.update({ "system.injuries":
      [...this.document.system.injuries, { name: "", effect: "", permanent: false, major: false }] });
  }
  static async #removeInjury(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.injuries":
      this.document.system.injuries.filter((_, n) => n !== i) });
  }
  static async #addDisease() {
    await this.document.update({ "system.diseases":
      [...this.document.system.diseases, { name: "", tier: 1, tn: 8, cap: 0, note: "" }] });
  }
  static async #removeDisease(event, target) {
    const i = Number(target.dataset.index);
    await this.document.update({ "system.diseases":
      this.document.system.diseases.filter((_, n) => n !== i) });
  }

  /** One treatment check a week. Degrees of success move the tier. */
  static async #treatDisease(event, target) {
    const i = Number(target.dataset.index);
    const list = [...this.document.system.diseases];
    const d = list[i];
    if (!d) return;
    const med = this.element.querySelector(".med-select")?.value ?? "herbal";
    const heal = this.document.items.find(x => x.type === "skill" && x.name.toLowerCase() === "heal");

    const { margin } = await game.zed00.Dice.rollSkill(this.document, {
      skill: heal, attribute: "int", tn: d.tn, medicine: med,
      label: `Treating ${d.name || "disease"} with ${med === "none" ? "nothing" : med} medicine`
    });
    // Bare-handed work costs the patient a point of Strain.
    if (med === "none") {
      await this.document.update({ "system.strain.value":
        Math.min(this.document.system.strain.max, this.document.system.strain.value + 1) });
    }

    const shift = margin >= 4 ? -2 : margin >= 0 ? -1 : margin <= -4 ? 1 : 0;
    const cap = d.cap || 5;
    d.tier = Math.max(0, Math.min(cap, d.tier + shift));

    const shiftText = { "-2": "loses two tiers", "-1": "loses a tier",
                        "0": "holds", "1": "gains a tier" }[String(shift)];
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this.document }),
      content: `<strong>${d.name || "The illness"}</strong> ${shiftText} — now tier ${Math.max(0, d.tier)}.`
    });

    if (d.tier <= 0) {
      list.splice(i, 1);
      ChatMessage.create({ content: `<strong>${d.name || "The illness"} has passed.</strong>` });
    } else if (d.tier >= 5) {
      ChatMessage.create({ content: `<strong>${d.name} has reached tier 5.</strong>` });
    }
    await this.document.update({ "system.diseases": list });
  }

  /**
   * Ready or stow one of something.
   *
   * Two hacking rigs in the pack and you draw one: you should end up with
   * one readied and one still stowed, not two readied and not one. So a
   * stack of more than one splits, and a single item rejoining a matching
   * stack merges back into it. Shift-click moves the whole lot at once.
   */
  static async #toggleEquip(event, target) {
    const item = this.document.items.get(target.closest("[data-item-id]").dataset.itemId);
    if (!item) return;

    // Armour is worn or not — there is no half-wearing a flak jacket.
    if (item.type === "armor") {
      return item.update({ "system.equipped": !item.system.equipped });
    }

    const qty = Number(item.system.quantity) || 1;
    const nowStowed = !item.system.stowed;
    // "all" is its own link on the sheet rather than a shift-click nobody
    // can see, but the shift still works for anyone who expects it.
    const whole = target.dataset.all === "1" || event?.shiftKey || qty <= 1;
    const moving = whole ? qty : 1;

    // Is there already a pile on the other side to merge back into?
    const twin = this.document.items.find(i =>
      i.id !== item.id && i.name === item.name && i.type === item.type &&
      !!i.system.stowed === nowStowed &&
      (Number(i.system.spoilsOn) || 0) === (Number(item.system.spoilsOn) || 0));

    if (twin) {
      await twin.update({
        "system.quantity": (Number(twin.system.quantity) || 0) + moving });
      if (whole) await item.delete();
      else await item.update({ "system.quantity": qty - 1 });
      return;
    }

    if (whole) return item.update({ "system.stowed": nowStowed });

    // Peel one off the stack.
    const one = item.toObject();
    delete one._id;
    one.system.quantity = 1;
    one.system.stowed = nowStowed;
    await item.update({ "system.quantity": qty - 1 });
    await this.document.createEmbeddedDocuments("Item", [one]);
  }
}
