const { SchemaField, NumberField, StringField, BooleanField, HTMLField, ArrayField } =
  foundry.data.fields;

/**
 * How much one grid square of stockpile holds, in Encumbrance.
 *
 * Measured in the same unit a character carries things in, so "will this
 * fit in the warehouse" and "can I carry it there" are the same question
 * asked twice. Ten Enc a square puts a 3×3 shed at 90 Enc — comfortably
 * more than one colony's working stock, and nowhere near a whole base.
 */
export const ENC_PER_SQUARE = 10;

/** Kept so old worlds keep loading. Nothing reads it any more. */
export const UNITS_PER_SQUARE = 50;

export const FUNCTIONS = [
  "stockpile", "generator", "battery", "bench", "bed", "turret",
  "farm", "light", "climate", "recreation", "defence", "other", "wall"
];

/**
 * What a thing is built out of, and what that means when it is attacked.
 *
 * Straight from the Walls & Barriers table. The important column isn't
 * hit points — it's `tl4Proof`. A Charge Rifle does not care that your
 * stone wall has 42 HP, and only Plasteel changes that.
 */
export const MATERIALS = {
  wood:     { label: "Wood",     fire: "flammable",      tl4Proof: false },
  textile:  { label: "Textiles", fire: "flammable",      tl4Proof: false,
              explosiveResistant: true },
  metal:    { label: "Metal",    fire: "fire-retardant", tl4Proof: false },
  stone:    { label: "Stone",    fire: "inflammable",    tl4Proof: false },
  plasteel: { label: "Plasteel", fire: "inflammable",    tl4Proof: true },
  mixed:    { label: "Mixed",    fire: "flammable",      tl4Proof: false }
};

/**
 * A colony structure.
 *
 * Terrain is not this. Walls, floors and doors stay as tiles and wall
 * segments — there are hundreds of them and they hold nothing worth
 * tracking. A structure actor is for the fifteen or thirty things that
 * have hit points, draw power, hold goods or shoot at people.
 */
/** Encumbrance is fractional, and 7.300000000000001 is not a weight. */
const round1 = n => Math.round(n * 10) / 10;

export class Zed00Structure extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),

      function: new StringField({ choices: FUNCTIONS, initial: "other" }),

      material: new StringField({
        choices: Object.keys(MATERIALS), initial: "metal" }),

      health: new SchemaField({
        value: new NumberField({ integer: true, initial: 20 }),
        max:   new NumberField({ integer: true, initial: 20 })
      }),
      condition: new StringField({
        choices: ["pristine", "damaged", "broken", "destroyed"], initial: "pristine" }),

      // Footprint in grid squares. Drives stockpile capacity.
      squares: new NumberField({ integer: true, min: 1, initial: 1 }),

      // Power. Generators give, everything else takes.
      power: new SchemaField({
        output: new NumberField({ integer: true, min: 0, initial: 0 }),
        draw:   new NumberField({ integer: true, min: 0, initial: 0 }),
        // Solar and wind stop in bad weather; the week engine knows which.
        weatherDependent: new BooleanField({ initial: false }),
        running: new BooleanField({ initial: true })
      }),

      // Upkeep per week, as a material and an amount.
      upkeep: new SchemaField({
        material: new StringField({ initial: "" }),
        amount:   new NumberField({ integer: true, min: 0, initial: 0 })
      }),

      build: new SchemaField({
        materials: new StringField({ initial: "" }),
        bench:     new StringField({ initial: "none" }),
        weeks:     new NumberField({ integer: true, min: 0, initial: 0 })
      }),

      // --- stockpile ---------------------------------------------------
      // Goods are held as batches so spoilage has something to expire.
      contents: new ArrayField(new SchemaField({
        name:   new StringField({ initial: "" }),
        units:  new NumberField({ integer: true, min: 0, initial: 0 }),
        spoils: new NumberField({ integer: true, min: 0, initial: 0 })   // 0 = never
      }), { initial: [] }),
      freezing: new BooleanField({ initial: false }),
      covered:  new BooleanField({ initial: true }),

      // --- turret ------------------------------------------------------
      attacks: new ArrayField(new SchemaField({
        name:    new StringField({ initial: "Turret" }),
        bonus:   new NumberField({ integer: true, initial: 2 }),
        damage:  new StringField({ initial: "1d8" }),
        count:   new NumberField({ integer: true, min: 1, initial: 1 }),
        shock:   new NumberField({ integer: true, min: 0, initial: 0 }),
        shockAC: new NumberField({ integer: true, min: 0, initial: 0 }),
        range:   new StringField({ initial: "" }),
        note:    new StringField({ initial: "" })
      }), { initial: [] }),
      armorClass: new NumberField({ integer: true, initial: 14 }),

      // --- farm --------------------------------------------------------
      crop: new SchemaField({
        name:    new StringField({ initial: "" }),
        yield:   new NumberField({ integer: true, min: 0, initial: 175 }),
        checks:  new NumberField({ integer: true, min: 0, max: 4, initial: 0 }),
        steps:   new NumberField({ integer: true, initial: 0 }),   // 25% each
        failures: new NumberField({ integer: true, min: 0, initial: 0 }),
        lost:    new BooleanField({ initial: false })
      }),

      // --- bed ---------------------------------------------------------
      quality: new StringField({
        choices: ["none", "bedroll", "basic", "private"], initial: "basic" }),
      sleeps: new NumberField({ integer: true, min: 0, initial: 1 }),

      // --- light -------------------------------------------------------
      // Straight off the Area Lit column. A Torch Lamp covers 3×3, a
      // Standing Lamp 5×5 and a Flood Light 10×10 — which is the whole
      // reason to pay for power, and why a free torch is not a free
      // floodlight. Radius in feet.
      lit: new SchemaField({
        bright: new NumberField({ integer: true, min: 0, initial: 0 }),
        dim:    new NumberField({ integer: true, min: 0, initial: 0 }),
        flame:  new BooleanField({ initial: false })   // burns rather than draws
      })
    };
  }

  prepareDerivedData() {
    const c = this.condition;
    this.usable = c !== "destroyed";
    this.bloodied = this.health.value <= Math.floor(this.health.max / 2);

    // --- what it is made of ------------------------------------------
    const m = MATERIALS[this.material] ?? MATERIALS.metal;
    this.materialLabel = m.label;
    this.fire = m.fire;
    this.tl4Proof = m.tl4Proof;
    this.explosiveResistant = !!m.explosiveResistant;
    // The one sentence a GM needs when someone shoots the wall.
    this.defenceNote = m.tl4Proof
      ? "Stands up to TL4 weapons."
      : "Takes full damage from TL4 (Advanced) weapons — armour and hit points do not apply.";

    // Broken buildings do not do their job.
    this.working = this.usable && c !== "broken" && this.power.running;

    // --- stockpile ---------------------------------------------------
    // Goods are the items this structure owns, so they can be dragged in
    // off a character and dragged back out again.
    this.capacity = round1(this.squares * ENC_PER_SQUARE);
    const goods = this.parent?.items ?? [];
    this.stored = round1(goods.reduce((n, i) => {
      const s = i.system ?? {};
      return n + (Number(s.encumbrance) || 0) * (Number(s.quantity) || 0);
    }, 0));
    this.spare = round1(this.capacity - this.stored);
    this.overCapacity = this.stored > this.capacity;
    this.fillPercent = this.capacity ? Math.round((this.stored / this.capacity) * 100) : 0;

    // --- power -------------------------------------------------------
    this.netPower = this.working ? (this.power.output - this.power.draw) : -0;
    this.effectiveOutput = this.working ? this.power.output : 0;
    this.effectiveDraw = this.usable ? this.power.draw : 0;

    // --- farm --------------------------------------------------------
    // Each result moves the harvest a 25% step, capped at 150%.
    const mult = Math.max(0, Math.min(6, 4 + (this.crop.steps ?? 0))) / 4;
    this.crop.multiplier = mult;
    this.crop.projected = this.crop.lost ? 0 : Math.floor(this.crop.yield * mult);
    this.crop.ready = (this.crop.checks ?? 0) >= 4 && !this.crop.lost;
    this.crop.weeksLeft = Math.max(0, 4 - (this.crop.checks ?? 0));
  }
}
