const { SchemaField, NumberField, StringField, BooleanField, HTMLField, ArrayField } =
  foundry.data.fields;

/** How much one grid square of stockpile holds. */
export const UNITS_PER_SQUARE = 50;

export const FUNCTIONS = [
  "stockpile", "generator", "battery", "bench", "bed", "turret",
  "farm", "light", "climate", "recreation", "defence", "other"
];

/**
 * A colony structure.
 *
 * Terrain is not this. Walls, floors and doors stay as tiles and wall
 * segments — there are hundreds of them and they hold nothing worth
 * tracking. A structure actor is for the fifteen or thirty things that
 * have hit points, draw power, hold goods or shoot at people.
 */
export class Zed00Structure extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),

      function: new StringField({ choices: FUNCTIONS, initial: "other" }),

      health: new SchemaField({
        value: new NumberField({ integer: true, initial: 20 }),
        max:   new NumberField({ integer: true, initial: 20 })
      }),
      condition: new StringField({
        choices: ["pristine", "damaged", "broken", "destroyed"], initial: "pristine" }),

      // Footprint in grid squares. Drives stockpile capacity.
      squares: new NumberField({ integer: true, min: 1, initial: 1 }),

      // Power. Generators give, everything else takes.
      power: new SchemaField({
        output: new NumberField({ integer: true, min: 0, initial: 0 }),
        draw:   new NumberField({ integer: true, min: 0, initial: 0 }),
        // Solar and wind stop in bad weather; the week engine knows which.
        weatherDependent: new BooleanField({ initial: false }),
        running: new BooleanField({ initial: true })
      }),

      // Upkeep per week, as a material and an amount.
      upkeep: new SchemaField({
        material: new StringField({ initial: "" }),
        amount:   new NumberField({ integer: true, min: 0, initial: 0 })
      }),

      build: new SchemaField({
        materials: new StringField({ initial: "" }),
        bench:     new StringField({ initial: "none" }),
        weeks:     new NumberField({ integer: true, min: 0, initial: 0 })
      }),

      // --- stockpile ---------------------------------------------------
      // Goods are held as batches so spoilage has something to expire.
      contents: new ArrayField(new SchemaField({
        name:   new StringField({ initial: "" }),
        units:  new NumberField({ integer: true, min: 0, initial: 0 }),
        spoils: new NumberField({ integer: true, min: 0, initial: 0 })   // 0 = never
      }), { initial: [] }),
      freezing: new BooleanField({ initial: false }),
      covered:  new BooleanField({ initial: true }),

      // --- turret ------------------------------------------------------
      attacks: new ArrayField(new SchemaField({
        name:    new StringField({ initial: "Turret" }),
        bonus:   new NumberField({ integer: true, initial: 2 }),
        damage:  new StringField({ initial: "1d8" }),
        count:   new NumberField({ integer: true, min: 1, initial: 1 }),
        shock:   new NumberField({ integer: true, min: 0, initial: 0 }),
        shockAC: new NumberField({ integer: true, min: 0, initial: 0 }),
        range:   new StringField({ initial: "" }),
        note:    new StringField({ initial: "" })
      }), { initial: [] }),
      armorClass: new NumberField({ integer: true, initial: 14 }),

      // --- farm --------------------------------------------------------
      crop: new SchemaField({
        name:    new StringField({ initial: "" }),
        yield:   new NumberField({ integer: true, min: 0, initial: 175 }),
        checks:  new NumberField({ integer: true, min: 0, max: 4, initial: 0 }),
        steps:   new NumberField({ integer: true, initial: 0 }),   // 25% each
        failures: new NumberField({ integer: true, min: 0, initial: 0 }),
        lost:    new BooleanField({ initial: false })
      }),

      // --- bed ---------------------------------------------------------
      quality: new StringField({
        choices: ["none", "bedroll", "basic", "private"], initial: "basic" }),
      sleeps: new NumberField({ integer: true, min: 0, initial: 1 })
    };
  }

  prepareDerivedData() {
    const c = this.condition;
    this.usable = c !== "destroyed";
    this.bloodied = this.health.value <= Math.floor(this.health.max / 2);

    // Broken buildings do not do their job.
    this.working = this.usable && c !== "broken" && this.power.running;

    // --- stockpile ---------------------------------------------------
    this.capacity = this.squares * UNITS_PER_SQUARE;
    this.stored = (this.contents ?? []).reduce((n, b) => n + (b.units ?? 0), 0);
    this.spare = this.capacity - this.stored;
    this.overCapacity = this.stored > this.capacity;
    this.fillPercent = this.capacity ? Math.round((this.stored / this.capacity) * 100) : 0;

    // --- power -------------------------------------------------------
    this.netPower = this.working ? (this.power.output - this.power.draw) : -0;
    this.effectiveOutput = this.working ? this.power.output : 0;
    this.effectiveDraw = this.usable ? this.power.draw : 0;

    // --- farm --------------------------------------------------------
    // Each result moves the harvest a 25% step, capped at 150%.
    const mult = Math.max(0, Math.min(6, 4 + (this.crop.steps ?? 0))) / 4;
    this.crop.multiplier = mult;
    this.crop.projected = this.crop.lost ? 0 : Math.floor(this.crop.yield * mult);
    this.crop.ready = (this.crop.checks ?? 0) >= 4 && !this.crop.lost;
    this.crop.weeksLeft = Math.max(0, 4 - (this.crop.checks ?? 0));
  }
}
