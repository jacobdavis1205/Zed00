const { SchemaField, NumberField, StringField, BooleanField, HTMLField } = foundry.data.fields;

const BENCHES = ["none", "forge", "hand-tailor", "machining", "fabrication"];
const CONDITIONS = ["pristine", "damaged", "broken", "destroyed"];

const price = () => new SchemaField({
  buy:  new NumberField({ integer: true, min: 0, initial: 0 }),
  sell: new NumberField({ integer: true, min: 0, initial: 0 })
});

const physical = () => ({
  description: new HTMLField(),
  // Deliberately not an integer. Bulk materials weigh a fraction of an
  // Encumbrance each, which is the only way a warehouse full of metal and
  // a backpack can be measured on the same scale.
  encumbrance: new NumberField({ min: 0, initial: 1 }),
  quantity:    new NumberField({ integer: true, min: 0, initial: 1 }),
  bench:       new StringField({ choices: BENCHES, initial: "none" }),
  price:       price(),
  stowed:      new BooleanField({ initial: false }),
  homemade:    new BooleanField({ initial: false }),  // only homemade gear takes a mod

  // Spoilage. `shelfLife` is how many weeks this keeps once it is put
  // away; `spoilsOn` is the week it actually goes off, stamped when it
  // lands in a stockpile. Zero shelf life means it keeps indefinitely.
  shelfLife:   new NumberField({ integer: true, min: 0, initial: 0 }),
  spoilsOn:    new NumberField({ integer: true, min: 0, initial: 0 }),
  // Wood, textiles and anything that was once alive lose a quarter a week
  // on an uncovered pile. Metal and stone sit out in the rain quite happily.
  organic:     new BooleanField({ initial: false })
});

/* ------------------------------------------------------------------ */

export class Zed00Weapon extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      category:  new StringField({ choices: ["melee", "ranged", "heavy"], initial: "melee" }),
      damage:    new StringField({ initial: "1d6" }),
      shock:     new SchemaField({
        damage: new NumberField({ integer: true, min: 0, initial: 0 }),
        ac:     new NumberField({ integer: true, min: 0, initial: 0 })
      }),
      range:     new SchemaField({
        short: new NumberField({ integer: true, min: 0, initial: 0 }),
        long:  new NumberField({ integer: true, min: 0, initial: 0 })
      }),
      magazine:  new NumberField({ integer: true, min: 0, initial: 0 }),
      ammo:      new NumberField({ integer: true, min: 0, initial: 0 }),
      ammoPool:  new StringField({ initial: "" }),
      // Whether what is currently in the magazine is plasteel. Set by the
      // reload, because once rounds are in the gun they are a count and
      // no longer know which box they came from — and a shot's effect
      // depends on it, so the gun has to remember.
      loadedTl4: new BooleanField({ initial: false }),
      attribute: new StringField({ initial: "str" }),
      burst:     new BooleanField({ initial: false }),
      ballistic: new BooleanField({ initial: false }),
      unarmed:   new BooleanField({ initial: false }),
      // Pair this weapon with an off-hand to dual-wield automatically.
      offhandId: new StringField({ initial: "" }),
      // Which skill swings it. Blank falls back to the category default.
      skill:     new StringField({ initial: "" }),
      special:   new StringField({ initial: "" }),
      tl4:       new BooleanField({ initial: false }),
      twoHanded: new BooleanField({ initial: false }),
      reach:     new BooleanField({ initial: false }),
      condition: new StringField({ choices: CONDITIONS, initial: "pristine" }),
      mod:       new StringField({ initial: "" }),
      modUuid:   new StringField({ initial: "" })
    };
  }

  prepareDerivedData() {
    // Broken gear still works, badly. Destroyed gear does not work at all.
    const c = this.condition;
    this.penalties = {
      toHit:  c === "damaged" ? -1 : c === "broken" ? -1 : 0,
      damage: c === "broken" ? -2 : 0,
      noShock: c === "broken"
    };
    this.usable = c !== "destroyed";
    // Enc 1 weapons can be used one-handed; anything heavier needs both.
    this.oneHanded = this.encumbrance <= 1;
    this.canOffhand = this.oneHanded && this.mod !== "Stripped Frame";
    // Durability Save threshold by bench tier.
    this.durability = { none: 5, forge: 4, "hand-tailor": 4, machining: 3, fabrication: 2 }[this.bench] ?? 5;

    // Which skill this weapon uses, unless it says otherwise.
    this.skillName = this.skill
      || (this.unarmed ? "Punch" : this.category === "melee" ? "Stab" : "Shoot");
  }
}

export class Zed00Armor extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      ac:        new NumberField({ integer: true, min: 10, initial: 13 }),
      powered:   new BooleanField({ initial: false }),
      condition: new StringField({ choices: CONDITIONS, initial: "pristine" }),
      mod:       new StringField({ initial: "" }),
      modUuid:   new StringField({ initial: "" }),
      equipped:  new BooleanField({ initial: false })
    };
  }

  prepareDerivedData() {
    const c = this.condition;
    this.effectiveAC = this.ac + (c === "damaged" ? -1 : c === "broken" ? -2 : 0);
    this.usable = c !== "destroyed";
    // Powered armor: DR 7 and total Shock immunity vs primitive and TL3.
    this.dr = this.powered && c !== "broken" ? 7 : 0;
    this.shockImmune = this.powered && c !== "broken";
    // Enc 1 armor can be slept in. Anything heavier cannot.
    this.sleepable = this.encumbrance <= 1;
    // Durability Save threshold, same bench ladder as weapons.
    this.durability = { none: 5, forge: 4, "hand-tailor": 4, machining: 3, fabrication: 2 }[this.bench] ?? 5;
  }
}

export class Zed00Modification extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      drawback:    new StringField({ initial: "" }),
      materials:   new StringField({ initial: "" }),
      bench:       new StringField({ choices: BENCHES, initial: "forge" }),
      slot:        new StringField({ choices: ["weapon", "armor"], initial: "weapon" }),
      restriction: new StringField({ initial: "" })   // e.g. "ballistic only"
    };
  }
}

export class Zed00Drug extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      buffer:    new NumberField({ integer: true, min: 0, initial: 0 }),
      benefit:   new StringField({ initial: "" }),
      drawback:  new StringField({ initial: "" }),
      freeDoses: new NumberField({ integer: true, min: 0, initial: 4 }),
      taken:     new NumberField({ integer: true, min: 0, initial: 0 })
    };
  }
  prepareDerivedData() {
    this.overLimit = Math.max(0, this.taken - this.freeDoses);
    this.dependencyRisk = this.overLimit * 5;   // roll 1d20, dependent on <= this
  }
}

export class Zed00Cyberware extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      band:     new StringField({ choices: ["minor", "standard", "major"], initial: "standard" }),
      slot:     new StringField({ initial: "" }),
      installed: new BooleanField({ initial: false }),
      price:    price()
    };
  }
  prepareDerivedData() {
    // Strain cost is permanent and comes off the maximum pool.
    this.strainCost = this.band === "major" ? 2 : 1;
    this.installTN = 10;
    this.removeTN = 14;
  }
}

export class Zed00Power extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      discipline: new StringField({
        choices: ["biopsionics", "telepathy", "telekinesis"], initial: "biopsionics" }),
      tier:     new NumberField({ integer: true, min: 1, max: 4, initial: 1 }),
      effort:   new NumberField({ integer: true, min: 0, initial: 1 }),
      duration: new StringField({ choices: ["instant", "scene", "day"], initial: "instant" })
    };
  }
}

export class Zed00Gear extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      condition: new StringField({ choices: CONDITIONS, initial: "pristine" }),

      // Exposure gear. A parka does nothing against toxins and a gas mask
      // does nothing against a blizzard, so each piece names its hazard
      // and the weekly turn applies it only when that hazard is the one
      // actually biting.
      mitigates: new StringField({
        choices: ["none", "cold", "heat", "air", "precipitation"], initial: "none" }),
      mitigation: new NumberField({ integer: true, min: 0, initial: 0 }),
      charges:    new NumberField({ integer: true, min: 0, initial: 0 }),
      chargesMax: new NumberField({ integer: true, min: 0, initial: 0 })
    };
  }
  prepareDerivedData() {
    this.durability = { none: 5, forge: 4, "hand-tailor": 4, machining: 3, fabrication: 2 }[this.bench] ?? 5;
    this.usable = this.condition !== "destroyed";
    // Spent gear mitigates nothing until it is replaced or recharged.
    this.spent = this.chargesMax > 0 && this.charges <= 0;
    this.protects = this.mitigates !== "none" && this.usable && !this.spent;
  }
}

/**
 * Ammunition, as a thing you carry rather than a number on your sheet.
 *
 * The old model was a counter per pool on the actor, which worked right
 * up to the point where somebody wanted to leave half their rifle rounds
 * in a shed, hand a box to a colonist, or put them on a pack mule. A
 * counter cannot be anywhere; an item can.
 *
 * `quantity` is rounds, not boxes — a purchase or a batch is twenty, and
 * Encumbrance is worked out from the round count so that a hundred spare
 * rifle rounds cost you something to carry.
 */
export class Zed00Ammo extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      ...physical(),
      // Which weapons it feeds. The pools are the handbook's own.
      pool: new StringField({
        choices: ["arrows", "pistol", "shotgun", "smg", "rifle", "charged",
                  "grenade", "incendiary", "mortar"],
        initial: "pistol" }),
      // Plasteel in place of every unit of Metal makes the batch TL4.
      tl4: new BooleanField({ initial: false }),
      // How many rounds weigh one Encumbrance. Twenty is a purchase, a
      // crafted batch, and near enough a loaded magazine.
      per: new NumberField({ integer: true, min: 1, initial: 20 }),
      // Ordnance is counted one at a time and each piece is heavy.
      ordnance: new BooleanField({ initial: false })
    };
  }

  prepareDerivedData() {
    const rounds = Math.max(0, Number(this.quantity) || 0);
    // Encumbrance is per batch, rounded up — nineteen rounds and twenty
    // both weigh one, which is the honest answer and the kind one.
    this.batches = Math.ceil(rounds / this.per);
    this.bulk = this.ordnance
      ? Math.round(rounds * this.encumbrance * 10) / 10
      : this.batches * this.encumbrance;
    this.unit = this.ordnance ? "each" : `per ${this.per}`;
  }
}

export class Zed00Focus extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      level:   new NumberField({ integer: true, min: 1, max: 2, initial: 1 }),
      combat:  new BooleanField({ initial: false })
    };
  }
}

export class Zed00Xenotype extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      features: new foundry.data.fields.ArrayField(
        new SchemaField({
          name: new StringField({ initial: "" }),
          text: new StringField({ initial: "" })
        }), { initial: [] })
    };
  }
}

export class Zed00Skill extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      description: new HTMLField(),
      level:     new NumberField({ integer: true, min: -1, max: 4, initial: -1 }),
      attribute: new StringField({ initial: "int" }),
      combat:    new BooleanField({ initial: false }),
      misc:      new NumberField({ integer: true, initial: 0 })
    };
  }
}
