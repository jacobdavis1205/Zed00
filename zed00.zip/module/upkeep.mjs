/**
 * The upkeep tally.
 *
 * Reads what is standing on the map and says what it costs to keep
 * standing: Power against Capacity, and how many weeks of Wood and Fuel
 * are left in the stores at the current burn.
 *
 * It stores nothing. Every number is derived from the structures, so
 * building a generator changes the tally without anybody typing anything,
 * and a structure that is broken or switched off stops counting the
 * moment it stops working. That was the whole point of putting colony
 * buildings on the map as actors.
 */

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

import { placedStructures as structures, colonyScene, unplacedStructures as unplaced }
  from "./structures.mjs";

/** Everything in every stockpile on the map, totalled by name. */
function stores() {
  const total = new Map();
  for (const pile of structures()) {
    if (pile.system.function !== "stockpile") continue;
    for (const good of pile.items) {
      const n = good.name.trim();
      total.set(n, (total.get(n) ?? 0) + (Number(good.system.quantity) || 0));
    }
  }
  return total;
}

/**
 * What a weather-dependent generator makes this week.
 *
 * Wind is rated 10–20 variable in the book, so a windy week runs it at
 * the ceiling and a still one at nothing. Solar either works or it does
 * not.
 */
function weatherOutput(sys, weather) {
  if (!sys.power.weatherDependent) return sys.power.output;
  const solarOff = weather?.solar === false;
  const isWind = sys.power.output <= 10;      // the turbine's floor
  if (isWind) {
    if (weather?.wind === true) return sys.power.output * 2;
    if (weather?.wind === false) return 0;
    return sys.power.output;
  }
  return solarOff ? 0 : sys.power.output;
}

/**
 * Add up the colony.
 *
 * `weather` is optional: pass this week's weather and the tally shows
 * what the grid does under it as well as on a fair week, which is the
 * difference between "we have enough" and "we have enough today".
 */
export function tally(weather = null) {
  const all = structures();
  const produced = [], batteries = [], drawing = [], burning = [], idle = [];

  let output = 0, capacity = 0, draw = 0, fairOutput = 0;

  for (const a of all) {
    const sys = a.system;
    const working = sys.working;

    if (sys.power.output > 0) {
      const now = working ? weatherOutput(sys, weather) : 0;
      const fair = working ? sys.power.output : 0;
      output += now;
      fairOutput += fair;
      produced.push({ name: a.name, now, fair, working,
                      weather: sys.power.weatherDependent });
    }
    if (sys.power.capacity > 0) {
      capacity += working ? sys.power.capacity : 0;
      batteries.push({ name: a.name, adds: sys.power.capacity, working });
    }
    if (sys.power.draw > 0) {
      draw += working ? sys.power.draw : 0;
      if (working) drawing.push({ name: a.name, draw: sys.power.draw });
      else idle.push({ name: a.name, draw: sys.power.draw,
                       why: sys.condition !== "pristine" && sys.condition !== "damaged"
                         ? sys.condition : "switched off" });
    }
    if (sys.upkeep.amount > 0 && sys.upkeep.material) {
      if (working) {
        burning.push({ name: a.name, amount: sys.upkeep.amount,
                       material: sys.upkeep.material });
      }
    }
  }

  // Fuel and wood, by material, against what is in the sheds.
  const held = stores();
  const fuels = new Map();
  for (const b of burning) {
    const key = b.material;
    const f = fuels.get(key) ?? { material: key, perWeek: 0, users: [] };
    f.perWeek += b.amount;
    f.users.push(b);
    fuels.set(key, f);
  }
  for (const f of fuels.values()) {
    // Stock may be filed under a slightly different name — "Fuel" against
    // "Chemfuel" is near enough. Exact match wins; otherwise anything
    // that contains the name, or is contained by it, counts. Whatever it
    // matched is reported, because "you have no wood" with no reason is
    // how this went wrong in the first place.
    const want = f.material.trim().toLowerCase();
    let have = 0;
    const matched = [];
    for (const [name, qty] of held) {
      if (name.trim().toLowerCase() === want) { have += qty; matched.push(name); }
    }
    if (!matched.length) {
      for (const [name, qty] of held) {
        const got = name.trim().toLowerCase();
        if (got.includes(want) || want.includes(got)) { have += qty; matched.push(name); }
      }
    }
    f.have = have;
    f.matched = matched;
    f.weeksLeft = f.perWeek > 0 ? Math.floor(have / f.perWeek) : Infinity;
  }

  const totalCapacity = output + capacity;
  const fairCapacity = fairOutput + capacity;

  return {
    produced: produced.sort((x, y) => y.now - x.now),
    batteries, drawing: drawing.sort((x, y) => y.draw - x.draw), idle,
    idleDraw: idle.reduce((n, d) => n + d.draw, 0),
    fuels: [...fuels.values()].sort((a, b) => a.weeksLeft - b.weeksLeft),
    output, capacity, draw, fairOutput,
    totalCapacity, fairCapacity,
    spare: totalCapacity - draw,
    fairSpare: fairCapacity - draw,
    over: draw > totalCapacity,
    overBy: Math.max(0, draw - totalCapacity),
    // A grid that only works on a fair week is a grid with a problem.
    fragile: draw <= fairCapacity && draw > totalCapacity,
    weather,
    structures: all.length,
    // Where the numbers came from, so a surprising total can be checked.
    scene: colonyScene()?.name ?? "no scene",
    piles: all.filter(a => a.system.function === "stockpile").length,
    held: [...held.entries()].sort((a, b) => b[1] - a[1])
      .map(([name, qty]) => ({ name, qty })),
    unplaced: unplaced().length
  };
}

/* ------------------------------------------------------------------ */

export class Zed00UpkeepSheet extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "zed00-upkeep",
    classes: ["zed00", "sheet", "upkeep-sheet"],
    position: { width: 520, height: 680 },
    window: { title: "Colony Upkeep", icon: "fas fa-bolt", resizable: true },
    actions: { refresh: Zed00UpkeepSheet.#refresh }
  };

  static PARTS = { body: { template: "systems/zed00/templates/upkeep.hbs" } };

  /** This week's weather, so the tally can show today as well as fair. */
  weather = null;

  async _prepareContext() {
    const t = tally(this.weather);
    return {
      t,
      // Weeks of fuel is the number a GM actually acts on, so lead with it.
      worst: t.fuels.length ? t.fuels[0] : null,
      hasFuel: t.fuels.length > 0,
      isGM: game.user.isGM
    };
  }

  static async #refresh() {
    this.render();
  }

  /**
   * Keep the tally live while it is open.
   *
   * Token hooks matter as much as actor hooks here: the buildings are
   * tokens, so placing, moving between scenes or deleting one changes
   * the numbers without any actor being touched.
   */
  _onFirstRender(context, options) {
    super._onFirstRender?.(context, options);
    const redraw = foundry.utils.debounce(() => this.render(), 100);
    const mine = (doc) => doc?.type === "structure" ||
                          doc?.actor?.type === "structure" ||
                          doc?.parent?.type === "structure" ||
                          doc?.parent?.parent?.type === "structure";

    this.#watching = [
      ["updateActor", (a) => { if (mine(a)) redraw(); }],
      ["createActor", (a) => { if (mine(a)) redraw(); }],
      ["deleteActor", (a) => { if (mine(a)) redraw(); }],
      ["createToken", (t) => { if (mine(t)) redraw(); }],
      ["updateToken", (t) => { if (mine(t)) redraw(); }],
      ["deleteToken", (t) => { if (mine(t)) redraw(); }],
      ["createItem", (i) => { if (mine(i)) redraw(); }],
      ["updateItem", (i) => { if (mine(i)) redraw(); }],
      ["deleteItem", (i) => { if (mine(i)) redraw(); }],
      ["canvasReady", () => redraw()]
    ].map(([name, fn]) => [name, Hooks.on(name, fn)]);
  }

  #watching = [];

  _onClose(options) {
    super._onClose?.(options);
    for (const [name, id] of this.#watching) Hooks.off(name, id);
    this.#watching = [];
  }
}

let open;

/** Show the tally, optionally under a particular week's weather. */
export function openUpkeep(weather = null) {
  open ??= new Zed00UpkeepSheet();
  open.weather = weather;
  open.render(true);
  return open;
}
