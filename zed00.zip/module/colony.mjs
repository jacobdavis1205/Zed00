/**
 * The colony at a glance.
 *
 * Nothing here is stored. Every figure is read off the map and the
 * sheets at the moment you open it, which is the same rule the rest of
 * the system runs on — the map is the source of truth, and a summary
 * that caches is a summary that lies.
 *
 * Four questions, in the order a GM actually asks them: who is here,
 * what have we built, what have we got, and how much is it all worth to
 * somebody who wants it.
 */

import { placedStructures, placedStockpiles, colonyScene, colonySceneIsSet,
         viewingElsewhere } from "./structures.mjs";
import { tally } from "./upkeep.mjs";
import { currentDate } from "./dates.mjs";
import { FOODS } from "./rations.mjs";
import { structureWorth } from "./build-cost.mjs";

/* ------------------------------------------------------------------ */
/*  Wealth                                                             */
/* ------------------------------------------------------------------ */

/**
 * The bands that decide what comes over the hill.
 *
 * Same shape as a caravan's, scaled for a settlement rather than a
 * column on the road. A raid is drawn against the tier, so this is the
 * number that turns a quiet winter into an expensive one.
 */
export const COLONY_BANDS = [
  { tier: 0, upto: 1500,     label: "Beneath notice",
    raid: "Scavenger Raiders, a handful at most" },
  { tier: 1, upto: 5000,     label: "Worth a look",
    raid: "Scavenger Raiders in numbers, or a few Raiders" },
  { tier: 2, upto: 15000,    label: "Worth robbing",
    raid: "Raiders, organised, with a plan for the walls" },
  { tier: 3, upto: 40000,    label: "Worth planning for",
    raid: "Raiders led by a Warband Elite" },
  { tier: 4, upto: 100000,   label: "Worth a war party",
    raid: "Warband Elites, several, and they know the layout" },
  { tier: 5, upto: Infinity, label: "Worth taking",
    raid: "Everything a faction can send, and mechanoids take an interest" }
];

/**
 * What a raider is actually coming for.
 *
 * Walls and turrets are not loot. Counting them toward the wealth that
 * draws a raid would mean every course of stone makes the colony a
 * richer-looking prize, so fortifying would summon exactly what it was
 * built to stop. They are reported, because what a colony has spent on
 * not being robbed is worth seeing — they just do not attract anybody.
 */
const DEFENSIVE = new Set(["wall", "turret"]);

export function bandFor(total) {
  return COLONY_BANDS.find(b => total < b.upto) ?? COLONY_BANDS.at(-1);
}

/** What one item contributes, priced the way everything else here is. */
function worthOf(item) {
  const s = item.system ?? {};
  const buy = Number(s.price?.buy) || 0;
  const qty = Number(s.quantity) || 0;
  // Ammunition is priced by the batch and counted by the round.
  if (item.type === "ammo") return buy * (qty / (Number(s.per) || 20));
  return buy * qty;
}

/* ------------------------------------------------------------------ */
/*  Reading the colony                                                 */
/* ------------------------------------------------------------------ */

/** Meals per unit, keyed the way a stockpile actually names its food. */
const MEALS_BY_NAME = new Map(FOODS.map(f => [f.name.toLowerCase(), f.meals]));

/** Everybody who lives here — people, not the things they stand next to. */
export function roster() {
  const scene = colonyScene();
  const out = [];
  const seen = new Set();

  // Colonists are linked actors with tokens on the colony map. Reading
  // the map rather than the sidebar means somebody on a caravan, or in
  // the insect nest, is not counted as being at home.
  for (const token of scene?.tokens ?? []) {
    const actor = token.actor;
    if (!actor || !["character", "colonist"].includes(actor.type)) continue;
    if (seen.has(actor.id)) continue;
    seen.add(actor.id);

    const sys = actor.system ?? {};
    out.push({
      id: actor.id,
      uuid: actor.uuid,
      name: actor.name,
      img: actor.img,
      type: actor.type,
      player: actor.type === "character",
      job: sys.job ?? "work",
      hp: Number(sys.health?.value) || 0,
      hpMax: Number(sys.health?.max) || 0,
      temp: Number(sys.health?.temp) || 0,
      strain: Number(sys.strain?.value) || 0,
      strainMax: Number(sys.strain?.max) || 0,
      buffer: Number(sys.strain?.buffer) || 0,
      exposure: Number(sys.exposure?.level) || 0,
      exposureLabel: sys.exposure?.label ?? "",
      hunger: sys.hunger?.tier ?? "Fed",
      morale: Number(sys.morale?.value) || 0,
      moraleMax: Number(sys.morale?.max) || 0,
      bloodied: !!sys.conditions?.bloodied,
      unstable: !!sys.conditions?.unstable,
      // What is actually wrong with this person, if anything.
      hurt: (Number(sys.health?.value) || 0) < (Number(sys.health?.max) || 0),
      worth: (actor.items ?? []).reduce((n, i) => n + worthOf(i), 0)
    });
  }
  return out.sort((a, b) =>
    Number(b.player) - Number(a.player) || a.name.localeCompare(b.name));
}

/** What has been built, gathered by what it is for. */
export function built() {
  const groups = new Map();
  let broken = 0, unpowered = 0, total = 0;
  let spoils = 0, defences = 0;

  for (const s of placedStructures()) {
    const sys = s.system ?? {};
    const fn = sys.function ?? "other";
    total++;

    const g = groups.get(fn) ?? { function: fn, count: 0, kinds: new Map(),
                                  damaged: 0, worth: 0 };
    g.count++;
    g.kinds.set(s.name, (g.kinds.get(s.name) ?? 0) + 1);
    // Structures carry a recipe, not a price, so what one is worth is
    // what it took to put up — reduced by however battered it is.
    const worth = structureWorth(s);
    g.worth += worth;
    g.defensive = DEFENSIVE.has(fn);
    if (g.defensive) defences += worth; else spoils += worth;

    const hp = Number(sys.health?.value) || 0;
    const max = Number(sys.health?.max) || 0;
    if (max && hp < max) { g.damaged++; broken++; }
    if (sys.powerDraw > 0 && !sys.working) unpowered++;

    groups.set(fn, g);
  }

  return {
    total, broken, unpowered,
    spoils: Math.round(spoils),
    defences: Math.round(defences),
    standing: Math.round(spoils + defences),
    groups: [...groups.values()]
      .map(g => ({ ...g,
        kinds: [...g.kinds.entries()]
          .map(([name, n]) => ({ name, n }))
          .sort((a, b) => b.n - a.n || a.name.localeCompare(b.name)) }))
      .sort((a, b) => b.count - a.count)
  };
}

/** What is in the sheds, gathered by what it is. */
export function stores() {
  const kinds = new Map();
  let worth = 0, meals = 0, spoiling = 0, spoiled = 0;
  const week = currentDate().week;

  for (const pile of placedStockpiles()) {
    for (const item of pile.items ?? []) {
      const s = item.system ?? {};
      const qty = Number(s.quantity) || 0;
      if (!qty) continue;

      const row = kinds.get(item.name) ?? {
        name: item.name, img: item.img, type: item.type,
        qty: 0, worth: 0, enc: 0, spoilsOn: null
      };
      row.qty += qty;
      row.worth += worthOf(item);
      row.enc += item.type === "ammo"
        ? (Number(s.bulk) || 0)
        : (Number(s.encumbrance) || 0) * qty;

      const on = Number(s.spoilsOn) || 0;
      if (on) {
        // Soonest expiry is the one that matters for a warning.
        row.spoilsOn = row.spoilsOn === null ? on : Math.min(row.spoilsOn, on);
        if (on <= week) spoiled += qty;
        else if (on - week <= 2) spoiling += qty;
      }

      // Food is the figure a colony actually lives or dies by. Matched by
      // name, the same way consumeRations() finds it, so the two can
      // never disagree about what counts as a meal.
      const per = MEALS_BY_NAME.get(item.name.trim().toLowerCase()) ?? 0;
      if (per > 0) meals += per * qty;

      worth += worthOf(item);
      kinds.set(item.name, row);
    }
  }

  return {
    worth: Math.round(worth),
    meals,
    spoiling, spoiled,
    rows: [...kinds.values()]
      .map(r => ({ ...r,
        worth: Math.round(r.worth),
        enc: Math.round(r.enc * 10) / 10,
        left: r.spoilsOn === null ? null : r.spoilsOn - week,
        expired: r.spoilsOn !== null && r.spoilsOn <= week }))
      .sort((a, b) => b.worth - a.worth || a.name.localeCompare(b.name))
  };
}

/**
 * Everything together, with the wealth tier that drives raids.
 *
 * Three components, the same three a caravan uses: what is stored, what
 * is standing, and what the people are carrying. A colony is worth
 * robbing for its sheds and its walls alike.
 */
export function summary() {
  const people = roster();
  const structures = built();
  const goods = stores();

  const carried = Math.round(people.reduce((n, p) => n + p.worth, 0));
  // Only what is worth carrying away. Defences are built value too, and
  // are reported beside it, but nobody raids a colony for its sandbags.
  const total = goods.worth + structures.spoils + carried;

  const heads = people.length;
  const band = bandFor(total);

  let power = null;
  try { power = tally(); } catch { power = null; }

  return {
    date: currentDate(),
    scene: colonyScene(),
    sceneSet: colonySceneIsSet(),
    elsewhere: viewingElsewhere(),

    people, structures, goods, power,

    wealth: {
      stored: goods.worth,
      standing: structures.spoils,
      defences: structures.defences,
      carried, total, ...band
    },

    heads,
    // Seven meals a head a week is the colony rule, on the road or at home.
    weeksOfFood: heads ? Math.floor(goods.meals / (heads * 7)) : null,
    hurt: people.filter(p => p.hurt || p.bloodied).length,
    unstable: people.filter(p => p.unstable).length,
    exposed: people.filter(p => p.exposure > 0).length,
    hungry: people.filter(p => p.hunger && p.hunger !== "Fed").length
  };
}
