/**
 * Compendium population.
 *
 * Compiling LevelDB packs needs the Foundry CLI and a build step, which
 * is more machinery than this system wants. Instead the item data ships
 * as plain JSON and gets loaded into the packs the first time a world
 * runs — or whenever the GM asks for it again.
 */

const PACKS = {
  weapons:       "weapons.json",
  armor:         "armor.json",
  modifications: "modifications.json",
  drugs:         "drugs.json",
  cyberware:     "cyberware.json",
  powers:        "powers.json",
  foci:          "foci.json",
  xenotypes:     "xenotypes.json",
  gear:          "gear.json",
  skills:        "skills.json",
  materials:     "materials.json"
};

const ACTOR_PACKS = {
  bestiary:   "bestiary.json",
  animals:    "animals.json",
  structures: "structures.json"
};

const TABLE_PACKS = { tables: "tables.json" };

const FLAG = "packsVersion";
const CURRENT = 6;

/** Load one JSON file bundled with the system. */
async function readSource(file) {
  const res = await fetch(`systems/zed00/packs-source/${file}`);
  if (!res.ok) throw new Error(`Could not read packs-source/${file}`);
  return res.json();
}

/**
 * Fill a single compendium.
 *
 * Normally this only adds what is missing, so anything the GM has edited
 * in their own world survives an update. In `replace` mode the shipped
 * entries are deleted and re-imported instead, which is how a corrected
 * stat block actually reaches a world that already has the old one.
 */
async function fillPack(name, file, { replace = false } = {}) {
  const pack = game.packs.get(`zed00.${name}`);
  if (!pack) return { name, created: 0, replaced: 0, skipped: 0, error: "pack not found" };

  const wasLocked = pack.locked;
  if (wasLocked) await pack.configure({ locked: false });

  try {
    const docs = await readSource(file);
    const index = await pack.getIndex();
    const have = new Map(index.map(e => [e.name, e._id]));
    const cls = { Actor, Item, RollTable }[pack.documentName] ?? Item;

    let replaced = 0;
    if (replace) {
      const stale = docs.map(d => have.get(d.name)).filter(Boolean);
      if (stale.length) {
        await cls.deleteDocuments(stale, { pack: pack.collection });
        replaced = stale.length;
        for (const d of docs) have.delete(d.name);
      }
    }

    const toCreate = docs.filter(d => !have.has(d.name));
    if (toCreate.length) {
      await cls.createDocuments(toCreate, { pack: pack.collection, keepId: false });
    }
    return {
      name,
      created: toCreate.length - replaced,
      replaced,
      skipped: docs.length - toCreate.length
    };
  } catch (err) {
    console.error(`Zed-00 | ${name}:`, err);
    return { name, created: 0, replaced: 0, skipped: 0, error: err.message };
  } finally {
    if (wasLocked) await pack.configure({ locked: true });
  }
}

/** Populate everything. Safe to run more than once. */
export async function populatePacks({ notify = true, replace = false } = {}) {
  if (!game.user.isGM) return;
  const results = [];
  for (const [name, file] of Object.entries({ ...PACKS, ...ACTOR_PACKS, ...TABLE_PACKS })) {
    results.push(await fillPack(name, file, { replace }));
  }
  const made = results.reduce((n, r) => n + r.created, 0);
  const redone = results.reduce((n, r) => n + r.replaced, 0);
  const failed = results.filter(r => r.error);

  if (notify) {
    const parts = [];
    if (made) parts.push(`added ${made}`);
    if (redone) parts.push(`refreshed ${redone}`);
    if (parts.length) ui.notifications.info(`Zed-00: ${parts.join(", ")} compendium entries.`);
    else if (!failed.length) ui.notifications.info("Zed-00: compendiums already up to date.");
    for (const f of failed) ui.notifications.error(`Zed-00: ${f.name} — ${f.error}`);
  }
  console.table(results);
  return results;
}

/** Run once per world, unless the GM asks again from the settings menu. */
export function registerPackHooks() {
  game.settings.register("zed00", FLAG, {
    scope: "world", config: false, type: Number, default: 0
  });

  game.settings.registerMenu("zed00", "rebuildPacks", {
    name: "Add missing compendium entries",
    label: "Add missing",
    hint: "Re-reads the bundled data and adds anything the compendiums don't have yet. Entries already present — including ones you have edited — are left alone.",
    icon: "fas fa-box-open",
    type: class extends FormApplication {
      render() { populatePacks(); return this; }
    },
    restricted: true
  });

  game.settings.registerMenu("zed00", "refreshPacks", {
    name: "Refresh compendiums from the system",
    label: "Refresh all",
    hint: "Deletes every shipped entry and re-imports it, so corrected stat blocks replace the old ones. Your own edits to shipped entries are discarded; anything you created yourself is untouched. Actors already on a scene keep their current data.",
    icon: "fas fa-rotate",
    type: class extends FormApplication {
      render() {
        const D = foundry.applications?.api?.DialogV2 ?? Dialog;
        if (D.confirm) {
          D.confirm({
            window: { title: "Refresh compendiums" },
            content: "<p>Replace every shipped compendium entry with the version bundled in the system?</p><p>Edits you made to shipped entries will be lost. Items you created yourself, and actors already placed on a scene, are not touched.</p>",
            yes: { callback: () => populatePacks({ replace: true }) }
          });
        } else populatePacks({ replace: true });
        return this;
      }
    },
    restricted: true
  });

  Hooks.once("ready", async () => {
    if (!game.user.isGM) return;
    if (game.settings.get("zed00", FLAG) >= CURRENT) return;
    await populatePacks({ notify: true });
    await game.settings.set("zed00", FLAG, CURRENT);
  });
}
