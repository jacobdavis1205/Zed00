/**
 * Compendium population.
 *
 * Compiling LevelDB packs needs the Foundry CLI and a build step, which
 * is more machinery than this system wants. Instead the item data ships
 * as plain JSON and gets loaded into the packs the first time a world
 * runs — or whenever the GM asks for it again.
 */

const PACKS = {
  weapons:       "weapons.json",
  armor:         "armor.json",
  modifications: "modifications.json",
  drugs:         "drugs.json",
  cyberware:     "cyberware.json",
  powers:        "powers.json",
  foci:          "foci.json",
  xenotypes:     "xenotypes.json",
  gear:          "gear.json",
  skills:        "skills.json",
  materials:     "materials.json"
};

const ACTOR_PACKS = {
  bestiary:   "bestiary.json",
  animals:    "animals.json",
  structures: "structures.json"
};

const TABLE_PACKS = { tables: "tables.json" };

const FLAG = "packsVersion";

/**
 * What triggers a repopulate.
 *
 * This used to be a number I bumped by hand on every release that
 * changed pack content — and forgot to bump on several that did, which
 * is why compendiums quietly stopped filling themselves. It is now
 * derived from the content: the files that ship and how many documents
 * are in each. Change anything and the signature changes with it.
 */
async function signature() {
  const files = { ...PACKS, ...ACTOR_PACKS, ...TABLE_PACKS };
  const counts = [];
  for (const [name, file] of Object.entries(files)) {
    try {
      const docs = await readSource(file);
      counts.push(`${name}:${docs.length}`);
    } catch {
      counts.push(`${name}:?`);
    }
  }
  return counts.join("|");
}

/** Load one JSON file bundled with the system. */
async function readSource(file) {
  const res = await fetch(`systems/zed00/packs-source/${file}`);
  if (!res.ok) throw new Error(`Could not read packs-source/${file}`);
  return res.json();
}

/**
 * Fill a single compendium.
 *
 * Normally this only adds what is missing, so anything the GM has edited
 * in their own world survives an update. In `replace` mode the shipped
 * entries are deleted and re-imported instead, which is how a corrected
 * stat block actually reaches a world that already has the old one.
 */
async function fillPack(name, file, { replace = false } = {}) {
  const pack = game.packs.get(`zed00.${name}`);
  if (!pack) return { name, created: 0, replaced: 0, skipped: 0, error: "pack not found" };

  const wasLocked = pack.locked;
  if (wasLocked) await pack.configure({ locked: false });

  try {
    const docs = await readSource(file);
    const index = await pack.getIndex();
    const have = new Map(index.map(e => [e.name, e._id]));
    const cls = { Actor, Item, RollTable }[pack.documentName] ?? Item;

    // Documents can name a folder; make the folders first and swap the
    // names for ids. Dragging a folder out of a compendium brings the
    // whole group across with its structure intact, which is the only
    // thing that keeps an Actors tab full of buildings navigable.
    const wanted = [...new Set(docs.map(d => d.folder).filter(f => typeof f === "string"))];
    const folderIds = new Map();
    if (wanted.length) {
      const existing = pack.folders ?? [];
      for (const f of existing) folderIds.set(f.name, f.id);
      const missing = wanted.filter(n => !folderIds.has(n));
      if (missing.length) {
        const made = await Folder.createDocuments(
          missing.map(name => ({ name, type: pack.documentName, color: "#5A5A5A" })),
          { pack: pack.collection });
        for (const f of made) folderIds.set(f.name, f.id);
      }
    }
    for (const d of docs) {
      if (typeof d.folder === "string") d.folder = folderIds.get(d.folder) ?? null;
    }

    let replaced = 0;
    if (replace) {
      const stale = docs.map(d => have.get(d.name)).filter(Boolean);
      if (stale.length) {
        await cls.deleteDocuments(stale, { pack: pack.collection });
        replaced = stale.length;
        for (const d of docs) have.delete(d.name);
      }
    }

    const toCreate = docs.filter(d => !have.has(d.name));
    if (toCreate.length) {
      await cls.createDocuments(toCreate, { pack: pack.collection, keepId: false });
    }
    return {
      name,
      created: toCreate.length - replaced,
      replaced,
      skipped: docs.length - toCreate.length
    };
  } catch (err) {
    console.error(`Zed-00 | ${name}:`, err);
    return { name, created: 0, replaced: 0, skipped: 0, error: err.message };
  } finally {
    if (wasLocked) await pack.configure({ locked: true });
  }
}

/** Populate everything. Safe to run more than once. */
export async function populatePacks({ notify = true, replace = false } = {}) {
  if (!game.user.isGM) return;
  const results = [];
  for (const [name, file] of Object.entries({ ...PACKS, ...ACTOR_PACKS, ...TABLE_PACKS })) {
    results.push(await fillPack(name, file, { replace }));
  }
  const made = results.reduce((n, r) => n + r.created, 0);
  const redone = results.reduce((n, r) => n + r.replaced, 0);
  const failed = results.filter(r => r.error);

  if (notify) {
    const parts = [];
    if (made) parts.push(`added ${made}`);
    if (redone) parts.push(`refreshed ${redone}`);
    if (parts.length) ui.notifications.info(`Zed-00: ${parts.join(", ")} compendium entries.`);
    else if (!failed.length) ui.notifications.info("Zed-00: compendiums already up to date.");
    for (const f of failed) ui.notifications.error(`Zed-00: ${f.name} — ${f.error}`);
  }
  console.table(results);
  return results;
}

/** Run once per world, unless the GM asks again from the settings menu. */
export function registerPackHooks() {
  // A content signature, not a version number — see signature() above.
  // Old worlds hold a number here; String() of it simply never matches a
  // signature, so they repopulate once and settle.
  game.settings.register("zed00", FLAG, {
    scope: "world", config: false, type: String, default: ""
  });

  game.settings.registerMenu("zed00", "rebuildPacks", {
    name: "Add missing compendium entries",
    label: "Add missing",
    hint: "Re-reads the bundled data and adds anything the compendiums don't have yet. Entries already present — including ones you have edited — are left alone.",
    icon: "fas fa-box-open",
    type: class extends FormApplication {
      render() { populatePacks(); return this; }
    },
    restricted: true
  });

  game.settings.registerMenu("zed00", "playerStructures", {
    name: "Let players use the colony's structures",
    label: "Grant access",
    hint: "Gives every existing structure Owner permission so players can drag goods in and out of stockpiles themselves. New structures already come this way. Structures stay hidden from the players' Actors tab either way.",
    icon: "fas fa-people-carry-box",
    type: class extends FormApplication {
      render() {
        import("./structures.mjs").then(m => m.grantPlayerAccess());
        return this;
      }
    },
    restricted: true
  });

  game.settings.registerMenu("zed00", "refreshPacks", {
    name: "Refresh compendiums from the system",
    label: "Refresh all",
    hint: "Deletes every shipped entry and re-imports it, so corrected stat blocks replace the old ones. Your own edits to shipped entries are discarded; anything you created yourself is untouched. Actors already on a scene keep their current data.",
    icon: "fas fa-rotate",
    type: class extends FormApplication {
      render() {
        const D = foundry.applications?.api?.DialogV2 ?? Dialog;
        if (D.confirm) {
          D.confirm({
            window: { title: "Refresh compendiums" },
            content: "<p>Replace every shipped compendium entry with the version bundled in the system?</p><p>Edits you made to shipped entries will be lost. Items you created yourself, and actors already placed on a scene, are not touched.</p>",
            yes: { callback: () => populatePacks({ replace: true }) }
          });
        } else populatePacks({ replace: true });
        return this;
      }
    },
    restricted: true
  });

  Hooks.once("ready", async () => {
    if (!game.user.isGM) return;

    const sig = await signature();
    const seen = String(game.settings.get("zed00", FLAG) ?? "");

    // Any pack that is declared, has source, and is sitting empty needs
    // filling whatever the signature says — that is the case the old
    // version check kept getting wrong.
    const starved = [];
    for (const [name, file] of Object.entries({ ...PACKS, ...ACTOR_PACKS, ...TABLE_PACKS })) {
      const pack = game.packs.get(`zed00.${name}`);
      if (!pack) continue;
      if (pack.index.size === 0) starved.push(name);
    }

    if (seen === sig && !starved.length) return;

    if (starved.length && seen === sig) {
      console.log(`Zed-00 | filling empty compendiums: ${starved.join(", ")}`);
    }
    await populatePacks({ notify: true });
    await game.settings.set("zed00", FLAG, sig);
  });
}
