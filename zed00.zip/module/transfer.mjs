/**
 * Moving goods between a character and a stockpile.
 *
 * Three things this gets right that the ad-hoc version did not:
 *
 *  - **Freshness survives the journey.** A spoilage date is stamped once,
 *    when food is first put away, and travels with it after that. Carrying
 *    a meal across the compound and putting it back used to reset its
 *    clock, which made a round trip the best preservative in the game.
 *
 *  - **Things that carry their own state never merge.** A loaded rifle and
 *    an empty one are not two of the same object. Merging them adds the
 *    quantities and throws one magazine away, which is how a full gun came
 *    back empty.
 *
 *  - **You can take some.** Nobody wants 900 Metal on their character
 *    sheet, and a caravan loading up needs to say how much.
 */

const { DialogV2 } = foundry.applications.api;

/**
 * Does this item carry state that cannot be shared across a stack?
 *
 * A sack of metal is interchangeable. A rifle with four rounds left, a
 * modified weapon, a cracked helmet and a half-spent gas mask are not.
 */
export function carriesState(item) {
  const s = item?.system ?? {};
  if (Number(s.ammo) > 0) return true;                      // loaded
  if (s.mod) return true;                                   // modified
  if (s.condition && s.condition !== "pristine") return true;
  if (Number(s.chargesMax) > 0 && Number(s.charges) !== Number(s.chargesMax)) return true;
  if (s.offhandId) return true;                             // paired
  return false;
}

/** May these two be poured into the same pile? */
export function canMerge(a, b) {
  if (!a || !b) return false;
  if (a.name !== b.name || a.type !== b.type) return false;
  if ((Number(a.system.spoilsOn) || 0) !== (Number(b.system.spoilsOn) || 0)) return false;
  return !carriesState(a) && !carriesState(b);
}

/**
 * How many to move.
 *
 * Returns the full amount without asking when there is only one, or when
 * the drag was made with shift held — the common case stays one gesture.
 */
export async function askAmount(item, max, { shift = false, verb = "Move" } = {}) {
  if (max <= 1 || shift) return max;
  const value = await DialogV2.prompt({
    window: { title: `${verb} how many?` },
    position: { width: 340 },
    content: `
      <div class="zed00 note-form">
        <p><strong>${item.name}</strong> — ${max} available.</p>
        <div class="line">
          <label>Take</label>
          <input type="number" name="n" value="${max}" min="1" max="${max}" autofocus>
        </div>
        <p class="hint">Hold shift while dragging to take the lot without being asked.</p>
      </div>`,
    ok: {
      label: verb,
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        const n = Number(el.querySelector('[name="n"]')?.value);
        return Number.isFinite(n) ? Math.max(0, Math.min(max, Math.round(n))) : 0;
      }
    },
    rejectClose: false
  });
  return value ?? 0;
}

/**
 * Move some of an item onto a destination actor.
 *
 * @param {Item} item         the source item
 * @param {Actor} to          where it is going
 * @param {object} options
 * @param {number} options.amount    how many; defaults to all of them
 * @param {boolean} options.stowed   how it should arrive
 * @param {number} options.stampWeek stamp a spoilage date if it has none
 * @returns {object|null} what moved, or null if nothing did
 */
export async function moveItem(item, to, {
  amount = null, stowed = true, stampWeek = null
} = {}) {
  if (!item || !to) return null;
  const from = item.parent;
  if (from?.id === to.id) return null;

  const have = Number(item.system.quantity) || 1;
  const moving = Math.max(0, Math.min(have, amount ?? have));
  if (!moving) return null;

  const payload = item.toObject();
  delete payload._id;
  payload.system.quantity = moving;
  payload.system.stowed = stowed;

  // Stamp the clock only if it has never been stamped. After that the
  // date belongs to the goods, wherever they happen to be sitting.
  const shelf = Number(payload.system.shelfLife) || 0;
  const already = Number(payload.system.spoilsOn) || 0;
  if (shelf && !already && stampWeek !== null) {
    payload.system.spoilsOn = stampWeek + shelf;
  }

  // A stack this could join, if it is the kind of thing that joins stacks.
  const twin = carriesState(item) ? null : to.items.find(i =>
    i.name === payload.name && i.type === payload.type &&
    (Number(i.system.spoilsOn) || 0) === (Number(payload.system.spoilsOn) || 0) &&
    !!i.system.stowed === !!stowed &&
    !carriesState(i));

  if (twin) {
    await twin.update({
      "system.quantity": (Number(twin.system.quantity) || 0) + moving });
  } else {
    await to.createEmbeddedDocuments("Item", [payload]);
  }

  // And take it off the source — the whole row, or just the part moved.
  if (from) {
    if (moving >= have) await item.delete();
    else await item.update({ "system.quantity": have - moving });
  }

  return { moving, name: item.name, from, to, merged: !!twin };
}
