/**
 * The colony calendar.
 *
 * The week engine owns the date because Exposure depends on the season,
 * but running a week and moving the date are two different things. A
 * party away on a caravan for three weeks should be able to skip
 * forward without anyone pretending to sleep in a bed they are nowhere
 * near.
 *
 * It also holds dated notes — the trade caravan due in week 14, the
 * research that finishes in week 12, "the Tartarus crew said they would
 * come back". Players can read the ones marked for them, which is the
 * point: a shared calendar is how a group remembers what is coming.
 */

const { ApplicationV2, HandlebarsApplicationMixin, DialogV2 } = foundry.applications.api;

export function registerCalendarSettings() {
  game.settings.register("zed00", "calendarNotes", {
    scope: "world", config: false, type: Array, default: []
  });
}

/** Every note, soonest first. */
export function notes() {
  const all = game.settings.get("zed00", "calendarNotes") ?? [];
  return [...all].sort((a, b) => (a.week ?? 0) - (b.week ?? 0));
}

/** What a player is allowed to see. */
export function visibleNotes() {
  return game.user.isGM ? notes() : notes().filter(n => n.shared);
}

async function saveNotes(list) {
  return game.settings.set("zed00", "calendarNotes", list);
}

/* ------------------------------------------------------------------ */

export class Zed00CalendarSheet extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "zed00-calendar",
    classes: ["zed00", "sheet", "calendar-sheet"],
    position: { width: 480, height: 600 },
    window: { title: "Colony Calendar", icon: "fas fa-calendar", resizable: true },
    actions: {
      addNote:    Zed00CalendarSheet.#addNote,
      editNote:   Zed00CalendarSheet.#editNote,
      deleteNote: Zed00CalendarSheet.#deleteNote,
      toggleShared: Zed00CalendarSheet.#toggleShared,
      advance:    Zed00CalendarSheet.#advance,
      rewind:     Zed00CalendarSheet.#rewind,
      runWeek:    Zed00CalendarSheet.#runWeek
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/calendar.hbs" } };

  async _prepareContext() {
    const { currentDate, SEASONS } = await import("./week.mjs");
    const date = currentDate();
    const mine = visibleNotes();

    const label = (n) => {
      const away = n.week - date.week;
      if (away === 0) return "this week";
      if (away === 1) return "next week";
      if (away > 1) return `in ${away} weeks`;
      if (away === -1) return "last week";
      return `${-away} weeks ago`;
    };

    return {
      date,
      seasons: SEASONS,
      isGM: game.user.isGM,
      past: mine.filter(n => n.week < date.week)
                .reverse()
                .map(n => ({ ...n, when: label(n) })),
      now: mine.filter(n => n.week === date.week).map(n => ({ ...n, when: label(n) })),
      coming: mine.filter(n => n.week > date.week).map(n => ({ ...n, when: label(n) })),
      anyNotes: mine.length > 0
    };
  }

  /* --------------------------------------------------------------- */

  static async #addNote() {
    const { currentDate } = await import("./week.mjs");
    const date = currentDate();
    const note = await promptNote({ week: date.week, title: "", text: "", shared: true });
    if (!note) return;
    await saveNotes([...notes(), { ...note, id: foundry.utils.randomID() }]);
    this.render();
  }

  static async #editNote(event, target) {
    const id = target.closest("[data-note-id]")?.dataset.noteId;
    const list = notes();
    const found = list.find(n => n.id === id);
    if (!found) return;
    const note = await promptNote(found);
    if (!note) return;
    await saveNotes(list.map(n => (n.id === id ? { ...n, ...note } : n)));
    this.render();
  }

  static async #deleteNote(event, target) {
    const id = target.closest("[data-note-id]")?.dataset.noteId;
    await saveNotes(notes().filter(n => n.id !== id));
    this.render();
  }

  static async #toggleShared(event, target) {
    const id = target.closest("[data-note-id]")?.dataset.noteId;
    await saveNotes(notes().map(n =>
      n.id === id ? { ...n, shared: !n.shared } : n));
    this.render();
  }

  /**
   * Move the date without running a week.
   *
   * Nothing is applied to anybody: no exposure, no feeding, no spoilage.
   * This is for time the colony was not there for — a caravan on the
   * road, a month skipped between chapters.
   */
  static async #advance() {
    if (!game.user.isGM) return;
    const weeks = await promptWeeks();
    if (!weeks) return;
    const { currentDate } = await import("./week.mjs");
    const before = currentDate();
    await game.settings.set("zed00", "week", before.week + weeks);
    const after = currentDate();
    ChatMessage.create({
      content: `<strong>${weeks} week${weeks === 1 ? "" : "s"} pass.</strong> ` +
               `It is now ${after.label}.<br>` +
               `<span class="hint">Time only — no exposure, feeding or spoilage ` +
               `was worked out. Run the colony week for that.</span>`
    });
    this.render();
    for (const app of Object.values(ui.windows ?? {})) app.render?.(false);
  }

  static async #rewind() {
    if (!game.user.isGM) return;
    const { currentDate } = await import("./week.mjs");
    const date = currentDate();
    const weeks = await promptWeeks("Rewind how many weeks?");
    if (!weeks) return;
    await game.settings.set("zed00", "week", Math.max(1, date.week - weeks));
    this.render();
  }

  static async #runWeek() {
    const { openWeek } = await import("./week.mjs");
    await openWeek();
    this.render();
  }
}

/* ------------------------------------------------------------------ */

async function promptWeeks(title = "Skip how many weeks?") {
  const value = await DialogV2.prompt({
    window: { title },
    content: `<p>${title}</p>
      <input type="number" name="weeks" value="1" min="1" max="52" autofocus>
      <p class="hint">The date moves. Nothing is applied to anybody — no
      exposure, no feeding, no spoilage. Use this for time the colony was
      not there for.</p>`,
    ok: {
      label: "Skip",
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        return Number(el.querySelector('[name="weeks"]')?.value) || 0;
      }
    },
    rejectClose: false
  });
  return value || 0;
}

async function promptNote(existing) {
  return DialogV2.prompt({
    window: { title: existing.id ? "Edit note" : "New note" },
    position: { width: 420 },
    content: `
      <div class="zed00 note-form">
        <div class="line">
          <label>Week</label>
          <input type="number" name="week" value="${existing.week}" min="1">
        </div>
        <div class="line">
          <label>What</label>
          <input type="text" name="title" value="${foundry.utils.escapeHTML(existing.title ?? "")}"
                 placeholder="Trade caravan arrives" autofocus>
        </div>
        <textarea name="text" rows="4"
          placeholder="Anything worth remembering about it.">${foundry.utils.escapeHTML(existing.text ?? "")}</textarea>
        <label class="check">
          <input type="checkbox" name="shared" ${existing.shared ? "checked" : ""}>
          The players can see this
        </label>
      </div>`,
    ok: {
      label: "Save",
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        const get = (n) => el.querySelector(`[name="${n}"]`);
        const title = get("title")?.value?.trim();
        if (!title) return null;
        return {
          week: Number(get("week")?.value) || 1,
          title,
          text: get("text")?.value ?? "",
          shared: !!get("shared")?.checked
        };
      }
    },
    rejectClose: false
  });
}

/* ------------------------------------------------------------------ */

let open;

export function openCalendar() {
  open ??= new Zed00CalendarSheet();
  open.render(true);
  return open;
}
