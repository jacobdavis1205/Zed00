/**
 * Colony research.
 *
 * A colonist who spends a week researching banks **2d6 + Know + INT
 * modifier − 4** points. Points go into whatever project is active, and
 * a project needs its prerequisites finished before it can be started
 * at all — cost does not gate that, the dependency does.
 *
 * Everything derivable is derived: which benches exist comes off the
 * map, what is available comes off the completed list. The only stored
 * state is what has been finished, what is in progress, and how many
 * points are banked against each.
 */

import { PROJECTS, BY_NAME, TECHPRINTS } from "./research-data.mjs";

// Re-exported so research.mjs is the one door everything else knocks on.
export { PROJECTS, BY_NAME, TECHPRINTS };
import { placedStructures } from "./structures.mjs";

const { ApplicationV2, HandlebarsApplicationMixin, DialogV2 } = foundry.applications.api;

const KEY = "research";

export function registerResearchSettings() {
  game.settings.register("zed00", KEY, {
    scope: "world", config: false, type: Object,
    default: { done: [], progress: {}, active: null, techprints: 0 }
  });

  /**
   * How much faster the better benches are.
   *
   * The handbook says the Advanced Research Station is "faster
   * research" and the Multi-Analyzer "boosts that bench's research
   * speed", and gives no numbers for either. These are the module's,
   * and they are settings so a maths audit can move them without a
   * release.
   */
  game.settings.register("zed00", "advancedBenchBonus", {
    name: "Advanced Research Station bonus",
    hint: "Extra research points a week, for a colonist working at an Advanced Research Station rather than a Simple Research Bench. The handbook says it is faster and gives no number.",
    scope: "world", config: true, type: Number, default: 3,
    range: { min: 0, max: 10, step: 1 }
  });

  game.settings.register("zed00", "analyzerBonus", {
    name: "Multi-Analyzer bonus",
    hint: "Extra research points a week when a Multi-Analyzer stands next to the bench being worked at.",
    scope: "world", config: true, type: Number, default: 2,
    range: { min: 0, max: 10, step: 1 }
  });

  game.settings.register("zed00", "benchGating", {
    name: "Higher tiers need better benches",
    hint: "On: Tier 3 research needs an Advanced Research Station, and Tier 4 needs one with a Multi-Analyzer beside it. Off: any research bench studies anything. The handbook does not say either way.",
    scope: "world", config: true, type: Boolean, default: true
  });
}

/* ------------------------------------------------------------------ */
/*  State                                                              */
/* ------------------------------------------------------------------ */

export function state() {
  const s = game.settings.get("zed00", KEY) ?? {};
  return {
    done: s.done ?? [],
    progress: s.progress ?? {},
    active: s.active ?? null,
    techprints: s.techprints ?? 0
  };
}

async function save(next) {
  return game.settings.set("zed00", KEY, next);
}

/** Has this project been finished? */
export function isDone(name) {
  return state().done.includes(name);
}

/** Are this project's prerequisites all finished? */
export function isAvailable(name, done = null) {
  const list = done ?? state().done;
  const p = BY_NAME[name];
  if (!p) return false;
  return p.needs.every(n => list.includes(n));
}

/* ------------------------------------------------------------------ */
/*  Benches                                                            */
/* ------------------------------------------------------------------ */

const SIMPLE = /simple research bench/i;
const ADVANCED = /advanced research station/i;
const ANALYZER = /multi-?analyz/i;

/** Two tokens are adjacent if their squares touch, corners included. */
function adjacent(a, b) {
  const ta = a?.parent?.token ?? a?.token, tb = b?.parent?.token ?? b?.token;
  if (!ta || !tb) return false;
  const ax2 = ta.x + (ta.width ?? 1) * (canvas?.grid?.size ?? 100);
  const ay2 = ta.y + (ta.height ?? 1) * (canvas?.grid?.size ?? 100);
  const bx2 = tb.x + (tb.width ?? 1) * (canvas?.grid?.size ?? 100);
  const by2 = tb.y + (tb.height ?? 1) * (canvas?.grid?.size ?? 100);
  const gap = (canvas?.grid?.size ?? 100) * 1.1;
  const overlapX = ta.x < bx2 + gap && bx2 > ta.x - gap && tb.x < ax2 + gap;
  const overlapY = ta.y < by2 + gap && by2 > ta.y - gap && tb.y < ay2 + gap;
  return overlapX && overlapY;
}

/**
 * The research benches standing on the map, best first.
 *
 * One colonist to a bench — three researchers need three benches, which
 * is what stops a colony from throwing its whole population at a Tier 4
 * project.
 */
export function benches() {
  const all = placedStructures().filter(a =>
    SIMPLE.test(a.name) || ADVANCED.test(a.name));
  const analyzers = placedStructures().filter(a => ANALYZER.test(a.name));

  return all.map(b => {
    const advanced = ADVANCED.test(b.name);
    const boosted = analyzers.some(z => z.system.working && adjacent(b, z));
    return {
      id: b.id, name: b.name, actor: b,
      working: b.system.working,
      advanced, boosted,
      // Tier 3 wants the better bench, Tier 4 wants it with an analyzer.
      maxTier: !advanced ? 2 : (boosted ? 4 : 3),
      bonus: (advanced ? game.settings.get("zed00", "advancedBenchBonus") : 0) +
             (boosted ? game.settings.get("zed00", "analyzerBonus") : 0)
    };
  }).sort((x, y) => (y.maxTier - x.maxTier) || (y.bonus - x.bonus));
}

/** The best tier the colony can study at all. */
export function bestTier() {
  if (game.settings.get("zed00", "benchGating") !== true) return 4;
  const live = benches().filter(b => b.working);
  return live.length ? Math.max(...live.map(b => b.maxTier)) : 0;
}

/* ------------------------------------------------------------------ */
/*  A week of research                                                 */
/* ------------------------------------------------------------------ */

/**
 * Roll one colonist's week and bank it.
 *
 * This is an ordinary Know check with a -4, not a Know check plus an
 * extra Intelligence. Every skill check in the game is 2d6 + skill +
 * the governing attribute, and Know's governing attribute is INT — so
 * "2d6 + Know + INT - 4" is that same roll, penalised. Intelligence is
 * added exactly once, here and in the rules.
 *
 * The -4 is what turns a pass-or-fail check into a number of points. A
 * bad roll with no skill comes out at nothing, which is the rules being
 * honest about somebody filling in.
 */
export async function researchWeek(actor, bench = null) {
  const sys = actor.system;
  const know = (actor.items ?? []).find(i =>
    i.type === "skill" && /^know$/i.test(i.name));
  const level = Number(know?.system?.level) || 0;
  const intMod = sys.attributes?.int?.mod ?? 0;
  const benchBonus = bench?.bonus ?? 0;

  const roll = await new Roll(
    `2d6 + ${level} + ${intMod} - 4 + ${benchBonus}`).evaluate();
  const points = Math.max(0, roll.total);

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>Research</strong> — Know check ` +
            `(2d6 + Know ${level} + INT ${intMod >= 0 ? "+" : ""}${intMod}), ` +
            `then −4 for the week` +
            (benchBonus ? ` + ${benchBonus} from the bench` : "") +
            (points === 0 && roll.total < 0 ? " — nothing to show for it" : "")
  });

  await bank(points);
  return points;
}

/** Put points against the active project, finishing it if they cover it. */
export async function bank(points) {
  if (!points) return null;
  const s = state();
  if (!s.active) {
    ui.notifications.warn(
      `${points} research points earned, but no project is active. ` +
      `Pick one on the Research sheet and they will go somewhere.`);
    return null;
  }

  const project = BY_NAME[s.active];
  const now = (s.progress[s.active] ?? 0) + points;
  const next = { ...s, progress: { ...s.progress, [s.active]: now } };

  if (now >= project.cost) {
    next.done = [...s.done, s.active];
    next.progress = { ...next.progress };
    delete next.progress[s.active];
    next.active = null;
    await save(next);
    ChatMessage.create({
      content: `<div class="zed00-roll"><h3>${project.name} — complete</h3>` +
               `<p>${project.unlocks}</p>` +
               `<p class="hint">${now - project.cost > 0
                 ? `${now - project.cost} points over; they do not carry.`
                 : "Exactly on the nose."}</p></div>`
    });
    return { finished: true, project };
  }

  await save(next);
  return { finished: false, project, progress: now };
}

export async function setActive(name) {
  const s = state();
  if (name && !isAvailable(name, s.done)) {
    const missing = BY_NAME[name].needs.filter(n => !s.done.includes(n));
    return ui.notifications.warn(
      `${name} needs ${missing.join(" and ")} first.`);
  }
  await save({ ...s, active: name });
}

export async function markDone(name, done = true) {
  const s = state();
  const list = done
    ? [...new Set([...s.done, name])]
    : s.done.filter(n => n !== name);
  const progress = { ...s.progress };
  if (done) delete progress[name];
  await save({ ...s, done: list, progress,
               active: s.active === name && done ? null : s.active });
}

/* ------------------------------------------------------------------ */
/*  The sheet                                                          */
/* ------------------------------------------------------------------ */

export class Zed00ResearchSheet extends HandlebarsApplicationMixin(ApplicationV2) {

  static DEFAULT_OPTIONS = {
    id: "zed00-research",
    classes: ["zed00", "sheet", "research-sheet"],
    position: { width: 560, height: 720 },
    window: { title: "Colony Research", icon: "fas fa-flask", resizable: true },
    actions: {
      choose:   Zed00ResearchSheet.#choose,
      complete: Zed00ResearchSheet.#complete,
      undo:     Zed00ResearchSheet.#undo,
      addWeek:  Zed00ResearchSheet.#addWeek,
      addPoints: Zed00ResearchSheet.#addPoints,
      techprint: Zed00ResearchSheet.#techprint
    }
  };

  static PARTS = { body: { template: "systems/zed00/templates/research.hbs" } };

  /** Which tiers are expanded. Tier 1 and whatever is active, by default. */
  open = null;

  async _prepareContext() {
    const s = state();
    const bs = benches();
    const top = bestTier();
    const gating = game.settings.get("zed00", "benchGating") === true;

    const active = s.active ? BY_NAME[s.active] : null;
    const banked = active ? (s.progress[s.active] ?? 0) : 0;

    const tiers = [1, 2, 3, 4].map(tier => {
      const locked = gating && tier > top;
      const needPrints = TECHPRINTS[tier] ?? 0;
      const projects = PROJECTS.filter(p => p.tier === tier).map(p => {
        const done = s.done.includes(p.name);
        const available = isAvailable(p.name, s.done);
        const missing = p.needs.filter(n => !s.done.includes(n));
        const got = s.progress[p.name] ?? 0;
        return {
          ...p, done, available, missing, got,
          percent: Math.min(100, Math.round((got / p.cost) * 100)),
          isActive: s.active === p.name,
          blocked: !available || locked
        };
      });
      return {
        tier, locked, needPrints, projects,
        doneCount: projects.filter(p => p.done).length,
        total: projects.length
      };
    });

    return {
      isGM: game.user.isGM,
      state: s, tiers, active, banked,
      activePercent: active ? Math.min(100, Math.round((banked / active.cost) * 100)) : 0,
      activeLeft: active ? Math.max(0, active.cost - banked) : 0,
      benches: bs,
      liveBenches: bs.filter(b => b.working).length,
      bestTier: top,
      gating,
      noBench: bs.length === 0,
      doneTotal: s.done.length,
      grandTotal: PROJECTS.length
    };
  }

  static async #choose(event, target) {
    if (!game.user.isGM) return;
    await setActive(target.closest("[data-project]")?.dataset.project ?? null);
    this.render();
  }

  static async #complete(event, target) {
    if (!game.user.isGM) return;
    await markDone(target.closest("[data-project]")?.dataset.project, true);
    this.render();
  }

  static async #undo(event, target) {
    if (!game.user.isGM) return;
    await markDone(target.closest("[data-project]")?.dataset.project, false);
    this.render();
  }

  /** Roll a researcher's week from the sheet. */
  static async #addWeek() {
    if (!game.user.isGM) return;
    const actor = [...(game.user.targets ?? [])][0]?.actor
      ?? canvas?.tokens?.controlled?.find(t => t.actor?.type !== "structure")?.actor;
    if (!actor) {
      return ui.notifications.warn(
        "Target the colonist doing the research, or select their token.");
    }
    const free = benches().filter(b => b.working);
    await researchWeek(actor, free[0] ?? null);
    this.render();
  }

  static async #addPoints() {
    if (!game.user.isGM) return;
    const value = await DialogV2.prompt({
      window: { title: "Bank research points" },
      content: `<p>Points to add to the active project.</p>
                <input type="number" name="n" value="10" autofocus>`,
      ok: { label: "Bank", callback: (e, b, d) =>
        Number((d.element ?? b.form).querySelector('[name="n"]')?.value) || 0 },
      rejectClose: false
    });
    if (value) { await bank(value); this.render(); }
  }

  static async #techprint(event, target) {
    if (!game.user.isGM) return;
    const s = state();
    const delta = Number(target.dataset.delta) || 0;
    await save({ ...s, techprints: Math.max(0, s.techprints + delta) });
    this.render();
  }

  _onFirstRender(context, options) {
    super._onFirstRender?.(context, options);
    const redraw = foundry.utils.debounce(() => this.render(), 300);
    this.#watching = [
      ["createToken", redraw], ["updateToken", redraw], ["deleteToken", redraw],
      ["canvasReady", redraw]
    ].map(([n, f]) => [n, Hooks.on(n, f)]);
  }

  #watching = [];

  _onClose(options) {
    super._onClose?.(options);
    for (const [n, id] of this.#watching) Hooks.off(n, id);
    this.#watching = [];
  }
}

let open;

export function openResearch() {
  open ??= new Zed00ResearchSheet();
  open.render(true);
  return open;
}
