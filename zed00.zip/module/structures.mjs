/**
 * Structures on the map.
 *
 * Three problems this solves, all of them about a building being a very
 * different thing from a person even though Foundry only has one kind of
 * token:
 *
 *  1. Buildings should not be draggable by accident. A wall that slides
 *     two squares because you meant to click the colonist standing in
 *     front of it has quietly ruined the fight.
 *  2. Players need to read a stockpile's sheet without twenty-five
 *     buildings appearing in their Actors tab.
 *  3. Lights should light things, and only while they are powered.
 */

const FLAG = "zed00";

/** Is this token a structure? */
export function isStructure(doc) {
  return doc?.actor?.type === "structure" || doc?.type === "structure";
}

/** Is this structure token pinned in place? */
export function isPinned(tokenDoc) {
  return tokenDoc?.getFlag?.(FLAG, "pinned") !== false;
}

/* ------------------------------------------------------------------ */
/*  Pinning                                                           */
/* ------------------------------------------------------------------ */

const DARK = { bright: 0, dim: 0, alpha: 0, animation: { type: null } };

/**
 * Work out what light a structure should be throwing right now.
 *
 * The radii come off the structure itself, from the Area Lit column, so
 * a torch really does light a ninth of what a floodlight does. A flame
 * only needs to be standing; anything electric needs power as well.
 *
 * Returns a token light config, or the dark one if it should be off.
 */
export function lightFor(actor) {
  const sys = actor?.system;
  if (!sys || actor.type !== "structure") return null;
  if (!sys.lit?.bright && !sys.lit?.dim) return null;   // not a light at all

  const burning = !!sys.lit.flame;
  const on = burning ? sys.usable : sys.working;
  if (!on) return DARK;

  return {
    bright: sys.lit.bright,
    dim: sys.lit.dim,
    color: burning ? "#ffb066" : "#ffeec9",
    alpha: 0.12,
    luminosity: burning ? 0.4 : 0.5,
    animation: burning
      ? { type: "torch", speed: 2, intensity: 3 }
      : { type: null, speed: 5, intensity: 5 }
  };
}

/* ------------------------------------------------------------------ */

export function registerStructureHooks() {

  /* --- 1. pinned structures do not move ------------------------- */

  Hooks.on("preUpdateToken", (tokenDoc, change, options) => {
    if (!isStructure(tokenDoc)) return;
    const moving = ("x" in change) || ("y" in change) || ("elevation" in change);
    if (!moving) return;
    if (options?.zed00Unpinned) return;      // deliberate move, let it through
    if (!isPinned(tokenDoc)) return;

    delete change.x;
    delete change.y;
    delete change.elevation;
    if (game.user.isGM) {
      ui.notifications.warn(
        `${tokenDoc.name} is pinned. Unpin it on its sheet to move it.`);
    }
    return Object.keys(change).length ? undefined : false;
  });

  /* --- 2. players see the sheet, not the sidebar ----------------- */

  // Structures are Observer-by-default so a player can open one from the
  // map. That would otherwise fill their Actors tab with buildings, so
  // the directory drops them for anyone who is not the GM.
  Hooks.on("renderActorDirectory", (app, html) => {
    if (game.user.isGM) return;
    const root = html instanceof HTMLElement ? html : html?.[0];
    if (!root) return;
    for (const li of root.querySelectorAll("[data-entry-id], [data-document-id]")) {
      const id = li.dataset.entryId ?? li.dataset.documentId;
      if (game.actors.get(id)?.type === "structure") li.remove();
    }
  });

  /* --- 3. lights light things ------------------------------------ */

  // When a structure's power or condition changes, its tokens catch up.
  Hooks.on("updateActor", async (actor, change) => {
    if (!game.user.isGM || actor.type !== "structure") return;
    const touched = change.system &&
      ("power" in change.system || "condition" in change.system);
    if (!touched) return;
    await syncLights(actor);
  });

  // And when one is first dropped on the map.
  Hooks.on("createToken", async (tokenDoc) => {
    if (!game.user.isGM || !isStructure(tokenDoc)) return;
    const light = lightFor(tokenDoc.actor);
    if (light) await tokenDoc.update({ light }, { diff: false });
  });

  /* --- 4. a deleted off-hand stops being an off-hand -------------- */

  // Otherwise the weapon keeps its "dual" tag and dual-wields a ghost.
  Hooks.on("deleteItem", async (item) => {
    const actor = item.parent;
    if (!actor || actor.documentName !== "Actor") return;
    if (!game.user.isGM && !actor.isOwner) return;
    const orphans = actor.items.filter(i =>
      i.type === "weapon" && i.system?.offhandId === item.id);
    for (const o of orphans) await o.update({ "system.offhandId": "" });
  });

  // Drop a stack of two paired daggers to one and the pairing goes too.
  Hooks.on("updateItem", async (item, change) => {
    if (item.type !== "weapon") return;
    if (!(change.system && "quantity" in change.system)) return;
    if (item.system.offhandId !== item.id) return;        // not self-paired
    if ((Number(item.system.quantity) || 1) >= 2) return;
    if (!item.parent?.isOwner) return;
    await item.update({ "system.offhandId": "" });
  });
}

/** Push the right light onto every token of this structure. */
export async function syncLights(actor) {
  const light = lightFor(actor);
  if (!light) return;
  for (const scene of game.scenes) {
    const mine = scene.tokens.filter(t => t.actorId === actor.id ||
      t.delta?.parent?.id === actor.id || t.actor === actor);
    if (!mine.length) continue;
    await scene.updateEmbeddedDocuments("Token",
      mine.map(t => ({ _id: t.id, light })), { diff: false });
  }
}

/** Move a pinned structure anyway — used by the sheet's unpin button. */
export async function moveUnpinned(tokenDoc, update) {
  return tokenDoc.update(update, { zed00Unpinned: true });
}
