/**
 * Structures on the map.
 *
 * Three problems this solves, all of them about a building being a very
 * different thing from a person even though Foundry only has one kind of
 * token:
 *
 *  1. Buildings should not be draggable by accident. A wall that slides
 *     two squares because you meant to click the colonist standing in
 *     front of it has quietly ruined the fight.
 *  2. Players need to read a stockpile's sheet without twenty-five
 *     buildings appearing in their Actors tab.
 *  3. Lights should light things, and only while they are powered.
 */

const FLAG = "zed00";

/** Is this token a structure? */
export function isStructure(doc) {
  return doc?.actor?.type === "structure" || doc?.type === "structure";
}

/** The scene the colony is standing on. */
export function colonyScene() {
  return canvas?.scene ?? game.scenes?.active ?? game.scenes?.current ?? null;
}

/**
 * Every structure **standing on the map**.
 *
 * Not `game.actors`. The sidebar holds one entry per kind of building —
 * that is the whole point of unlinked tokens — so reading it counts one
 * battery however many you built, and counts things you have not built
 * at all. The tokens are the buildings; the sidebar is the catalogue.
 *
 * A token's `actor` is its own synthetic actor carrying its own data, so
 * two solar generators are two generators with two sets of hit points.
 * Linked tokens are the exception and share one actor, so they are
 * counted once however many are placed.
 *
 * Anything that asks "what has the colony got" must come through here.
 */
export function placedStructures(scene = null) {
  scene ??= colonyScene();
  if (!scene) return [];

  const out = [];
  const seenLinked = new Set();
  for (const token of scene.tokens) {
    const actor = token.actor;
    if (actor?.type !== "structure") continue;
    if (token.actorLink) {
      if (seenLinked.has(token.actorId)) continue;
      seenLinked.add(token.actorId);
    }
    out.push(actor);
  }
  return out;
}

/** Stockpiles on the map, which is where the colony's goods actually are. */
export function placedStockpiles(scene = null) {
  return placedStructures(scene).filter(a => a.system.function === "stockpile");
}

/** Structures in the sidebar that are not on this scene — the catalogue. */
export function unplacedStructures(scene = null) {
  const on = new Set(placedStructures(scene).map(a => a.id));
  return game.actors.filter(a => a.type === "structure" && !on.has(a.id));
}

/** Is this structure token pinned in place? */
export function isPinned(tokenDoc) {
  return tokenDoc?.getFlag?.(FLAG, "pinned") !== false;
}

/* ------------------------------------------------------------------ */
/*  Pinning                                                           */
/* ------------------------------------------------------------------ */

const DARK = { bright: 0, dim: 0, alpha: 0, animation: { type: null } };

/**
 * Work out what light a structure should be throwing right now.
 *
 * The radii come off the structure itself, from the Area Lit column, so
 * a torch really does light a ninth of what a floodlight does. A flame
 * only needs to be standing; anything electric needs power as well.
 *
 * Returns a token light config, or the dark one if it should be off.
 */
export function lightFor(actor) {
  const sys = actor?.system;
  if (!sys || actor.type !== "structure") return null;
  if (!sys.lit?.bright && !sys.lit?.dim) return null;   // not a light at all

  // A flame needs no grid, but it still needs to be lit: `running` is the
  // switch for both, so a torch can be put out the same way a lamp can be
  // turned off. Either way a wrecked fixture throws nothing.
  const burning = !!sys.lit.flame;
  const on = sys.power.running && (burning ? sys.usable : sys.working);
  if (!on) return DARK;

  return {
    bright: sys.lit.bright,
    dim: sys.lit.dim,
    color: burning ? "#ffb066" : "#ffeec9",
    alpha: 0.12,
    luminosity: burning ? 0.4 : 0.5,
    animation: burning
      ? { type: "torch", speed: 2, intensity: 3 }
      : { type: null, speed: 5, intensity: 5 }
  };
}

/* ------------------------------------------------------------------ */

export function registerStructureHooks() {

  /* --- 1. pinned structures do not move ------------------------- */

  Hooks.on("preUpdateToken", (tokenDoc, change, options) => {
    if (!isStructure(tokenDoc)) return;
    const moving = ("x" in change) || ("y" in change) || ("elevation" in change);
    if (!moving) return;
    if (options?.zed00Unpinned) return;      // deliberate move, let it through
    if (!isPinned(tokenDoc)) return;

    delete change.x;
    delete change.y;
    delete change.elevation;
    if (game.user.isGM) {
      ui.notifications.warn(
        `${tokenDoc.name} is pinned. Unpin it on its sheet to move it.`);
    }
    return Object.keys(change).length ? undefined : false;
  });

  /* --- 2. players see the sheet, not the sidebar ----------------- */

  // Structures are Observer-by-default so a player can open one from the
  // map. That would otherwise fill their Actors tab with buildings, so
  // the directory drops them for anyone who is not the GM.
  Hooks.on("renderActorDirectory", (app, html) => {
    if (game.user.isGM) return;
    const root = html instanceof HTMLElement ? html : html?.[0];
    if (!root) return;
    for (const li of root.querySelectorAll("[data-entry-id], [data-document-id]")) {
      const id = li.dataset.entryId ?? li.dataset.documentId;
      if (game.actors.get(id)?.type === "structure") li.remove();
    }
  });

  /* --- 3. lights light things ------------------------------------ */

  // When a structure's power or condition changes, its tokens catch up.
  Hooks.on("updateActor", async (actor, change) => {
    if (!game.user.isGM || actor.type !== "structure") return;
    const touched = change.system &&
      ("power" in change.system || "condition" in change.system);
    if (!touched) return;
    await syncLights(actor);
  });

  // And when one is first dropped on the map.
  Hooks.on("createToken", async (tokenDoc) => {
    if (!game.user.isGM || !isStructure(tokenDoc)) return;
    const light = lightFor(tokenDoc.actor);
    if (light) await tokenDoc.update({ light }, { diff: false });
  });

  /* --- 4. a deleted off-hand stops being an off-hand -------------- */

  // Otherwise the weapon keeps its "dual" tag and dual-wields a ghost.
  Hooks.on("deleteItem", async (item) => {
    const actor = item.parent;
    if (!actor || actor.documentName !== "Actor") return;
    if (!game.user.isGM && !actor.isOwner) return;
    const orphans = actor.items.filter(i =>
      i.type === "weapon" && i.system?.offhandId === item.id);
    for (const o of orphans) await o.update({ "system.offhandId": "" });
  });

  // Drop a stack of two paired daggers to one and the pairing goes too.
  Hooks.on("updateItem", async (item, change) => {
    if (item.type !== "weapon") return;
    if (!(change.system && "quantity" in change.system)) return;
    if (item.system.offhandId !== item.id) return;        // not self-paired
    if ((Number(item.system.quantity) || 1) >= 2) return;
    if (!item.parent?.isOwner) return;
    await item.update({ "system.offhandId": "" });
  });
}

/** Push the right light onto every token of this structure. */
export async function syncLights(actor) {
  const light = lightFor(actor);
  if (!light) return;
  for (const scene of game.scenes) {
    const mine = scene.tokens.filter(t => t.actorId === actor.id ||
      t.delta?.parent?.id === actor.id || t.actor === actor);
    if (!mine.length) continue;
    await scene.updateEmbeddedDocuments("Token",
      mine.map(t => ({ _id: t.id, light })), { diff: false });
  }
}

/** Move a pinned structure anyway — used by the sheet's unpin button. */
export async function moveUnpinned(tokenDoc, update) {
  return tokenDoc.update(update, { zed00Unpinned: true });
}

/**
 * Re-apply player access to structures that already exist.
 *
 * New structures are created Owner-by-default, but anything already in
 * a world keeps whatever it was made with. This brings them into line
 * so players can use the sheds they have already built.
 */
export async function grantPlayerAccess(level = CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER) {
  if (!game.user.isGM) return;
  const all = game.actors.filter(a => a.type === "structure");
  const updates = all
    .filter(a => (a.ownership?.default ?? 0) !== level)
    .map(a => ({ _id: a.id, "ownership.default": level }));

  if (!updates.length) {
    return ui.notifications.info("Every structure already has that access.");
  }
  await Actor.updateDocuments(updates);

  // Tokens already on a map carry their own copy of the actor.
  let tokens = 0;
  for (const scene of game.scenes) {
    const mine = scene.tokens.filter(t => t.actor?.type === "structure" && !t.actorLink);
    for (const t of mine) {
      await t.actor.update({ "ownership.default": level });
      tokens++;
    }
  }
  ui.notifications.info(
    `Updated ${updates.length} structure${updates.length === 1 ? "" : "s"}` +
    (tokens ? ` and ${tokens} placed token${tokens === 1 ? "" : "s"}` : "") + ".");
}
