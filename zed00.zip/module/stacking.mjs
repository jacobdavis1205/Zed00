/**
 * What stacks and what doesn't.
 *
 * The trouble with quantity is that some things carry state of their own
 * and some don't. Twenty Metal is twenty Metal — there is nothing to say
 * about any one of them. Two rifles are not interchangeable the moment
 * one has four rounds left and the other is full, and a single `ammo`
 * field cannot describe both.
 *
 * So the rule is: **anything with a magazine is its own item.** Buy three
 * rifles and you get three rifles, each with its own ammunition, its own
 * condition and its own modification. Everything else — melee weapons,
 * armour, gear, drugs, materials — stacks freely, and readying one peels
 * it off the pile.
 *
 * That keeps reloading honest without making the player think about it,
 * and it is the reason the gear tab shows a quantity box on a dagger and
 * not on an autopistol.
 */

/** Does this item keep state that can't be shared across a stack? */
export function isUnique(item) {
  const s = item?.system ?? {};
  if (item?.type === "weapon") return !!s.magazine;
  return false;
}

export function registerStackingHooks() {

  // Creating several of something that can't stack makes several of them.
  Hooks.on("preCreateItem", (item, data) => {
    if (!isUnique(item)) return;
    const qty = Number(data?.system?.quantity) || 1;
    if (qty > 1) item.updateSource({ "system.quantity": 1 });
  });

  Hooks.on("createItem", async (item, options, userId) => {
    if (game.user.id !== userId) return;
    if (!isUnique(item) || !item.parent) return;
    const wanted = Number(options?.zed00Copies) || 0;
    if (wanted <= 1) return;
    const copies = Array.from({ length: wanted - 1 }, () => {
      const c = item.toObject();
      delete c._id;
      c.system.quantity = 1;
      return c;
    });
    await item.parent.createEmbeddedDocuments("Item", copies);
  });

  // And nudging the quantity up on one is the same request.
  Hooks.on("preUpdateItem", (item, change) => {
    if (!isUnique(item)) return;
    const qty = change?.system?.quantity;
    if (qty === undefined) return;
    const n = Number(qty) || 0;
    if (n <= 1) return;
    change.system.quantity = 1;
    if (!item.parent) return;
    // Make the extras for real rather than silently refusing.
    const copies = Array.from({ length: n - 1 }, () => {
      const c = item.toObject();
      delete c._id;
      c.system.quantity = 1;
      c.system.ammo = 0;              // a new gun off the rack is empty
      return c;
    });
    item.parent.createEmbeddedDocuments("Item", copies).then(() => {
      ui.notifications.info(
        `${item.name} carries its own ammunition, so ${n - 1} more were added ` +
        `as separate entries rather than a stack.`);
    });
  });
}
