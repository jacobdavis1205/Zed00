/**
 * Ammunition as goods.
 *
 * Ammunition used to be nine counters in a SchemaField on every actor.
 * That is the cheapest possible way to track it and it was the right
 * first answer — but a counter cannot be in a shed, cannot be handed to
 * a colonist, cannot be loaded onto a pack mule and cannot be split in
 * half. Caravans make all four of those things routine, so ammunition
 * becomes an item like everything else.
 *
 * What stays the same: the nine pools, twenty rounds to a batch, and the
 * weapon naming the pool it eats. What changes: the rounds live
 * somewhere specific, weigh something, and move with the ordinary
 * transfer machinery.
 */

/**
 * The pools, straight from the handbook's own table.
 *
 * `per` is how many rounds weigh one Encumbrance — twenty, which is also
 * a purchase and a crafted batch. Ordnance is counted and carried one
 * piece at a time instead.
 */
export const POOLS = {
  arrows: {
    name: "Arrows", feeds: "Short bow, Recurve bow, Great bow",
    per: 20, enc: 1, buy: 8, sell: 2, recipe: "10 Wood", bench: "none", metal: 0,
    // An arrow has no metal in it, so there is nothing to swap out. A
    // plasteel arrow is a different object made of a different material
    // rather than a substitution, which is why it carries a recipe of
    // its own instead of falling out of the general rule.
    plasteel: true, plasteelRecipe: "15 Plasteel", plasteelUnits: 15
  },
  pistol: {
    name: "Pistol rounds", feeds: "Revolver, Autopistol",
    per: 20, enc: 1, buy: 30, sell: 9, recipe: "10 Metal", bench: "forge", metal: 10,
    plasteel: true
  },
  shotgun: {
    name: "Shotgun shells", feeds: "Pump shotgun, Chain shotgun",
    per: 20, enc: 1, buy: 40, sell: 12, recipe: "10 Metal, 5 Fuel", bench: "forge", metal: 10,
    plasteel: true
  },
  smg: {
    name: "SMG rounds", feeds: "Machine pistol, Heavy SMG",
    per: 20, enc: 1, buy: 45, sell: 14, recipe: "15 Metal", bench: "forge", metal: 15,
    plasteel: true
  },
  rifle: {
    name: "Rifle rounds", feeds: "Bolt-action rifle, Assault rifle, LMG, Minigun",
    per: 20, enc: 1, buy: 94, sell: 28,
    recipe: "15 Metal, 5 Basic Components", bench: "machining", metal: 15,
    plasteel: true
  },
  charged: {
    name: "Charge cells", feeds: "Charge rifle, Charge lance, Beam repeater",
    per: 20, enc: 1, buy: 275, sell: 82,
    recipe: "10 Metal, 5 Advanced Components", bench: "fabrication", metal: 10,
    plasteel: false
  },
  grenade: {
    name: "Grenades", feeds: "Frag, EMP, Smoke, Molotov",
    per: 1, enc: 1, ordnance: true, buy: 50, sell: 15,
    recipe: "varies by grenade", bench: "machining", metal: 0,
    plasteel: false
  },
  incendiary: {
    name: "Incendiary charges", feeds: "Incendiary launcher",
    per: 1, enc: 1, ordnance: true, buy: 31, sell: 9,
    recipe: "5 Metal, 5 Fuel", bench: "machining", metal: 5,
    plasteel: false
  },
  mortar: {
    name: "Mortar shells", feeds: "Mortar",
    per: 1, enc: 2, ordnance: true, buy: 0, sell: 0,
    recipe: "15 Metal, 10 Fuel", bench: "machining", metal: 15,
    plasteel: false
  }
};

export const POOL_KEYS = Object.keys(POOLS);

/** A readable name for a pool key, including one we don't know. */
export function poolName(key) {
  return POOLS[key]?.name ?? (key ? String(key) : "—");
}

/**
 * Build the item data for a batch of ammunition.
 *
 * Everything about a pool except the round count comes from the table,
 * so a box of rifle rounds created by the migration, by a purchase or by
 * hand all come out identical and therefore stackable.
 */
export function ammoData(pool, rounds = 20, { tl4 = false } = {}) {
  const p = POOLS[pool] ?? POOLS.pistol;
  const name = tl4 ? `${p.name} (plasteel)` : p.name;

  // Working plasteel needs the Fabrication Bench, which is where every
  // one of the handbook's own armour-piercing weapons is built. That one
  // rule is what makes plasteel ammunition hard to come by rather than
  // just expensive: a forge cannot produce it, so neither can a raider
  // camp or a tribal band. It also means the bench is the tier, with no
  // separate tech-level number to track.
  const bench = tl4 ? "fabrication" : (p.bench ?? "none");
  const rec = tl4 ? plasteelRecipe(pool) : null;

  // Plasteel costs 7.5 a unit against Metal's 2.25. Where it replaces
  // metal, only the difference is charged; where the whole object is
  // plasteel — an arrow — the recipe is priced from scratch.
  const buy = !tl4 ? (p.buy ?? 0)
    : rec.whole ? Math.round(rec.units * 7.5)
                : Math.round(p.buy + rec.units * (7.5 - 2.25));

  return {
    name,
    type: "ammo",
    img: "icons/weapons/ammunition/bullets-cartridge-shell-gray.webp",
    system: {
      pool,
      quantity: Math.max(0, Math.round(rounds)),
      tl4,
      per: p.per,
      ordnance: !!p.ordnance,
      encumbrance: p.enc,
      bench,
      price: { buy, sell: Math.round((tl4 ? buy * 0.3 : p.sell) ?? 0) },
      description: `<p>Feeds: ${p.feeds}.</p>` +
        `<p>Made from ${tl4 ? rec.text : p.recipe}.</p>` +
        (tl4
          ? `<p><b>Goes through powered armour.</b> Powered armour's 7 damage
             reduction and its Shock immunity do not apply to these, the same
             way they do not apply to a charge rifle.</p>
             <p>Fabrication Bench only — a forge cannot work plasteel.</p>`
          : "")
    }
  };
}

/**
 * Is a plasteel version of this pool a thing?
 *
 * Two reasons it might not be. Arrows and grenades have no Metal in the
 * recipe, so there is nothing to substitute. Charge cells, incendiary
 * charges and mortar shells already feed weapons that go through powered
 * armour, so a plasteel version would buy nothing and cost more.
 */
export function canBePlasteel(pool) {
  const p = POOLS[pool];
  if (!p || p.plasteel !== true) return false;
  return (p.metal ?? 0) > 0 || !!p.plasteelRecipe;
}

/** How many units of plasteel a batch takes, and what the recipe reads. */
export function plasteelRecipe(pool) {
  const p = POOLS[pool];
  if (!p) return null;
  if (p.plasteelRecipe) {
    return { units: p.plasteelUnits ?? 0, text: p.plasteelRecipe, whole: true };
  }
  return { units: p.metal ?? 0,
           text: p.recipe.replace(/(\d+) Metal/, "$1 Plasteel"), whole: false };
}

/* ------------------------------------------------------------------ */
/*  Finding something to load                                          */
/* ------------------------------------------------------------------ */

/**
 * Every batch on this actor that could feed this weapon, best first.
 *
 * "Best" means the plain stuff first, so a player who has saved up
 * twenty plasteel rounds does not burn them topping off a magazine
 * without being asked.
 */
export function matchingAmmo(actor, weapon) {
  const want = (weapon?.system?.ammoPool || "").toLowerCase();
  if (!want) return [];
  return actor.items
    .filter(i => i.type === "ammo" &&
                 i.system.pool === want &&
                 (Number(i.system.quantity) || 0) > 0)
    .sort((a, b) => Number(!!a.system.tl4) - Number(!!b.system.tl4));
}

/** How many rounds of a pool this actor is carrying, all batches together. */
export function roundsOf(actor, pool) {
  let total = 0;
  for (const i of actor.items) {
    if (i.type === "ammo" && i.system.pool === pool) {
      total += Number(i.system.quantity) || 0;
    }
  }
  return total;
}

/**
 * Take rounds out of a batch, deleting it when it runs dry.
 *
 * An empty box is not a thing worth carrying, and leaving zeroed stacks
 * on the sheet is how an inventory becomes unreadable.
 */
export async function spendRounds(batch, rounds) {
  const have = Number(batch.system.quantity) || 0;
  const take = Math.min(have, Math.max(0, rounds));
  if (!take) return 0;
  if (take >= have) await batch.delete();
  else await batch.update({ "system.quantity": have - take });
  return take;
}

/**
 * Fill a magazine from whatever is to hand.
 *
 * Draws from one batch at a time, plain before plasteel, and reports
 * which it used so the table can see the good rounds going in.
 */
/**
 * Pick which box to load from.
 *
 * The first version of this chose for you — plain rounds before
 * plasteel, on the reasoning that nobody wants to burn the expensive
 * stuff topping off a magazine. The effect was that you could never
 * deliberately load plasteel while you still had ordinary rounds on the
 * sheet: the only way through was to delete your own ammunition. That is
 * backwards. The player picks.
 */
async function chooseBatch(weapon, batches) {
  if (batches.length === 1) return batches[0];

  const rows = batches.map((b, i) => {
    const n = Number(b.system.quantity) || 0;
    return `<label class="check" style="display:block;padding:3px 0">
      <input type="radio" name="batch" value="${i}" ${i === 0 ? "checked" : ""}>
      <b>${b.name}</b> — ${n} round${n === 1 ? "" : "s"}
      ${b.system.tl4
        ? `<span class="hint">goes through powered armour</span>`
        : ``}
    </label>`;
  }).join("");

  const picked = await foundry.applications.api.DialogV2.prompt({
    window: { title: `Load ${weapon.name}`, icon: "fas fa-sync" },
    position: { width: 400 },
    content: `<div class="zed00"><p class="hint">What goes in the magazine?</p>
      ${rows}</div>`,
    ok: { label: "Load it",
          callback: (ev, button) => button.form.elements.batch.value }
  }).catch(() => null);

  return picked === null ? null : batches[Number(picked)];
}

/**
 * Fill a magazine from a box the player chooses.
 *
 * A magazine holds one kind of round, so loading a different kind into a
 * part-full magazine means emptying it first — and the rounds that come
 * out go back in the pack rather than evaporating, because a round you
 * take out of a gun is still a round.
 */
export async function reload(actor, weapon, { batchId = null } = {}) {
  if (!weapon?.system?.magazine) return null;
  const pool = (weapon.system.ammoPool || "").toLowerCase();
  if (!POOLS[pool]) {
    ui.notifications.warn(
      `${weapon.name} is not chambered for anything. Open it and set what it takes.`);
    return null;
  }

  const batches = matchingAmmo(actor, weapon);
  if (!batches.length) {
    ui.notifications.warn(
      `No ${poolName(pool).toLowerCase()} on this sheet. ` +
      `Drag some in from a stockpile or the compendium.`);
    return null;
  }

  const already = Number(weapon.system.ammo) || 0;
  if (already >= weapon.system.magazine && batches.length < 2) {
    ui.notifications.info(`${weapon.name} is already full.`);
    return null;
  }

  // An explicit choice from the overview skips the dialog.
  const batch = batchId
    ? batches.find(b => b.id === batchId)
    : await chooseBatch(weapon, batches);
  if (!batch) return null;

  const kind = !!batch.system.tl4;
  const swapping = already > 0 && !!weapon.system.loadedTl4 !== kind;

  if (swapping) {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: "Change rounds" },
      content: `<div class="zed00"><p>${weapon.name} has ${already}
        ${weapon.system.loadedTl4 ? "plasteel" : "ordinary"}
        round${already === 1 ? "" : "s"} in it, and a magazine holds one
        kind or the other.</p>
        <p>Those ${already} go back in the pack, and
        ${batch.name.toLowerCase()} goes in the gun.</p></div>`,
      yes: { label: "Swap them over" },
      no: { label: "Leave it loaded" }
    }).catch(() => false);
    if (!ok) return null;

    // Put the old rounds back where they came from rather than losing
    // them. Emptying a gun does not destroy ammunition.
    await returnRounds(actor, weapon, already);
    await weapon.update({ "system.ammo": 0 });
  }

  const have = swapping ? 0 : already;
  const need = weapon.system.magazine - have;
  if (need <= 0) {
    ui.notifications.info(`${weapon.name} is already full.`);
    return null;
  }

  const took = await spendRounds(batch, need);
  if (!took) return null;

  await weapon.update({
    "system.ammo": have + took,
    "system.loadedTl4": kind
  });

  const remaining = roundsOf(actor, pool);
  const short = need - took;
  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<strong>${weapon.name}</strong> loaded with ${took} ` +
      `${batch.name.toLowerCase()}` +
      (short > 0
        ? `. <span class="hint">${short} short of a full magazine — ` +
          `that was the last of them.</span>`
        : `. <span class="hint">${remaining} left in the pack.</span>`) +
      (kind
        ? `<br><em><b>Plasteel.</b> Powered armour's 7 damage reduction and ` +
          `its Shock immunity do not apply to these — the same way they do ` +
          `not apply to a charge rifle.</em>`
        : "")
  });
  return { loaded: took, short, tl4: kind, from: batch.name };
}

/**
 * Put rounds taken out of a gun back on the sheet.
 *
 * Merges into a matching box if there is one, so unloading and reloading
 * does not litter the sheet with part-boxes.
 */
export async function returnRounds(actor, weapon, rounds) {
  if (rounds <= 0) return null;
  const pool = (weapon.system.ammoPool || "").toLowerCase();
  const tl4 = !!weapon.system.loadedTl4;
  const home = actor.items.find(
    i => i.type === "ammo" && i.system.pool === pool && !!i.system.tl4 === tl4);

  if (home) {
    await home.update({
      "system.quantity": (Number(home.system.quantity) || 0) + rounds });
    return home;
  }
  const [made] = await actor.createEmbeddedDocuments(
    "Item", [ammoData(pool, rounds, { tl4 })]);
  return made;
}

/** Empty a gun back into the pack. */
export async function unload(actor, weapon) {
  const rounds = Number(weapon.system.ammo) || 0;
  if (!rounds) return ui.notifications.info(`${weapon.name} is already empty.`);
  await returnRounds(actor, weapon, rounds);
  await weapon.update({ "system.ammo": 0, "system.loadedTl4": false });
  ui.notifications.info(
    `${rounds} round${rounds === 1 ? "" : "s"} back in the pack.`);
}

/* ------------------------------------------------------------------ */
/*  Migration from the old counters                                    */
/* ------------------------------------------------------------------ */

/**
 * What the old counters hold, and what would be made from them.
 *
 * Reported before anything is written, because a migration that runs
 * first and explains afterwards is a migration nobody trusts. The old
 * `system.ammo` schema is left in place and simply zeroed, so a world
 * that has already migrated is recognisable by its empty counters and a
 * second run makes nothing.
 */
export function migrationPlan() {
  const plan = [];
  for (const actor of game.actors) {
    if (!["character", "colonist"].includes(actor.type)) continue;
    const counters = actor.system.ammo ?? {};
    const batches = [];
    for (const key of POOL_KEYS) {
      const n = Number(counters[key]) || 0;
      if (n > 0) batches.push({ pool: key, rounds: n });
    }
    if (batches.length) plan.push({ actor, batches });
  }
  return plan;
}

/** One line per actor, for the confirmation dialog and the chat record. */
export function describePlan(plan) {
  if (!plan.length) return "Nothing to move — no ammunition counters have anything in them.";
  return plan.map(p =>
    `<li><b>${p.actor.name}</b> — ` +
    p.batches.map(b => `${b.rounds} ${poolName(b.pool).toLowerCase()}`).join(", ") +
    `</li>`).join("");
}

/**
 * Turn the counters into items.
 *
 * @param {boolean} dryRun  true reports and writes nothing
 */
export async function migrateAmmo({ dryRun = true } = {}) {
  if (!game.user.isGM) {
    ui.notifications.warn("Only the GM can move the ammunition over.");
    return null;
  }
  const plan = migrationPlan();
  if (dryRun) return plan;

  let made = 0;
  for (const { actor, batches } of plan) {
    const creates = batches.map(b => ammoData(b.pool, b.rounds));
    await actor.createEmbeddedDocuments("Item", creates);
    made += creates.length;
    // Zero the counters rather than deleting the field: a schema change
    // in the same release as a data move is two ways for one upgrade to
    // go wrong, and an empty counter is how a migrated actor is known.
    await actor.update(Object.fromEntries(
      batches.map(b => [`system.ammo.${b.pool}`, 0])));
  }
  return { actors: plan.length, batches: made, plan };
}

/** The GM-facing button: show the plan, then do it. */
export async function promptMigration() {
  const plan = migrationPlan();
  const ok = await foundry.applications.api.DialogV2.confirm({
    window: { title: "Move ammunition onto the sheets", icon: "fas fa-box" },
    position: { width: 520 },
    content: `<div class="zed00">
      <h3>Ammunition becomes items</h3>
      <p class="hint">The nine counters on each sheet become boxes of
      ammunition you can stow, hand over, leave in a shed or load onto a
      caravan. Twenty rounds weigh one Encumbrance.</p>
      ${plan.length ? `<ul class="simple">${describePlan(plan)}</ul>`
                    : `<p>${describePlan(plan)}</p>`}
      <p class="hint">The old counters are emptied, not removed, so this is
      safe to run twice — the second time finds nothing to do.</p>
    </div>`,
    yes: { label: plan.length ? "Move it over" : "Nothing to do" },
    no: { label: "Leave it alone" }
  });
  if (!ok || !plan.length) return;

  const done = await migrateAmmo({ dryRun: false });
  ChatMessage.create({
    content: `<div class="zed00-card">
      <header><strong>Ammunition moved</strong></header>
      <div class="text">${done.batches} box${done.batches === 1 ? "" : "es"} across
        ${done.actors} sheet${done.actors === 1 ? "" : "s"}. It is in the gear tab
        now, and it weighs something.</div>
    </div>`
  });
  ui.notifications.info(`Moved ${done.batches} batches onto ${done.actors} sheets.`);
}
