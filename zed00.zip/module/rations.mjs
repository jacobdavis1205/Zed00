/**
 * What the colony ate this week.
 *
 * Two separate questions, which the old single "Ate" dropdown ran
 * together:
 *
 *   How MUCH — seven meals a head, or fourteen raw food. Falling short
 *   puts everyone on the Hunger track: Mild Malnourishment, Severe
 *   Starvation, Total Fasting.
 *
 *   How WELL — the colony eats at one quality for the week, and the
 *   whole week has to be at that tier for it to count. Two lavish meals
 *   and five simple ones is a week of simple meals with a nice Tuesday.
 *
 * So this totals what was served, works out both answers, and names who
 * is risking what. It changes nothing on its own: the GM reads it and
 * decides.
 */

export const MEALS_PER_HEAD = 7;
export const RAW_PER_HEAD = 14;

/**
 * The things a colony can put on the table, in quality order.
 *
 * `meals` is how many of a colonist's seven one unit covers — raw food
 * is half a meal because fourteen of it feeds one person for a week.
 */
export const FOODS = [
  { key: "lavish",    name: "Lavish Meal",    meals: 1,   tier: 4,
    note: "+1 Strain recovered and +1 to every check" },
  { key: "fine",      name: "Fine Meal",      meals: 1,   tier: 3,
    note: "+1 Strain recovered" },
  { key: "simple",    name: "Simple Meal",    meals: 1,   tier: 2,
    note: "the baseline" },
  { key: "preserved", name: "Preserved Food", meals: 1,   tier: 2,
    note: "keeps forever, counts as a simple meal" },
  { key: "plant",     name: "Plant Product",  meals: 0.5, tier: 1,
    note: "raw — +1 Strain for the week" },
  { key: "animal",    name: "Animal Product", meals: 0.5, tier: 1,
    note: "raw — +1 Strain, and a worm risk" }
];

const TIER_NAME = {
  4: "Lavish", 3: "Fine", 2: "Simple", 1: "Raw"
};

/**
 * The hunger tier for one person, by how many meals they actually got.
 *
 * Split out from the colony total because a colony that is short does
 * not have to be short evenly — a table will quite reasonably put the
 * wounded on full rations and everybody else on five.
 */
export function hungerFor(meals) {
  const eaten = Math.floor(Math.max(0, meals));
  if (eaten >= 7) return { tier: "Well Fed", level: 0, eaten,
    effect: "Standard. Natural Strain recovery permitted." };
  if (eaten >= 4) return { tier: "Mild Malnourishment", level: 1, eaten,
    effect: "-1 to physical and labour checks. Blocks natural Strain recovery." };
  if (eaten >= 1) return { tier: "Severe Starvation", level: 2, eaten,
    effect: "-2 to all skill checks. Max HP -25%. +2 Strain at end of week." };
  return { tier: "Total Fasting", level: 2, eaten,
    effect: "Max HP halved. From a second consecutive week at zero, Physical save or coma." };
}

/**
 * Share the pool out evenly, nobody over seven.
 *
 * This is only the starting point the dialog fills in — the whole point
 * is that it can then be overridden person by person.
 */
export function evenShares(totalMeals, heads) {
  if (heads <= 0) return [];
  const shares = new Array(heads).fill(0);
  let left = Math.floor(totalMeals);
  // Round-robin rather than divide-and-remainder, so a shortfall lands
  // on as few people as possible being one meal down rather than all of
  // them being fractionally down.
  for (let pass = 0; pass < MEALS_PER_HEAD && left > 0; pass++) {
    for (let i = 0; i < heads && left > 0; i++) { shares[i]++; left--; }
  }
  return shares;
}

/**
 * Work out the week from a plan.
 *
 * @param {object} plan   { lavish: 0, fine: 0, simple: 70, ... }
 * @param {number} heads  how many colonists are eating
 */
export function assessRations(plan, heads) {
  const counts = {};
  let mealsServed = 0;
  for (const f of FOODS) {
    const n = Math.max(0, Number(plan?.[f.key]) || 0);
    counts[f.key] = n;
    mealsServed += n * f.meals;
  }

  const needed = heads * MEALS_PER_HEAD;
  const perHead = heads > 0 ? mealsServed / heads : 0;
  // The hunger table is in whole meals eaten, so round down — a colonist
  // on six and a half meals had six.
  const eaten = Math.floor(perHead);
  const deficit = Math.max(0, MEALS_PER_HEAD - eaten);

  const hunger = hungerFor(eaten);

  // Quality is the worst tier anybody had to eat at, because everyone has
  // to eat a full week at a tier for it to count. If the good food does
  // not stretch to seven a head, the week drops to whatever filled it.
  let remaining = needed;
  let worstTier = 4;
  let served = [];
  for (const f of FOODS) {
    if (remaining <= 0) break;
    const contributes = Math.min(remaining, counts[f.key] * f.meals);
    if (contributes <= 0) continue;
    remaining -= contributes;
    worstTier = Math.min(worstTier, f.tier);
    served.push(f);
  }
  // Nothing served at all is its own case.
  if (!served.length) worstTier = 0;

  const rawOnly = served.length > 0 && served.every(f => f.tier === 1);
  const anyRaw = counts.plant > 0 || counts.animal > 0;

  const quality =
    worstTier === 4 ? { name: "Lavish", strain: -1, bonus: 1,
                        effect: "+1 Strain recovered, and +1 to every check." }
    : worstTier === 3 ? { name: "Fine", strain: -1, bonus: 0,
                        effect: "+1 Strain recovered." }
    : worstTier === 2 ? { name: "Simple", strain: 0, bonus: 0,
                        effect: "The baseline. No bonus, no penalty." }
    : worstTier === 1 ? { name: "Raw", strain: 1, bonus: 0,
                        effect: "+1 Strain for the week." }
    : { name: "Nothing", strain: 0, bonus: 0, effect: "Nobody ate." };

  const warnings = [];
  if (deficit > 0 && heads > 0) {
    warnings.push({
      level: hunger.level >= 2 ? "bad" : "warn",
      text: `${eaten} meal${eaten === 1 ? "" : "s"} a head against seven — ` +
            `${hunger.tier}. ${hunger.effect}`
    });
  }
  if (hunger.level >= 1) {
    warnings.push({ level: "warn",
      text: "Any malnourishment blocks natural Strain recovery, whatever the bedding." });
  }
  if (anyRaw && worstTier === 1) {
    warnings.push({ level: "warn",
      text: "A week on raw food is +1 Strain each. Both Stomach cybernetics " +
            "negate it, as does a Pigskin's Iron Gut." });
  }
  if (rawOnly && counts.animal > 0) {
    warnings.push({ level: "bad",
      text: "A week eating only unprocessed raw food risks Intestinal Worms — " +
            "roll 1d10 per colonist, worms on a 1. Raw animal product is the " +
            "part that bites." });
  }
  if (counts.lavish > 0 && worstTier < 4) {
    warnings.push({ level: "hint",
      text: `Lavish meals were served but the week fell back to ${TIER_NAME[worstTier] ?? "nothing"} — ` +
            `everyone has to eat a full week at a tier for it to count.` });
  }

  return {
    counts, heads, needed,
    mealsServed: Math.round(mealsServed * 10) / 10,
    perHead: Math.round(perHead * 10) / 10,
    eaten, deficit, hunger, quality, warnings,
    short: needed - mealsServed,
    enough: mealsServed >= needed,
    rawOnly, wormRisk: rawOnly && counts.animal > 0
  };
}

/**
 * Sensible starting points, so the common cases are one click.
 * Each returns a plan for the given number of heads.
 */
export function presets(heads) {
  const need = heads * MEALS_PER_HEAD;
  return [
    { key: "simple", label: `All simple meals (${need})`,
      plan: { simple: need } },
    { key: "fine", label: `All fine meals (${need})`,
      plan: { fine: need } },
    { key: "lavish", label: `All lavish meals (${need})`,
      plan: { lavish: need } },
    { key: "raw", label: `All raw (${need * 2})`,
      plan: { plant: need, animal: need } },
    // Five a head: hungry, penalised, but not starving. Literally halving
    // the ration lands in Severe Starvation, which is not what anybody
    // means by "tighten our belts".
    { key: "short", label: `Short rations (${heads * 5})`,
      plan: { simple: heads * 5 } },
    { key: "none", label: "Nothing", plan: {} }
  ];
}

/** What a plan would take out of the stores, by item name. */
export function shoppingList(plan) {
  return FOODS
    .map(f => ({ name: f.name, qty: Math.max(0, Number(plan?.[f.key]) || 0) }))
    .filter(x => x.qty > 0);
}

/**
 * Make the planner live inside the week dialog.
 *
 * Typing a number re-reads the whole plan and redraws the verdict, so
 * the consequences of feeding everyone raw turnips are visible before
 * anyone commits to it rather than afterwards in the results table.
 */
export function wireFoodPlanner(root, heads) {
  const need = root.querySelector("#zed00-food-need");
  const verdict = root.querySelector("#zed00-food-verdict");
  if (!verdict) return;
  // Both the dialog callback and the render hook may reach here; only
  // the first one should attach listeners.
  if (verdict.dataset.wired === "1") return;
  verdict.dataset.wired = "1";

  const readPlan = () => {
    const plan = {};
    for (const input of root.querySelectorAll(".food-qty")) {
      plan[input.dataset.food] = Number(input.value) || 0;
    }
    return plan;
  };

  const mealBoxes = () => [...root.querySelectorAll(".meals")];

  // Share the pool out evenly. Only runs when the plan changes or the
  // button is pressed, so a hand-set exception is never clobbered by
  // somebody typing in the food boxes afterwards.
  const share = (total) => {
    const boxes = mealBoxes();
    const shares = evenShares(total, boxes.length);
    boxes.forEach((b, i) => { b.value = shares[i] ?? 0; });
  };

  const draw = () => {
    const r = assessRations(readPlan(), heads);
    if (need) {
      need.textContent = heads
        ? `${heads} eating · ${r.needed} meals needed`
        : "nobody at the colony";
    }

    if (!heads) {
      verdict.innerHTML =
        `<div class="line hint">Nobody is at the colony this week, so nothing is eaten.</div>`;
      return;
    }

    const tone = r.hunger.level >= 2 ? "bad" : r.hunger.level === 1 ? "warn" : "good";
    const lines = r.warnings.map(w => `<div class="line ${w.level}">${w.text}</div>`).join("");
    const spare = Math.round(Math.abs(r.short) * 10) / 10;

    // How the pool has actually been divided up, which may not be evenly.
    const boxes = mealBoxes();
    const allocated = boxes.reduce((n, b) => n + (Number(b.value) || 0), 0);
    const over = allocated - r.mealsServed;
    const tiers = {};
    for (const b of boxes) {
      const t = hungerFor(Number(b.value) || 0).tier;
      tiers[t] = (tiers[t] ?? 0) + 1;
    }
    const spread = Object.entries(tiers)
      .filter(([t]) => t !== "Well Fed")
      .map(([t, n]) => `${n} on ${t}`)
      .join(", ");

    verdict.innerHTML =
      `<div class="summary ${tone}">` +
      `<b>${r.eaten} meal${r.eaten === 1 ? "" : "s"} a head</b> — ${r.hunger.tier}` +
      (r.quality.name !== "Nothing" ? `, eating ${r.quality.name.toLowerCase()}` : "") + ". " +
      (r.short > 0 ? `<span class="short">${spare} meals short.</span>` : "") +
      (r.short < 0 ? `<span class="hint">${spare} spare.</span>` : "") +
      `</div>` +
      `<div class="line hint">${r.quality.effect}</div>` +
      (boxes.length
        ? `<div class="line ${over > 0 ? "bad" : "hint"}">` +
          `Handed out: ${allocated} of ${Math.floor(r.mealsServed)} served` +
          (over > 0 ? ` — <b>${over} more than there is</b>.` : ".") +
          (spread ? ` ${spread}.` : " Everybody well fed.") +
          `</div>`
        : "") + lines;
  };

  for (const input of root.querySelectorAll(".food-qty")) {
    input.addEventListener("input", () => {
      share(assessRations(readPlan(), heads).mealsServed);
      draw();
    });
  }
  for (const box of mealBoxes()) box.addEventListener("input", draw);

  const evenBtn = root.querySelector("#zed00-share-even");
  if (evenBtn) {
    evenBtn.addEventListener("click", (ev) => {
      ev.preventDefault();
      share(assessRations(readPlan(), heads).mealsServed);
      draw();
    });
  }
  for (const button of root.querySelectorAll(".food-preset")) {
    button.addEventListener("click", (ev) => {
      ev.preventDefault();
      let plan = {};
      try { plan = JSON.parse(button.dataset.plan ?? "{}"); } catch { /* ignore */ }
      for (const input of root.querySelectorAll(".food-qty")) {
        input.value = plan[input.dataset.food] ?? 0;
      }
      share(assessRations(plan, heads).mealsServed);
      draw();
    });
  }
  share(assessRations(readPlan(), heads).mealsServed);
  draw();
}
