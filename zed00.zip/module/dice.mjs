/**
 * Zed-00 has TWO dice scales and they are never mixed.
 *
 *   SKILL CHECKS   2d6 + skill level + attribute modifier, against a TN.
 *                  Beat by 4+ = critical success. Miss by 4+ = critical failure.
 *
 *   SAVES          A BARE d20 against a target of 16 - level - attribute mod.
 *                  The modifier is already IN the target. Do not add it to
 *                  the roll. This mistake has been made before.
 *
 * Attack rolls use d20 + attack bonus + skill + attribute vs Armor Class,
 * which is its own thing again.
 */

export const TN = { easy: 6, standard: 8, hard: 10 };

/* ------------------------------------------------------------------ */
/*  Skill checks — 2d6                                                 */
/* ------------------------------------------------------------------ */

export async function rollSkill(actor, {
  skill = null, attribute = "int", tn = TN.standard,
  bonus = 0, label = "Check", medicine = null, multitask = false
} = {}) {
  const parts = ["2d6"];
  const flavorBits = [];

  const skillLevel = skill?.system?.level ?? -1;
  parts.push(String(skillLevel));
  flavorBits.push(`skill ${skillLevel >= 0 ? "+" : ""}${skillLevel}`);

  const misc = skill?.system?.misc ?? 0;
  if (misc) { parts.push(String(misc)); flavorBits.push(`misc ${misc >= 0 ? "+" : ""}${misc}`); }

  const mod = actor.system.attributes[attribute]?.mod ?? 0;
  parts.push(String(mod));
  flavorBits.push(`${attribute.toUpperCase()} ${mod >= 0 ? "+" : ""}${mod}`);

  // Medicine is a modifier, not a gate.
  if (medicine !== null) {
    const med = { none: -2, herbal: 0, industrial: 1, glitterworld: 2 }[medicine] ?? 0;
    parts.push(String(med));
    flavorBits.push(`${medicine} ${med >= 0 ? "+" : ""}${med}`);
  }

  // Exposure, Unstable and Bloodied all stack. So does darkness.
  const pen = (actor.system.checkPenalty ?? 0) + (actor.system.darknessPenalty ?? 0);
  if (pen) { parts.push(String(pen)); flavorBits.push(`conditions ${pen}`); }

  if (multitask) { parts.push("-2"); flavorBits.push("multitasking -2"); }
  if (bonus)     { parts.push(String(bonus)); flavorBits.push(`bonus ${bonus >= 0 ? "+" : ""}${bonus}`); }

  const roll = await new Roll(parts.join(" + ")).evaluate();
  const margin = roll.total - tn;
  const outcome =
    margin >= 4 ? "Critical success" :
    margin >= 0 ? "Success" :
    margin <= -4 ? "Critical failure" : "Failure";

  // Colony labour: crit 150%, success full, failure half, crit failure nothing.
  const yieldMultiplier =
    margin >= 4 ? 1.5 : margin >= 0 ? 1 : margin <= -4 ? 0 : 0.5;

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>${label}</strong> vs TN ${tn} — <em>${outcome}</em>
             <div class="zed00-detail">${flavorBits.join(" · ")}</div>`
  });

  return { roll, margin, outcome, yieldMultiplier };
}

/* ------------------------------------------------------------------ */
/*  Saves — a bare d20                                                 */
/* ------------------------------------------------------------------ */

export async function rollSave(actor, type = "physical", { penalty = 0, label = null } = {}) {
  const target = actor.system.saves?.[type] ?? 15;
  const effective = target + penalty;          // threats raise the target

  // BARE d20. The attribute modifier is already inside the target.
  const roll = await new Roll("1d20").evaluate();
  const success = roll.total >= effective;

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>${label ?? type} save</strong> — needs ${effective}+ —
             <em>${success ? "Success" : "Failure"}</em>`
  });
  return { roll, success, target: effective };
}

/* ------------------------------------------------------------------ */
/*  Attacks                                                            */
/* ------------------------------------------------------------------ */

export async function rollAttack(actor, weapon, { skill = null, ac = null, modifiers = 0, burst = false } = {}) {
  const sys = weapon.system;
  const notes = [];
  const notes0 = [];
  let notesLow = false;

  // Dual-wielding is a property of the weapon, not a button. Pair an
  // off-hand on the weapon sheet and every attack uses both.
  const offhand = sys.offhandId ? actor.items.get(sys.offhandId) : null;
  const dual = !!offhand && offhand.system.usable;
  if (!sys.usable) return ui.notifications.warn(`${weapon.name} is destroyed.`);

  // Out of ammunition is a hard stop, and the player should be told why.
  // Burst costs three. Dual-wielding spends from both weapons, and a
  // dual burst needs both to be burst-capable.
  if (burst && dual && !offhand.system.burst) {
    return ui.notifications.warn(
      `${offhand.name} cannot fire bursts, so this pair cannot burst together.`);
  }
  const needed = burst ? 3 : 1;
  if (sys.magazine && (sys.ammo ?? 0) < needed) {
    return ui.notifications.warn(
      `${weapon.name} has ${sys.ammo ?? 0} round${sys.ammo === 1 ? "" : "s"} left` +
      (burst ? " — a burst needs 3. Reload or fire single." : ". Reload first."));
  }

  // If the player has a token targeted, use its AC rather than asking.
  let targetName = null;
  if (ac === null) {
    const t = Array.from(game.user.targets)[0];
    if (t) {
      targetName = t.name;
      ac = t.actor?.system?.armorClass ?? t.actor?.system?.ac ?? 10;
    } else ac = 10;
  }
  const attr = actor.system.attributes[sys.attribute]?.mod ?? 0;
  const skillLevel = skill?.system?.level ?? -2;      // untrained is -2
  const pen = (actor.system.checkPenalty ?? 0) + (actor.system.darknessPenalty ?? 0);

  const parts = ["1d20", String(actor.system.attackBonus), String(skillLevel), String(attr)];
  if (sys.penalties.toHit) parts.push(String(sys.penalties.toHit));
  if (dual) parts.push("-1");
  if (burst) parts.push("+2");
  if (pen) parts.push(String(pen));
  if (modifiers) parts.push(String(modifiers));

  if (dual && sys.category !== "melee" && offhand.system.range.long) {
    const short = Math.min(sys.range.short || 0, offhand.system.range.short || 0);
    const long  = Math.min(sys.range.long || 0, offhand.system.range.long || 0);
    if (long) notes0.push(`Range ${short}/${long} — the shorter of the two.`);
  }

  const roll = await new Roll(parts.join(" + ")).evaluate();
  const natural = roll.dice[0].results[0].result;

  // Spend the ammunition.
  if (sys.magazine && actor.isOwner) {
    const left = Math.max(0, (sys.ammo ?? 0) - needed);
    await weapon.update({ "system.ammo": left });
    if (!left) notesLow = true;
  }
  // Both weapons expend ammunition on every attack, not just the one
  // that resolved. A weapon paired with itself is a melee stack sharing
  // one entry, so there is no second magazine to empty.
  if (dual && offhand.id !== weapon.id && offhand.system.magazine && actor.isOwner) {
    await offhand.update({
      "system.ammo": Math.max(0, (offhand.system.ammo ?? 0) - needed) });
  }
  const hit = roll.total >= ac;

  // A natural 1 puts the weapon at risk. Off-hand weapons never resolve
  // an attack and are never in danger.
  if (burst) notes.push(`<em>Burst — +2 to hit and damage.</em>`);
  if (dual) {
    const b = sys.category === "melee" ? (offhand.system.shock.damage ?? 0) : 1;
    notes.push(`<em>Dual-wielding ${offhand.name} — -1 to hit, +${b} damage, ` +
               `${needed} round${needed === 1 ? "" : "s"} from each.</em>`);
  }
  if (notesLow) notes.push(`<strong>Out of ammunition.</strong>`);
  if (natural === 1) notes.push(`<strong>Natural 1 — Durability Save (${sys.durability}+ on 1d6)</strong>`);
  if (natural === 20) notes.push(`<strong>Natural 20 — the target's armor is at risk</strong>`);
  if (!hit && sys.shock.damage && !sys.penalties.noShock) {
    notes.push(`Miss, but <strong>Shock ${sys.shock.damage}</strong> applies against AC ${sys.shock.ac} or lower`);
  }
  // Burst fire: +2 to hit and +2 damage, three rounds of ammunition.
  let dmgMod = (actor.system.attributes[sys.attribute]?.mod ?? 0) + (sys.penalties.damage ?? 0);
  // Punch is the one skill that adds its level to damage.
  if (sys.unarmed && skill) dmgMod += Math.max(0, skill.system.level);
  if (burst) dmgMod += 2;
  // Melee takes the off-hand weapon's own Shock rating. Ranged is a flat +1.
  if (dual) {
    dmgMod += sys.category === "melee" ? (offhand.system.shock.damage ?? 0) : 1;
  }
  const dmgFormula = `${sys.damage}${dmgMod ? (dmgMod > 0 ? ` + ${dmgMod}` : ` - ${Math.abs(dmgMod)}`) : ""}`;
  notes.push(`<button class="zed00-damage" data-formula="${dmgFormula}" data-label="${weapon.name}">` +
             `Roll damage — ${sys.damage}${dmgMod ? ` and ${dmgMod > 0 ? "+" : ""}${dmgMod}` : ""}</button>`);
  // Weapons that do something beyond damage explain themselves every time.
  if (sys.tl4) {
    notes.push(`<em>TL4 — ignores the tech wall. Powered armor gets no damage reduction and no Shock immunity against this.</em>`);
  } else if (sys.category === "melee" || sys.category === "ranged") {
    notes.push(`<em>Primitive or TL3 — powered armor takes 7 damage reduction and no Shock from this.</em>`);
  }
  if (sys.special) notes.push(`<div class="zed00-effect">${sys.special}</div>`);
  const effectOnly = !sys.damage || sys.damage === "0" || sys.damage === "—";
  if (effectOnly && !sys.special && sys.description) {
    notes.push(`<div class="zed00-effect">${sys.description}</div>`);
  }
  if (sys.mod) notes.push(`<em>${sys.mod}${sys.modNote ? ` — ${sys.modNote}` : ""}</em>`);

  notes.unshift(...notes0);
  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `<strong>${weapon.name}</strong> vs ${targetName ? `${targetName} (AC ${ac})` : `AC ${ac}`} — <em>${hit ? "Hit" : "Miss"}</em>
             ${notes.length ? `<div class="zed00-detail">${notes.join("<br>")}</div>` : ""}`
  });
  return { roll, hit, natural };
}

/* ------------------------------------------------------------------ */
/*  Strain                                                             */
/* ------------------------------------------------------------------ */

/**
 * Every instance of damage taken costs 1 Strain. Shock counts. Damage
 * reduced to zero does not. Non-combat damage does.
 */
export async function takeDamage(actor, amount, { source = "damage", reducedToZero = false } = {}) {
  const sys = actor.system;

  // Temporary hit points go first, and do not come back. The Strain cost
  // still applies — it is one per instance of damage taken, and damage
  // soaked by a temporary layer was still taken.
  const temp = Number(sys.health.temp) || 0;
  const soaked = amount > 0 ? Math.min(temp, amount) : 0;
  const toHp = amount - soaked;

  const newHp = Math.max(sys.health.value - toHp, -999);
  const updates = { "system.health.value": newHp };
  if (soaked) updates["system.health.temp"] = temp - soaked;

  if (!reducedToZero && amount > 0) {
    const buffer = sys.strain.buffer ?? 0;
    if (buffer > 0) updates["system.strain.buffer"] = buffer - 1;
    else updates["system.strain.value"] = Math.min(sys.strain.value + 1, sys.strain.max);
  }

  await actor.update(updates);

  if (soaked) {
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<strong>${actor.name}</strong> — ${soaked} soaked by temporary hit points` +
               `${temp - soaked ? ` (${temp - soaked} left)` : ", now spent"}` +
               `${toHp ? `, ${toHp} through to Hit Points` : ""}.`
    });
  }

  if (newHp <= 0) {
    ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<strong>${actor.name} is down.</strong> Roll on the Standard Injury Chart.
                Stabilizing is a medical check — TN 8, +1 per round elapsed, and it costs a Main Action.`
    });
  }
  return newHp;
}

/** Pushing: the Warrior's negate or the Expert's reroll, past the free use. */
export async function push(actor) {
  const cost = actor.system.nextPushCost;
  if (cost === null) return ui.notifications.warn(`${actor.name} cannot push.`);
  if (actor.system.strain.value + cost > actor.system.strain.max) {
    return ui.notifications.warn(`${actor.name} does not have the Strain to push again.`);
  }
  await actor.update({
    "system.strain.value": actor.system.strain.value + cost,
    "system.pushes": actor.system.pushes + 1
  });
  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<strong>${actor.name} pushes.</strong> ${cost ? `${cost} Strain.` : "Free use."}`
  });
}

/** A scene ends: clear pushes and any Scene-committed Effort. */
export async function endScene(actor) {
  await actor.update({ "system.pushes": 0 });
}


/* ------------------------------------------------------------------ */
/*  Chat cards                                                         */
/* ------------------------------------------------------------------ */

/** Put a power, focus or any described item into chat so the table sees it. */
export async function postItem(actor, item) {
  const sys = item.system;
  const bits = [];

  if (item.type === "power") {
    bits.push(`<b>${capitalise(sys.discipline)}</b> · Tier ${sys.tier} · ` +
              `Effort ${sys.effort} · committed for the ${capitalise(sys.duration)}`);
    if (sys.duration === "day") bits.push(`<em>Gone until a night's rest.</em>`);
  }
  if (item.type === "focus") bits.push(`<b>Focus</b> · Level ${sys.level}`);
  if (item.type === "drug")  bits.push(`Buffer ${sys.buffer} · ${sys.benefit || "—"} / ${sys.drawback || "—"}`);
  if (item.type === "cyberware") bits.push(`<b>${capitalise(sys.band)}</b> · ${sys.strainCost} Strain`);

  await ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<div class="zed00-card">
      <header><img src="${item.img}" width="28"><strong>${item.name}</strong></header>
      ${bits.length ? `<div class="meta">${bits.join("<br>")}</div>` : ""}
      <div class="text">${sys.description || ""}</div>
    </div>`
  });
}

const capitalise = s => String(s ?? "").replace(/^\w/, c => c.toUpperCase());

/** Spend Effort for a power and post it. */
export async function castPower(actor, power) {
  const cost = power.system.effort ?? 0;
  const eff = actor.system.effort;
  if (cost > (eff.max - eff.value)) {
    return ui.notifications.warn(`${actor.name} has only ${eff.max - eff.value} Effort free.`);
  }
  if (power.system.duration !== "instant") {
    await actor.update({ "system.effort.value": eff.value + cost });
  }
  await postItem(actor, power);
}

/**
 * Buttons on chat cards: roll damage, then apply it.
 *
 * The rolled damage card carries an Apply button so nobody has to read a
 * number off chat and type it into a sheet. Mitigation is offered beside
 * it rather than applied automatically, because what reduces damage —
 * powered armour against a primitive weapon, cover, a Trauma Plate — is
 * a judgement the GM makes, not a sum the system can do.
 */
export function registerChatHooks() {
  Hooks.on("renderChatMessageHTML", (msg, html) => {

    // Roll the damage.
    for (const btn of html.querySelectorAll("button.zed00-damage")) {
      btn.addEventListener("click", async ev => {
        ev.preventDefault();
        const r = await new Roll(btn.dataset.formula).evaluate();
        const label = btn.dataset.label ?? "Damage";
        await r.toMessage({
          flavor: `<strong>${label}</strong> — damage` +
            `<div class="zed00-apply">` +
            `<button class="zed00-take" data-amount="${r.total}" data-label="${label}">` +
            `Apply ${r.total} to the target</button>` +
            `<button class="zed00-take" data-amount="${r.total}" data-label="${label}" data-mitigate="1">` +
            `Apply with mitigation…</button></div>`
        });
      });
    }

    // Apply it to whatever is targeted, or selected.
    for (const btn of html.querySelectorAll("button.zed00-take")) {
      btn.addEventListener("click", async ev => {
        ev.preventDefault();
        await applyDamageToTargets(
          Number(btn.dataset.amount) || 0,
          btn.dataset.label ?? "damage",
          btn.dataset.mitigate === "1");
      });
    }
  });
}

/** Everything the user is pointing at: targets first, then selection. */
function pickedActors() {
  const targeted = [...(game.user.targets ?? [])].map(t => t.actor).filter(Boolean);
  if (targeted.length) return targeted;
  return (canvas?.tokens?.controlled ?? []).map(t => t.actor).filter(Boolean);
}

/**
 * Apply an amount to the targets, optionally asking what got through
 * first. Structures take it on their hit points; people go through
 * takeDamage so Strain and the injury rules still fire.
 */
export async function applyDamageToTargets(amount, label, askMitigation = false) {
  const actors = pickedActors();
  if (!actors.length) {
    return ui.notifications.warn(
      "Target a token first — or select one — then apply the damage.");
  }

  let final = amount;
  let why = "";
  if (askMitigation) {
    const answer = await promptMitigation(amount, actors);
    if (answer === null) return;
    final = Math.max(0, amount - answer.reduction);
    why = answer.why;
  }

  for (const actor of actors) {
    if (actor.type === "structure") {
      const sys = actor.system;
      const hp = Math.max(0, sys.health.value - final);
      const frac = sys.health.max ? hp / sys.health.max : 0;
      const cond = hp <= 0 ? "destroyed" : frac <= 0.25 ? "broken"
                 : frac <= 0.6 ? "damaged" : "pristine";
      await actor.update({ "system.health.value": hp, "system.condition": cond });
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor }),
        content: `<strong>${actor.name}</strong> takes ${final} from ${label}` +
                 `${why ? ` (${why})` : ""} — ${hp}/${sys.health.max}, ${cond}.`
      });
      continue;
    }
    await takeDamage(actor, final, {
      source: label,
      reducedToZero: final <= 0 && amount > 0
    });
  }
}

/** Ask what got through, with the usual culprits as one-click answers. */
async function promptMitigation(amount, actors) {
  const D = foundry.applications.api.DialogV2;
  const names = actors.map(a => a.name).join(", ");
  const content = `
    <div class="zed00 note-form">
      <p><strong>${amount}</strong> incoming on ${names}.</p>
      <div class="line">
        <label>Reduce by</label>
        <input type="number" name="reduction" value="0" min="0" autofocus>
      </div>
      <div class="line">
        <label>Because</label>
        <input type="text" name="why" placeholder="powered armour, cover, Trauma Plate…">
      </div>
      <p class="hint">Damage reduced to nothing still costs a point of Strain —
        the rules count being hit, not being hurt.</p>
    </div>`;

  return D.prompt({
    window: { title: "Apply with mitigation" },
    position: { width: 400 },
    content,
    ok: {
      label: "Apply",
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        return {
          reduction: Number(el.querySelector('[name="reduction"]')?.value) || 0,
          why: el.querySelector('[name="why"]')?.value?.trim() ?? ""
        };
      }
    },
    rejectClose: false
  });
}
