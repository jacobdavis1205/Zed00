/**
 * The colony week.
 *
 * This computes. It does not decide. Every number it works out is shown
 * to the GM before anything is written to a sheet, and nothing fires on
 * its own — the week advances when somebody presses the button.
 *
 * The rules live here rather than in the GM's memory, which is the whole
 * point of it.
 */

const { DialogV2 } = foundry.applications.api;

/* ------------------------------------------------------------------ */
/*  The calendar                                                       */
/* ------------------------------------------------------------------ */

export const SEASONS = ["Spring", "Summer", "Autumn", "Winter"];
const WEEKS_PER_SEASON = 13;          // 52 weeks, four seasons

/** Weather, and what each band does to the Temperature hazard. */
export const WEATHER = {
  Spring: [
    { roll: [1, 6],   name: "Mild",            temp: 0, precip: 0 },
    { roll: [7, 10],  name: "Rain",            temp: 0, precip: 1 },
    { roll: [11, 14], name: "Cold snap",       temp: 1, precip: 0 },
    { roll: [15, 17], name: "Heavy rain",      temp: 0, precip: 2 },
    { roll: [18, 19], name: "Storm",           temp: 1, precip: 2, solar: false },
    { roll: [20, 20], name: "Late frost",      temp: 2, precip: 0, crop: true }
  ],
  Summer: [
    { roll: [1, 7],   name: "Fair",            temp: 0, precip: 0 },
    { roll: [8, 11],  name: "Hot",             temp: 1, precip: 0 },
    { roll: [12, 14], name: "Thunderstorms",   temp: 0, precip: 2, solar: false },
    { roll: [15, 17], name: "Heat wave",       temp: 2, precip: 0 },
    { roll: [18, 19], name: "Drought",         temp: 2, precip: 0, crop: true },
    { roll: [20, 20], name: "Flash fire",      temp: 3, precip: 0, crop: true }
  ],
  Autumn: [
    { roll: [1, 6],   name: "Mild",            temp: 0, precip: 0 },
    { roll: [7, 11],  name: "Rain",            temp: 0, precip: 1 },
    { roll: [12, 15], name: "Cold and wet",    temp: 1, precip: 2, solar: false },
    { roll: [16, 18], name: "First frost",     temp: 2, precip: 0 },
    { roll: [19, 19], name: "Gale",            temp: 1, precip: 2, solar: false },
    { roll: [20, 20], name: "Early winter",    temp: 3, precip: 1, crop: true }
  ],
  Winter: [
    { roll: [1, 5],   name: "Cold",            temp: 1, precip: 0 },
    { roll: [6, 10],  name: "Hard cold",       temp: 2, precip: 0 },
    { roll: [11, 14], name: "Snow",            temp: 2, precip: 1, solar: false },
    { roll: [15, 17], name: "Blizzard",        temp: 3, precip: 2, solar: false },
    { roll: [18, 19], name: "Deep freeze",     temp: 3, precip: 0 },
    { roll: [20, 20], name: "Killing cold",    temp: 3, precip: 2, solar: false }
  ]
};

/** Where somebody slept, and what it does. */
export const BEDDING = {
  none:         { label: "Rough — nothing at all", shelter: 2, strain: 0 },
  bedroll:      { label: "A bedroll",              shelter: 1, strain: 0 },
  tent:         { label: "A bedroll and a tent",   shelter: 0, strain: 0 },
  basic:        { label: "A basic bed indoors",    shelter: 0, strain: 1 },
  private:      { label: "A private room",         shelter: 0, strain: 2 },
  recreational: { label: "A Recreational Week",    shelter: 0, strain: -1 }   // rolls instead
};

/* ------------------------------------------------------------------ */
/*  State                                                              */
/* ------------------------------------------------------------------ */

export function registerWeekSettings() {
  game.settings.register("zed00", "week", {
    scope: "world", config: false, type: Number, default: 1
  });
  game.settings.register("zed00", "year", {
    scope: "world", config: false, type: Number, default: 5503
  });
  game.settings.register("zed00", "lastWeather", {
    scope: "world", config: false, type: Object, default: null
  });
}

export function currentDate() {
  const week = game.settings.get("zed00", "week");
  const year = game.settings.get("zed00", "year");
  const seasonIndex = Math.floor(((week - 1) % 52) / WEEKS_PER_SEASON);
  return {
    week, year,
    season: SEASONS[seasonIndex],
    weekOfSeason: ((week - 1) % WEEKS_PER_SEASON) + 1,
    label: `Week ${((week - 1) % WEEKS_PER_SEASON) + 1} of ${SEASONS[seasonIndex]}, ${year}`
  };
}

/* ------------------------------------------------------------------ */
/*  Hazards                                                            */
/* ------------------------------------------------------------------ */

/**
 * Work out one colonist's six hazards for the week.
 * Returns the hazards and the resulting Exposure, and changes nothing.
 */
export function assessColonist(actor, { weather, bedding, fed, mitigation = {} }) {
  const sys = actor.system;

  // Temperature: the weather's band, less whatever clothing takes off it.
  const temperature = Math.max(0, (weather?.temp ?? 0) - (mitigation.temperature ?? 0));

  // Precipitation: only bites if you are out in it.
  const outdoors = ["none", "bedroll", "tent"].includes(bedding);
  const precipitation = outdoors
    ? Math.max(0, (weather?.precip ?? 0) - (mitigation.precipitation ?? 0))
    : 0;

  // Shelter and rest is where you slept.
  const shelter = Math.max(0, (BEDDING[bedding]?.shelter ?? 0) - (mitigation.shelter ?? 0));

  // Starvation: fed, short, or nothing.
  const starvation = fed === "none" ? 3 : fed === "short" ? 1 : 0;

  // Withdrawal: dependent and went without.
  const withdrawal = (sys.addictions ?? []).some(a => a.dependent && (a.taken ?? 0) === 0) ? 2 : 0;

  // Air quality is a place, not a week — carried over unless set.
  const airQuality = Math.max(0, mitigation.airQuality ?? sys.exposure.hazards.airQuality ?? 0);

  const hazards = { temperature, airQuality, precipitation, shelter, withdrawal, starvation };
  const worst = Math.max(0, ...Object.values(hazards));

  // The weekly gain is the HIGHEST hazard left, never the sum. A level-1
  // hazard stops at Exposure 2, a level-2 at 4; only a 3 reaches Fatal.
  const ceiling = worst === 0 ? 0 : [0, 2, 4, 5][worst];
  const current = sys.exposure.level ?? 0;
  const next = worst === 0
    ? Math.max(0, current - 1)
    : Math.min(ceiling, current + worst);

  // Strain: recovery by bedding, blocked at Exposure 2 or worse, and
  // Exposure 3 adds 2 on top.
  let strainDelta = 0;
  if (next < 2) strainDelta -= (BEDDING[bedding]?.strain ?? 0);
  if (next >= 3) strainDelta += 2;
  if (fed === "raw") strainDelta += 1;

  return {
    actor, hazards, worst, ceiling,
    exposureFrom: current, exposureTo: next,
    healing: Math.min(sys.health.max - sys.health.value, sys.level),
    strainDelta,
    recreational: bedding === "recreational"
  };
}

/* ------------------------------------------------------------------ */
/*  The dialog                                                         */
/* ------------------------------------------------------------------ */

function weatherFor(season, roll) {
  return WEATHER[season].find(w => roll >= w.roll[0] && roll <= w.roll[1]) ?? WEATHER[season][0];
}

/** Open the week dialog. Computes everything, applies nothing yet. */
export async function openWeek() {
  if (!game.user.isGM) return ui.notifications.warn("The colony week is the GM's to run.");

  const date = currentDate();
  const colonists = game.actors.filter(a =>
    ["character", "colonist"].includes(a.type) && a.hasPlayerOwner !== undefined);

  if (!colonists.length) return ui.notifications.warn("No characters or colonists to run a week for.");

  const roll = await new Roll("1d20").evaluate();
  const weather = weatherFor(date.season, roll.total);

  const bedOptions = Object.entries(BEDDING)
    .map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("");

  const rows = colonists.map(a => `
    <tr data-actor-id="${a.id}">
      <td>${a.name}</td>
      <td><select class="bedding" data-actor-id="${a.id}">${bedOptions}</select></td>
      <td><select class="fed" data-actor-id="${a.id}">
        <option value="fed">Fed</option>
        <option value="raw">Raw food</option>
        <option value="short">Short rations</option>
        <option value="none">Nothing</option>
      </select></td>
      <td><input type="number" class="temp-mit" data-actor-id="${a.id}" value="0" min="0" max="3"
                 title="Levels of Temperature taken off by clothing"></td>
      <td><input type="number" class="air" data-actor-id="${a.id}"
                 value="${a.system.exposure?.hazards?.airQuality ?? 0}" min="0" max="3"
                 title="Air quality where they are"></td>
    </tr>`).join("");

  const content = `
    <div class="zed00 week-dialog">
      <h3>${date.label}</h3>
      <div class="weather-line">
        <b>${weather.name}</b> — rolled ${roll.total}
        ${weather.temp ? ` · Temperature hazard ${weather.temp}` : ""}
        ${weather.precip ? ` · Precipitation ${weather.precip}` : ""}
        ${weather.solar === false ? " · no solar output" : ""}
        ${weather.crop ? " · <span class='bad'>crops at risk</span>" : ""}
      </div>
      <div class="hint">Change the weather here if the story wants something else.</div>
      <select id="zed00-weather">
        ${WEATHER[date.season].map(w =>
          `<option value="${w.name}" ${w.name === weather.name ? "selected" : ""}>${w.name}</option>`).join("")}
      </select>

      <table class="items">
        <thead><tr><th>Who</th><th>Slept</th><th>Ate</th><th>Cold kept off</th><th>Air</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="hint">
        Nothing is written until you press Apply. The next screen shows exactly what will change.
      </div>
    </div>`;

  const answers = await DialogV2.prompt({
    window: { title: "The Colony Week", icon: "fas fa-calendar" },
    position: { width: 680 },
    content,
    ok: {
      label: "Work it out",
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        const get = (cls, id) => el.querySelector(`.${cls}[data-actor-id="${id}"]`)?.value;
        return {
          weatherName: el.querySelector("#zed00-weather")?.value,
          people: colonists.map(a => ({
            id: a.id,
            bedding: get("bedding", a.id) ?? "basic",
            fed: get("fed", a.id) ?? "fed",
            temperature: Number(get("temp-mit", a.id) ?? 0),
            airQuality: Number(get("air", a.id) ?? 0)
          }))
        };
      }
    }
  });

  if (!answers) return;

  const chosen = WEATHER[date.season].find(w => w.name === answers.weatherName) ?? weather;
  const results = answers.people.map(p => {
    const actor = game.actors.get(p.id);
    return assessColonist(actor, {
      weather: chosen,
      bedding: p.bedding,
      fed: p.fed,
      mitigation: { temperature: p.temperature, airQuality: p.airQuality }
    });
  });

  await reviewAndApply(date, chosen, results);
}

/* ------------------------------------------------------------------ */
/*  Review                                                             */
/* ------------------------------------------------------------------ */

async function reviewAndApply(date, weather, results) {
  const rows = results.map(r => {
    const moved = r.exposureTo - r.exposureFrom;
    const dir = moved > 0 ? "bad" : moved < 0 ? "good" : "";
    return `<tr>
      <td>${r.actor.name}</td>
      <td class="${dir}">${r.exposureFrom} → <b>${r.exposureTo}</b></td>
      <td>${r.worst || "—"}</td>
      <td>${r.healing ? `+${r.healing}` : "—"}</td>
      <td class="${r.strainDelta > 0 ? "bad" : r.strainDelta < 0 ? "good" : ""}">
        ${r.strainDelta > 0 ? `+${r.strainDelta}` : r.strainDelta || "—"}</td>
      <td class="hint">${Object.entries(r.hazards)
        .filter(([, v]) => v > 0).map(([k, v]) => `${k} ${v}`).join(", ") || "clear"}</td>
    </tr>`;
  }).join("");

  const ok = await DialogV2.confirm({
    window: { title: "What the week does", icon: "fas fa-clipboard-check" },
    position: { width: 720 },
    content: `<div class="zed00">
      <h3>${date.label} — ${weather.name}</h3>
      <table class="items">
        <thead><tr><th>Who</th><th>Exposure</th><th>Worst hazard</th><th>HP</th><th>Strain</th><th>Hazards</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="hint">Apply writes these to the sheets and advances the week.</div>
    </div>`,
    yes: { label: "Apply and advance" },
    no: { label: "Cancel — change nothing" }
  });

  if (!ok) return ui.notifications.info("Week cancelled. Nothing changed.");

  for (const r of results) {
    const sys = r.actor.system;
    const updates = {
      "system.exposure.level": r.exposureTo,
      "system.exposure.hazards": r.hazards,
      "system.health.value": Math.min(sys.health.max, sys.health.value + r.healing)
    };

    let strain = sys.strain.value + r.strainDelta;
    if (r.recreational && r.exposureTo < 2) {
      const rec = await new Roll("1d4 + 1").evaluate();
      strain -= rec.total;
      await rec.toMessage({
        speaker: ChatMessage.getSpeaker({ actor: r.actor }),
        flavor: "<strong>Recreational Week</strong> — Strain cleared"
      });
    }
    updates["system.strain.value"] = Math.clamp(strain, 0, sys.strain.max);

    // Tick anything with a stated duration.
    if (sys.injuries?.some(i => i.weeks > 0)) {
      updates["system.injuries"] = sys.injuries.map(i =>
        i.weeks > 0 ? { ...i, weeks: i.weeks - 1 } : i);
    }
    if (sys.diseases?.some(d => d.weeks > 0)) {
      updates["system.diseases"] = sys.diseases.map(d =>
        d.weeks > 0 ? { ...d, weeks: d.weeks - 1 } : d);
    }
    // A new week resets the drug count, dependency intact.
    if (sys.addictions?.length) {
      updates["system.addictions"] = sys.addictions.map(a => ({ ...a, taken: 0 }));
    }

    await r.actor.update(updates);
  }

  await game.settings.set("zed00", "week", date.week + 1);
  await game.settings.set("zed00", "lastWeather", weather);

  const worsened = results.filter(r => r.exposureTo > r.exposureFrom);
  const recovered = results.filter(r => r.exposureTo < r.exposureFrom);

  await ChatMessage.create({
    content: `<div class="zed00-card">
      <header><strong>${date.label}</strong></header>
      <div class="meta">${weather.name}${weather.solar === false ? " — no solar output this week" : ""}
        ${weather.crop ? "<br><b>Crops at risk.</b>" : ""}</div>
      <div class="text">
        ${worsened.length ? `<b>Worse:</b> ${worsened.map(r => `${r.actor.name} (${r.exposureTo})`).join(", ")}<br>` : ""}
        ${recovered.length ? `<b>Recovering:</b> ${recovered.map(r => r.actor.name).join(", ")}<br>` : ""}
        ${!worsened.length && !recovered.length ? "An uneventful week." : ""}
      </div>
    </div>`
  });

  ui.notifications.info(`Week advanced. It is now ${currentDate().label}.`);
}

/* ------------------------------------------------------------------ */

export function registerWeekHooks() {
  registerWeekSettings();

  // A button in the scene controls, under tokens, for the GM.
  Hooks.on("getSceneControlButtons", controls => {
    const tokens = controls.tokens ?? controls.find?.(c => c.name === "token");
    if (!tokens || !game.user.isGM) return;
    const tool = {
      name: "zed00-week",
      title: "Run the colony week",
      icon: "fas fa-calendar-day",
      button: true,
      visible: true,
      onChange: () => openWeek(),
      onClick: () => openWeek()
    };
    if (Array.isArray(tokens.tools)) tokens.tools.push(tool);
    else if (tokens.tools) tokens.tools["zed00-week"] = tool;
  });
}
