/**
 * The colony week.
 *
 * This computes. It does not decide. Every number it works out is shown
 * to the GM before anything is written to a sheet, and nothing fires on
 * its own — the week advances when somebody presses the button.
 *
 * The rules live here rather than in the GM's memory, which is the whole
 * point of it.
 */

import { openUpkeep } from "./upkeep.mjs";
import { placedStockpiles } from "./structures.mjs";
import { openCalendar, registerCalendarSettings } from "./calendar.mjs";

const { DialogV2 } = foundry.applications.api;

/* ------------------------------------------------------------------ */
/*  The calendar                                                       */
/* ------------------------------------------------------------------ */

export const SEASONS = ["Spring", "Summer", "Autumn", "Winter"];
const WEEKS_PER_SEASON = 13;          // 52 weeks, four seasons

/**
 * Weather, by season, on a d20.
 *
 * Flags, and what reads them:
 *   temp     levels of Temperature exposure, 0-3
 *   band     "cold" or "heat" — which apparel helps, and what the
 *            mitigation column is called that week
 *   precip   levels of Precipitation exposure, 0-2
 *   solar    false means solar panels produce nothing
 *   wind     true means turbines run at their ceiling, false at nothing,
 *            absent means the middle of their 10-20 range
 *   dark     true means outdoor work is working in the dark: -2 to
 *            everything but the talking skills
 *   crop     true means the week threatens a standing crop regardless of
 *            how well it was tended
 */
export const WEATHER = {
  Spring: [
    { roll: [1, 4],   name: "Mild",           temp: 0, precip: 0 },
    { roll: [5, 7],   name: "Rain",           temp: 0, precip: 1 },
    { roll: [8, 9],   name: "Morning fog",    temp: 0, precip: 0, dark: true,
      note: "It never quite lifts. Outdoor work is work in the dark." },
    { roll: [10, 11], name: "Cold snap",      temp: 1, band: "cold", precip: 0 },
    { roll: [12, 13], name: "Blustery",       temp: 0, precip: 0, wind: true,
      note: "Good week to own a turbine." },
    { roll: [14, 15], name: "Heavy rain",     temp: 0, precip: 2 },
    { roll: [16, 17], name: "Thaw and mud",   temp: 0, precip: 1,
      note: "Everything takes longer than it should." },
    { roll: [18, 18], name: "Storm",          temp: 1, band: "cold", precip: 2,
      solar: false, wind: false },
    { roll: [19, 19], name: "Hail",           temp: 1, band: "cold", precip: 2,
      solar: false, crop: true,
      note: "Stones the size of knuckles. Anything standing in a field is at risk." },
    { roll: [20, 20], name: "Late frost",     temp: 2, band: "cold", precip: 0,
      crop: true, note: "Comes in the night, after everything has budded." }
  ],
  Summer: [
    { roll: [1, 5],   name: "Fair",           temp: 0, precip: 0 },
    { roll: [6, 8],   name: "Hot",            temp: 1, band: "heat", precip: 0 },
    { roll: [9, 10],  name: "Muggy",          temp: 1, band: "heat", precip: 1,
      note: "Close, airless and wet. Nothing dries." },
    { roll: [11, 12], name: "Thunderstorms",  temp: 0, precip: 2, solar: false },
    { roll: [13, 14], name: "Clear and still", temp: 1, band: "heat", precip: 0,
      wind: false, note: "Cloudless, and not a breath of air. The turbines sit idle." },
    { roll: [15, 16], name: "Heat wave",      temp: 2, band: "heat", precip: 0 },
    { roll: [17, 17], name: "Dust storm",     temp: 2, band: "heat", precip: 0,
      solar: false, dark: true, crop: true,
      note: "Grit in everything. You cannot see across the compound." },
    { roll: [18, 18], name: "Drought",        temp: 2, band: "heat", precip: 0, crop: true },
    { roll: [19, 19], name: "Smoke haze",     temp: 2, band: "heat", precip: 0,
      solar: false, dark: true,
      note: "Something is burning a long way off. The sun is a dull coin." },
    { roll: [20, 20], name: "Flash fire",     temp: 3, band: "heat", precip: 0, crop: true }
  ],
  Autumn: [
    { roll: [1, 4],   name: "Mild",           temp: 0, precip: 0 },
    { roll: [5, 7],   name: "Rain",           temp: 0, precip: 1 },
    { roll: [8, 9],   name: "Autumn fog",     temp: 1, band: "cold", precip: 0, dark: true,
      note: "Thick and cold and slow to shift." },
    { roll: [10, 11], name: "Cold and wet",   temp: 1, band: "cold", precip: 2, solar: false },
    { roll: [12, 13], name: "Windfall gales", temp: 1, band: "cold", precip: 1, wind: true,
      note: "Hard on roofs, kind to turbines." },
    { roll: [14, 15], name: "First frost",    temp: 2, band: "cold", precip: 0 },
    { roll: [16, 17], name: "Driving rain",   temp: 1, band: "cold", precip: 2, solar: false },
    { roll: [18, 18], name: "Gale",           temp: 1, band: "cold", precip: 2,
      solar: false, wind: false,
      note: "Too much wind, in the end, even for the turbines." },
    { roll: [19, 19], name: "Sleet",          temp: 2, band: "cold", precip: 2,
      solar: false, crop: true },
    { roll: [20, 20], name: "Early winter",   temp: 3, band: "cold", precip: 1, crop: true }
  ],
  Winter: [
    { roll: [1, 4],   name: "Cold",           temp: 1, band: "cold", precip: 0 },
    { roll: [5, 7],   name: "Hard cold",      temp: 2, band: "cold", precip: 0 },
    { roll: [8, 9],   name: "Clear and bitter", temp: 2, band: "cold", precip: 0,
      note: "Blue sky, no warmth in it at all." },
    { roll: [10, 11], name: "Snow",           temp: 2, band: "cold", precip: 1, solar: false },
    { roll: [12, 13], name: "Whiteout",       temp: 2, band: "cold", precip: 1,
      solar: false, dark: true,
      note: "You can lose the walk between two buildings in this." },
    { roll: [14, 15], name: "Thaw",           temp: 1, band: "cold", precip: 2,
      note: "Everything that froze is now water, and all of it is indoors." },
    { roll: [16, 17], name: "Blizzard",       temp: 3, band: "cold", precip: 2,
      solar: false, wind: false, dark: true },
    { roll: [18, 18], name: "Deep freeze",    temp: 3, band: "cold", precip: 0 },
    { roll: [19, 19], name: "Ice storm",      temp: 3, band: "cold", precip: 2,
      solar: false, crop: true,
      note: "Everything glazed over. Anything left outside is part of the ice now." },
    { roll: [20, 20], name: "Killing cold",   temp: 3, band: "cold", precip: 2,
      solar: false, wind: false }
  ]
};

/** Where somebody slept, and what it does. */
export const BEDDING = {
  none:         { label: "Rough — nothing at all", shelter: 2, strain: 0 },
  bedroll:      { label: "A bedroll",              shelter: 1, strain: 0 },
  tent:         { label: "A bedroll and shelter",  shelter: 0, strain: 0 },
  basic:        { label: "A basic bed indoors",    shelter: 0, strain: 1 },
  private:      { label: "A private room",         shelter: 0, strain: 2 },
  recreational: { label: "A Recreational Week",    shelter: 0, strain: -1 }   // rolls instead
};

/**
 * What a colonist's own kit takes off this week's hazards.
 *
 * Only readied gear counts — a parka at the bottom of the pack keeps
 * nobody warm — and only against the hazard it is actually for. Cold
 * Apparel does nothing in a heat wave, which is the whole point of
 * there being two kinds.
 */
export function autoMitigation(actor, weather) {
  const band = weather?.band ?? null;        // "cold", "heat" or neither
  let temperature = 0, airQuality = 0, precipitation = 0;
  const used = [];

  for (const it of actor.items ?? []) {
    if (it.type !== "gear") continue;
    const s = it.system ?? {};
    if (!s.protects || s.stowed) continue;   // has to be to hand
    const v = Number(s.mitigation) || 0;

    if (s.mitigates === band)                 { temperature += v;   used.push(it); }
    else if (s.mitigates === "air")           { airQuality += v;    used.push(it); }
    else if (s.mitigates === "precipitation") { precipitation += v; used.push(it); }
  }

  // A matched pair of detox organs clears bad air outright, anywhere.
  const detox = (actor.items ?? []).filter(i =>
    i.type === "cyberware" && /detox\s+(lung|kidney)/i.test(i.name)).length;
  if (detox >= 2) airQuality = 99;
  else if (detox === 1) airQuality += 1;

  return { temperature, airQuality, precipitation, used, band };
}

/** "Cold kept off" reads wrong in a heat wave. */
export function mitigationLabel(weather) {
  if (!weather?.temp) return "Weather kept off";
  return weather.band === "heat" ? "Heat kept off" : "Cold kept off";
}

/* ------------------------------------------------------------------ */
/*  State                                                              */
/* ------------------------------------------------------------------ */

export function registerWeekSettings() {
  game.settings.register("zed00", "week", {
    scope: "world", config: false, type: Number, default: 1
  });
  game.settings.register("zed00", "year", {
    scope: "world", config: false, type: Number, default: 5503
  });
  game.settings.register("zed00", "lastWeather", {
    scope: "world", config: false, type: Object, default: null
  });
}

/**
 * The weather the last week was run under.
 *
 * The upkeep tally needs it to say what the generators are doing *today*
 * rather than on an average week, which is the difference between "we
 * have enough power" and "we have enough power while the sun is out".
 */
export function currentWeather() {
  return game.settings.get("zed00", "lastWeather") ?? null;
}

export function currentDate() {
  const week = game.settings.get("zed00", "week");
  const year = game.settings.get("zed00", "year");
  const seasonIndex = Math.floor(((week - 1) % 52) / WEEKS_PER_SEASON);
  return {
    week, year,
    season: SEASONS[seasonIndex],
    weekOfSeason: ((week - 1) % WEEKS_PER_SEASON) + 1,
    label: `Week ${((week - 1) % WEEKS_PER_SEASON) + 1} of ${SEASONS[seasonIndex]}, ${year}`
  };
}

/* ------------------------------------------------------------------ */
/*  Hazards                                                            */
/* ------------------------------------------------------------------ */

/**
 * Work out one colonist's six hazards for the week.
 * Returns the hazards and the resulting Exposure, and changes nothing.
 */
export function assessColonist(actor, { weather, bedding, fed, mitigation = {} }) {
  const sys = actor.system;

  // Temperature: the weather's band, less whatever clothing takes off it.
  const temperature = Math.max(0, (weather?.temp ?? 0) - (mitigation.temperature ?? 0));

  // Precipitation: only bites if you are out in it.
  const outdoors = ["none", "bedroll", "tent"].includes(bedding);
  const precipitation = outdoors
    ? Math.max(0, (weather?.precip ?? 0) - (mitigation.precipitation ?? 0))
    : 0;

  // Shelter and rest is where you slept.
  const shelter = Math.max(0, (BEDDING[bedding]?.shelter ?? 0) - (mitigation.shelter ?? 0));

  // Starvation: fed, short, or nothing.
  const starvation = fed === "none" ? 3 : fed === "short" ? 1 : 0;

  // Withdrawal: dependent and went without.
  const withdrawal = (sys.addictions ?? []).some(a => a.dependent && (a.taken ?? 0) === 0) ? 2 : 0;

  // Air quality is a place, not a week — carried over unless set.
  const airQuality = Math.max(0, mitigation.airQuality ?? sys.exposure.hazards.airQuality ?? 0);

  const hazards = { temperature, airQuality, precipitation, shelter, withdrawal, starvation };
  const worst = Math.max(0, ...Object.values(hazards));

  // The weekly gain is the HIGHEST hazard left, never the sum. A level-1
  // hazard stops at Exposure 2, a level-2 at 4; only a 3 reaches Fatal.
  const ceiling = worst === 0 ? 0 : [0, 2, 4, 5][worst];
  const current = sys.exposure.level ?? 0;
  const next = worst === 0
    ? Math.max(0, current - 1)
    : Math.min(ceiling, current + worst);

  // Strain: recovery by bedding, blocked at Exposure 2 or worse, and
  // Exposure 3 adds 2 on top.
  let strainDelta = 0;
  if (next < 2) strainDelta -= (BEDDING[bedding]?.strain ?? 0);
  if (next >= 3) strainDelta += 2;
  if (fed === "raw") strainDelta += 1;

  return {
    actor, hazards, worst, ceiling, bedding,
    exposureFrom: current, exposureTo: next,
    healing: Math.min(sys.health.max - sys.health.value, sys.level),
    strainDelta,
    strainBlocked: next >= 2,
    notes: [],
    recreational: false      // set by the caller, if they took the week off
  };
}

/**
 * A Recreational Week's Strain recovery.
 *
 * The rec room sets the die, and two pieces of furniture each bend it in
 * their own way: a Slot Machine is variance, so roll twice and keep the
 * better; a Dreamweave Pod is simply more, so add one.
 */
export async function rollRecreation(tier, item) {
  const DIE = { none: "", low: "1d2+1", medium: "1d4+1", high: "1d6+1" };
  const formula = DIE[tier] ?? "";
  if (!formula) {
    return { total: 0, note: "Took the week off, but there is no rec room to take it in." };
  }

  const first = await new Roll(formula).evaluate();
  let used = first;
  let note = `Recreational week — ${formula} rolled ${first.total}`;

  if (item === "slot") {
    const second = await new Roll(formula).evaluate();
    used = second.total > first.total ? second : first;
    note = `Recreational week at the Slot Machine — ${formula} twice ` +
           `(${first.total}, ${second.total}), kept ${used.total}`;
  }

  let total = used.total;
  if (item === "pod") {
    total += 1;
    note = `Recreational week in the Dreamweave Pod — ${formula} rolled ` +
           `${used.total}, and +1 from the Pod`;
  }
  return { total, note, formula };
}

/* ------------------------------------------------------------------ */
/*  The dialog                                                         */
/* ------------------------------------------------------------------ */

function weatherFor(season, roll) {
  return WEATHER[season].find(w => roll >= w.roll[0] && roll <= w.roll[1]) ?? WEATHER[season][0];
}

/** Open the week dialog. Computes everything, applies nothing yet. */
export async function openWeek() {
  if (!game.user.isGM) return ui.notifications.warn("The colony week is the GM's to run.");

  const date = currentDate();

  // Only the people living there. A visiting trader or a faction contact
  // can have a full sheet without being fed and frozen every week; the
  // flag lives on their sheet and every row here can still be unticked.
  const everyone = game.actors.filter(a => ["character", "colonist"].includes(a.type));
  const colonists = everyone.filter(a => a.system.atColony !== false);

  // An empty colony is a legitimate week — the party is away, the stores
  // still rot, the date still moves. So this carries on regardless; the
  // dialog simply has no rows in it.
  if (!colonists.length && everyone.length) {
    ui.notifications.info(
      `None of your ${everyone.length} character sheets are marked "At the colony". ` +
      `Running the week for the place itself — stores and the date.`);
  }

  const roll = await new Roll("1d20").evaluate();
  const weather = weatherFor(date.season, roll.total);

  // "A Recreational Week" used to be an option in here, which lost the
  // bed it was slept in. It is its own column now.
  const bedOptions = Object.entries(BEDDING)
    .filter(([k]) => k !== "recreational")
    .map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("");

  const REC_TIERS = {
    none:   "No rec room",
    low:    "Low quality — 1d2+1",
    medium: "Medium quality — 1d4+1",
    high:   "High quality — 1d6+1"
  };

  // Each colonist's own kit fills these in; override anything by hand.
  const rows = colonists.map(a => {
    const auto = autoMitigation(a, weather);
    const worn = auto.used.length
      ? `Wearing ${auto.used.map(i => i.name).join(", ")}`
      : "Nothing readied that helps";
    const air = Math.max(0,
      (a.system.exposure?.hazards?.airQuality ?? 0) - Math.min(3, auto.airQuality));
    return `
    <tr data-actor-id="${a.id}">
      <td><label class="check"><input type="checkbox" class="present" data-actor-id="${a.id}" checked>
          ${a.name}</label></td>
      <td><select class="bedding" data-actor-id="${a.id}">${bedOptions}</select></td>
      <td><select class="spent" data-actor-id="${a.id}"
                  title="A Recreational Week heals Strain on a die instead of the flat recovery a bed gives. They still slept somewhere — that is the column to the left.">
        <option value="work">Worked</option>
        <option value="rec">Recreational week</option>
      </select>
      <select class="rec-item" data-actor-id="${a.id}" title="Recreational furniture used, if any.">
        <option value="">—</option>
        <option value="slot">Slot Machine — roll twice, keep the better</option>
        <option value="pod">Dreamweave Pod — one extra Strain cleared</option>
      </select></td>
      <td><select class="fed" data-actor-id="${a.id}">
        <option value="fed">Fed</option>
        <option value="raw">Raw food</option>
        <option value="short">Short rations</option>
        <option value="none">Nothing</option>
      </select></td>
      <td><input type="number" class="temp-mit" data-actor-id="${a.id}"
                 value="${Math.min(3, auto.temperature)}" min="0" max="3"
                 title="${worn}. Add anything the colony is doing — a campfire or a heater takes more off."></td>
      <td><input type="number" class="air" data-actor-id="${a.id}"
                 value="${air}" min="0" max="3"
                 title="Air quality where they are, after masks and implants"></td>
    </tr>`;
  }).join("");

  const content = `
    <div class="zed00 week-dialog">
      <h3>${date.label}</h3>
      <div class="weather-line">
        <b>${weather.name}</b> — rolled ${roll.total}
        ${weather.temp ? ` · Temperature hazard ${weather.temp}` : ""}
        ${weather.precip ? ` · Precipitation ${weather.precip}` : ""}
        ${weather.solar === false ? " · no solar output" : ""}
        ${weather.wind === true ? " · turbines at full" : ""}
        ${weather.wind === false ? " · no wind output" : ""}
        ${weather.dark ? " · <span class='bad'>outdoor work is in the dark (-2)</span>" : ""}
        ${weather.crop ? " · <span class='bad'>crops at risk</span>" : ""}
      </div>
      ${weather.note ? `<div class="weather-note">${weather.note}</div>` : ""}
      <div class="hint">Change the weather here if the story wants something else.</div>
      <select id="zed00-weather">
        ${WEATHER[date.season].map(w =>
          `<option value="${w.name}" ${w.name === weather.name ? "selected" : ""}>${w.name}</option>`).join("")}
      </select>

      <div class="rec-room">
        <label>The colony's rec room</label>
        <select id="zed00-recroom" title="A fully enclosed room up to 5x5 with at least two working pieces of recreational furniture. This sets the die a Recreational Week rolls.">
          ${Object.entries(REC_TIERS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}
        </select>
      </div>

      <table class="items">
        <thead><tr><th>Who</th><th>Slept</th><th>Week spent</th><th>Ate</th>
          <th>${mitigationLabel(weather)}</th><th>Air</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="hint">
        Untick anyone who was away this week. Sleeping and how the week was
        spent are separate — a colonist resting in a barracks of bedrolls is
        having a different week from one resting in a private suite.
      </div>
      <div class="hint">
        Nothing is written until you press Apply. The next screen shows exactly what will change.
      </div>
    </div>`;

  const answers = await DialogV2.prompt({
    window: { title: "The Colony Week", icon: "fas fa-calendar" },
    position: { width: 680 },
    content,
    ok: {
      label: "Work it out",
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        const get = (cls, id) => el.querySelector(`.${cls}[data-actor-id="${id}"]`)?.value;
        const ticked = (cls, id) =>
          el.querySelector(`.${cls}[data-actor-id="${id}"]`)?.checked ?? true;
        return {
          weatherName: el.querySelector("#zed00-weather")?.value,
          recRoom: el.querySelector("#zed00-recroom")?.value ?? "none",
          people: colonists
            .filter(a => ticked("present", a.id))
            .map(a => ({
              id: a.id,
              bedding: get("bedding", a.id) ?? "basic",
              recreational: get("spent", a.id) === "rec",
              recItem: get("rec-item", a.id) ?? "",
              fed: get("fed", a.id) ?? "fed",
              temperature: Number(get("temp-mit", a.id) ?? 0),
              airQuality: Number(get("air", a.id) ?? 0)
            }))
        };
      }
    }
  });

  if (!answers) return;

  const chosen = WEATHER[date.season].find(w => w.name === answers.weatherName) ?? weather;

  // Nobody home is still a week. Food rots, the date moves, and the
  // weather happened whether or not anyone was there to feel it.
  const results = [];
  for (const p of answers.people) {
    const actor = game.actors.get(p.id);
    const assessed = assessColonist(actor, {
      weather: chosen,
      bedding: p.bedding,
      fed: p.fed,
      mitigation: { temperature: p.temperature, airQuality: p.airQuality }
    });
    // Remember which consumables did the work, so charges get spent.
    assessed.usedMasks = autoMitigation(actor, chosen).used;

    // A Recreational Week replaces the bed's flat Strain recovery with a
    // roll, and leaves the bed's Exposure shelter exactly as it was.
    if (p.recreational) {
      assessed.recreational = true;
      const rec = await rollRecreation(answers.recRoom, p.recItem);
      assessed.notes.push(rec.note);
      // Exposure 2 or worse blocks Strain recovery however the week was
      // spent — you cannot relax your way out of frostbite.
      if (assessed.strainBlocked) {
        assessed.notes.push("Exposure 2 or worse — no Strain recovery, rec room or not.");
      } else {
        // Replaces the bed's flat recovery rather than stacking with it.
        const bedGave = BEDDING[p.bedding]?.strain ?? 0;
        assessed.strainDelta += bedGave - rec.total;
      }
    }
    if (weather.dark) {
      assessed.notes.push("Fog or dust all week — outdoor work took -2.");
    }
    results.push(assessed);
  }

  await reviewAndApply(date, chosen, results);
}

/* ------------------------------------------------------------------ */
/*  Review                                                             */
/* ------------------------------------------------------------------ */

/**
 * Clear out whatever went off this week, everywhere it is stored.
 *
 * A freezer stops the clock rather than slowing it: anything in a
 * freezing stockpile has its spoilage date pushed along with the week,
 * so it never arrives. Goods left uncovered lose a quarter instead.
 */
export async function spoilStockpiles(week) {
  if (!game.user.isGM) return;
  // Stockpiles on the map, not entries in the sidebar — one shed in the
  // catalogue is not a shed in the colony.
  const piles = placedStockpiles();

  for (const pile of piles) {
    const frozen = pile.system.freezing && pile.system.working;
    const gone = [], docked = [];

    for (const good of pile.items) {
      const s = good.system ?? {};
      const spoils = Number(s.spoilsOn) || 0;

      // Freezing stops the clock rather than slowing it, so a dated lot
      // simply never arrives at its date.
      if (spoils && frozen) {
        await good.update({ "system.spoilsOn": spoils + 1 });
        continue;
      }
      if (spoils && spoils <= week) { gone.push(good); continue; }

      // Wood, textiles and anything that was once alive lose a quarter a
      // week on an uncovered pile. Metal and stone sit out in the rain
      // quite happily. This bites whether or not the lot has a date.
      if (!pile.system.covered && s.organic) {
        const qty = Number(s.quantity) || 0;
        const left = Math.ceil(qty * 0.75);
        if (left < qty) {
          docked.push(`${good.name} ${qty} → ${left}`);
          if (left <= 0) gone.push(good);
          else await good.update({ "system.quantity": left });
        }
      }
    }

    for (const g of gone) await g.delete();
    if (gone.length || docked.length) {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: pile }),
        content: `<strong>${pile.name}</strong><br>` +
          (gone.length ? `Spoiled: ${gone.map(g => g.name).join(", ")}.<br>` : "") +
          (docked.length ? `<span class="hint">Uncovered losses: ${docked.join(", ")}.</span>` : "")
      });
    }
  }
}

async function reviewAndApply(date, weather, results) {
  const empty = results.length === 0
    ? `<tr><td colspan="6" class="hint">Nobody at the colony this week. The
        date moves, stores still rot, and the weather still happened.</td></tr>`
    : "";
  const rows = empty || results.map(r => {
    const moved = r.exposureTo - r.exposureFrom;
    const dir = moved > 0 ? "bad" : moved < 0 ? "good" : "";
    return `<tr>
      <td>${r.actor.name}</td>
      <td class="${dir}">${r.exposureFrom} → <b>${r.exposureTo}</b></td>
      <td>${r.worst || "—"}</td>
      <td>${r.healing ? `+${r.healing}` : "—"}</td>
      <td class="${r.strainDelta > 0 ? "bad" : r.strainDelta < 0 ? "good" : ""}">
        ${r.strainDelta > 0 ? `+${r.strainDelta}` : r.strainDelta || "—"}</td>
      <td class="hint">${Object.entries(r.hazards)
        .filter(([, v]) => v > 0).map(([k, v]) => `${k} ${v}`).join(", ") || "clear"}
        ${(r.notes ?? []).map(n => `<div class="note-line">${n}</div>`).join("")}</td>
    </tr>`;
  }).join("");

  const ok = await DialogV2.confirm({
    window: { title: "What the week does", icon: "fas fa-clipboard-check" },
    position: { width: 720 },
    content: `<div class="zed00">
      <h3>${date.label} — ${weather.name}</h3>
      <table class="items">
        <thead><tr><th>Who</th><th>Exposure</th><th>Worst hazard</th><th>HP</th><th>Strain</th><th>Hazards</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="hint">Apply writes these to the sheets and advances the week.</div>
    </div>`,
    yes: { label: "Apply and advance" },
    no: { label: "Cancel — change nothing" }
  });

  if (!ok) return ui.notifications.info("Week cancelled. Nothing changed.");

  for (const r of results) {
    const sys = r.actor.system;
    const updates = {
      "system.exposure.level": r.exposureTo,
      "system.exposure.hazards": r.hazards,
      "system.health.value": Math.min(sys.health.max, sys.health.value + r.healing)
    };

    // The Recreational Week roll already happened, with the rec room's
    // own die and whatever furniture was used, and is folded into
    // strainDelta. Nothing more to roll here.
    const strain = sys.strain.value + r.strainDelta;
    updates["system.strain.value"] = Math.clamp(strain, 0, sys.strain.max);

    // Tick anything with a stated duration.
    if (sys.injuries?.some(i => i.weeks > 0)) {
      updates["system.injuries"] = sys.injuries.map(i =>
        i.weeks > 0 ? { ...i, weeks: i.weeks - 1 } : i);
    }
    if (sys.diseases?.some(d => d.weeks > 0)) {
      updates["system.diseases"] = sys.diseases.map(d =>
        d.weeks > 0 ? { ...d, weeks: d.weeks - 1 } : d);
    }
    // A new week resets the drug count, dependency intact.
    if (sys.addictions?.length) {
      updates["system.addictions"] = sys.addictions.map(a => ({ ...a, taken: 0 }));
    }

    await r.actor.update(updates);

    // Masks are consumable. A week spent breathing through one spends a
    // charge, and a spent mask stops protecting anybody.
    if (r.hazards.airQuality > 0 || r.usedMasks?.length) {
      const spend = (r.usedMasks ?? []).filter(i =>
        i.system.mitigates === "air" && i.system.chargesMax > 0);
      for (const m of spend) {
        await m.update({ "system.charges": Math.max(0, m.system.charges - 1) });
      }
      const empty = spend.filter(m => m.system.charges <= 1);
      if (empty.length) {
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor: r.actor }),
          content: `<strong>${empty.map(m => m.name).join(", ")}</strong> — spent. ` +
                   `Make or buy another before next week.`
        });
      }
    }

    // Food in the pack rots on the same clock as food in the shed.
    const perished = r.actor.items.filter(i =>
      (Number(i.system?.spoilsOn) || 0) && i.system.spoilsOn <= date.week);
    for (const p of perished) await p.delete();
    if (perished.length) {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: r.actor }),
        content: `<strong>Spoiled in the pack:</strong> ${perished.map(p => p.name).join(", ")}.`
      });
    }
  }

  // --- stockpiles rot too -------------------------------------------
  await spoilStockpiles(date.week);

  // Remember it, so the upkeep tally knows whether the sun was out.
  await game.settings.set("zed00", "lastWeather", weather);
  await game.settings.set("zed00", "week", date.week + 1);
  await game.settings.set("zed00", "lastWeather", weather);

  const worsened = results.filter(r => r.exposureTo > r.exposureFrom);
  const recovered = results.filter(r => r.exposureTo < r.exposureFrom);

  await ChatMessage.create({
    content: `<div class="zed00-card">
      <header><strong>${date.label}</strong></header>
      <div class="meta">${weather.name}${weather.solar === false ? " — no solar output this week" : ""}
        ${weather.crop ? "<br><b>Crops at risk.</b>" : ""}</div>
      <div class="text">
        ${worsened.length ? `<b>Worse:</b> ${worsened.map(r => `${r.actor.name} (${r.exposureTo})`).join(", ")}<br>` : ""}
        ${recovered.length ? `<b>Recovering:</b> ${recovered.map(r => r.actor.name).join(", ")}<br>` : ""}
        ${!worsened.length && !recovered.length ? "An uneventful week." : ""}
      </div>
    </div>`
  });

  ui.notifications.info(`Week advanced. It is now ${currentDate().label}.`);
}

/* ------------------------------------------------------------------ */

export function registerWeekHooks() {
  registerWeekSettings();
  registerCalendarSettings();

  // Buttons in the scene controls, under tokens, for the GM.
  Hooks.on("getSceneControlButtons", controls => {
    const tokens = controls.tokens ?? controls.find?.(c => c.name === "token");
    if (!tokens) return;

    const add = (tool) => {
      if (Array.isArray(tokens.tools)) tokens.tools.push(tool);
      else if (tokens.tools) tokens.tools[tool.name] = tool;
    };

    // Players get the calendar and the upkeep tally. Both are things the
    // colony knows about itself — how much power there is and what is
    // coming up are exactly the things players should be arguing over
    // without having to ask the GM to read it out.
    add({
      name: "zed00-calendar",
      title: "Colony calendar",
      icon: "fas fa-calendar",
      button: true, visible: true,
      onChange: () => openCalendar(),
      onClick: () => openCalendar()
    });

    add({
      name: "zed00-upkeep",
      title: "Colony upkeep — power, wood and fuel",
      icon: "fas fa-bolt",
      button: true, visible: true,
      onChange: () => openUpkeep(currentWeather()),
      onClick: () => openUpkeep(currentWeather())
    });

    if (!game.user.isGM) return;

    add({
      name: "zed00-week",
      title: "Run the colony week",
      icon: "fas fa-calendar-day",
      button: true, visible: true,
      onChange: () => openWeek(),
      onClick: () => openWeek()
    });

  });
}
