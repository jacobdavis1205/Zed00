/**
 * The colony week.
 *
 * This computes. It does not decide. Every number it works out is shown
 * to the GM before anything is written to a sheet, and nothing fires on
 * its own — the week advances when somebody presses the button.
 *
 * The rules live here rather than in the GM's memory, which is the whole
 * point of it.
 */

import { openUpkeep, settleBatteries } from "./upkeep.mjs";
import { placedStockpiles } from "./structures.mjs";
import { openResearch, registerResearchSettings, researchWeek, benches }
  from "./research.mjs";
import { openCalendar, registerCalendarSettings, registerCalendarSocket } from "./calendar.mjs";
import { dateForWeek, MONTHS } from "./dates.mjs";
import { assessRations, presets, FOODS, shoppingList, wireFoodPlanner, hungerFor }
  from "./rations.mjs";

const { DialogV2 } = foundry.applications.api;

/* ------------------------------------------------------------------ */
/*  The calendar                                                       */
/* ------------------------------------------------------------------ */

export const SEASONS = ["Spring", "Summer", "Autumn", "Winter"];
const WEEKS_PER_SEASON = 13;          // 52 weeks, four seasons

/**
 * Weather, by season, on a d20.
 *
 * Every season spans its own range rather than being one note repeated:
 * spring gets a warm spell as well as a late frost, autumn gets heat it
 * has no business having, winter gets a thaw. The nasty results sit at
 * the top of each table, so a bad week is always a high roll.
 *
 * Flags, and what reads them:
 *   temp     levels of Temperature exposure, 0-3
 *   band     "cold" or "heat" — which apparel helps, and what the
 *            mitigation column is called that week
 *   precip   levels of Precipitation exposure, 0-2
 *   solar    false means solar panels produce nothing
 *   wind     true means turbines run at their ceiling, false at nothing,
 *            absent means the middle of their 10-20 range
 *   dark     true means outdoor work is work in the dark: -2 to
 *            everything but the talking skills
 *   crop     true means the week threatens a standing crop however well
 *            it was tended
 */
export const WEATHER = {
  Spring: [
    { roll: [1, 5], name: "Mild", temp: 0, precip: 0,
      note: "Nothing to complain about, which in spring is its own kind of luck." },
    { roll: [6, 7], name: "Rain", temp: 0, precip: 1,
      note: "Steady, grey and unremarkable. The fields take it gladly." },
    { roll: [8, 9], name: "Warm spell", temp: 1, band: "heat", precip: 0,
      note: "Early heat, weeks ahead of itself. Pleasant, and faintly wrong." },
    { roll: [10, 11], name: "Morning fog", temp: 0, precip: 0, dark: true,
      note: "It never quite lifts. Outdoor work is work in the dark." },
    { roll: [12, 13], name: "Blustery", temp: 0, precip: 0, wind: true,
      note: "A good week to own a turbine and a bad one to be roofing." },
    { roll: [14, 15], name: "Heavy rain", temp: 0, precip: 2, solar: false,
      note: "Standing water everywhere. Nothing dries, nothing stays clean." },
    { roll: [16, 17], name: "Cold snap", temp: 1, band: "cold", precip: 0,
      note: "Winter putting a hand back through the door." },
    { roll: [18, 18], name: "Spring storm", temp: 1, band: "cold", precip: 2, solar: false, wind: false,
      note: "Wind and water together, too much of both." },
    { roll: [19, 19], name: "Hail", temp: 1, band: "cold", precip: 2, solar: false, crop: true,
      note: "Stones the size of knuckles. Anything standing in a field is at risk." },
    { roll: [20, 20], name: "Late frost", temp: 2, band: "cold", precip: 0, crop: true,
      note: "Comes in the night, after everything has budded. The cruellest week in the year." }
  ],
  Summer: [
    { roll: [1, 5], name: "Fair", temp: 0, precip: 0,
      note: "Warm, bright and entirely reasonable." },
    { roll: [6, 7], name: "Hot", temp: 1, band: "heat", precip: 0,
      note: "Work gets done early and late, and not much in between." },
    { roll: [8, 9], name: "Summer rain", temp: 0, precip: 1,
      note: "Brief, warm and welcome. Everything greens overnight." },
    { roll: [10, 11], name: "Muggy", temp: 1, band: "heat", precip: 1,
      note: "Close, airless and wet. Nothing dries, including people." },
    { roll: [12, 13], name: "Clear and still", temp: 1, band: "heat", precip: 0, wind: false,
      note: "Cloudless, and not a breath of air. The turbines stand idle." },
    { roll: [14, 15], name: "Thunderstorms", temp: 0, precip: 2, solar: false,
      note: "Rolling in each afternoon, loud and brief." },
    { roll: [16, 17], name: "Heat wave", temp: 2, band: "heat", precip: 0,
      note: "Days of it, one after another, with no night cool enough to recover in." },
    { roll: [18, 18], name: "Dust storm", temp: 2, band: "heat", precip: 0, solar: false, dark: true, crop: true,
      note: "Grit in everything. You cannot see across the compound." },
    { roll: [19, 19], name: "Drought", temp: 2, band: "heat", precip: 0, crop: true,
      note: "The ground opens in cracks you can put a hand into." },
    { roll: [20, 20], name: "Flash fire", temp: 3, band: "heat", precip: 0, crop: true,
      note: "It moves faster than anyone expects it to. It always does." }
  ],
  Autumn: [
    { roll: [1, 5], name: "Mild", temp: 0, precip: 0,
      note: "The best weather of the year, and nobody ever believes it will last." },
    { roll: [6, 6], name: "Indian summer", temp: 1, band: "heat", precip: 0,
      note: "Heat out of season, borrowed and brief." },
    { roll: [7, 9], name: "Rain", temp: 0, precip: 1,
      note: "The long grey business of autumn getting under way." },
    { roll: [10, 11], name: "Autumn fog", temp: 1, band: "cold", precip: 0, dark: true,
      note: "Thick, cold and slow to shift." },
    { roll: [12, 13], name: "Windfall gales", temp: 1, band: "cold", precip: 1, wind: true,
      note: "Hard on roofs, kind to turbines." },
    { roll: [14, 15], name: "Cold and wet", temp: 1, band: "cold", precip: 2, solar: false,
      note: "The combination that gets into people." },
    { roll: [16, 17], name: "First frost", temp: 2, band: "cold", precip: 0,
      note: "White on everything at dawn, gone by nine, back tomorrow." },
    { roll: [18, 18], name: "Gale", temp: 1, band: "cold", precip: 2, solar: false, wind: false,
      note: "Too much wind, in the end, even for the turbines." },
    { roll: [19, 19], name: "Sleet", temp: 2, band: "cold", precip: 2, solar: false, crop: true,
      note: "Neither one thing nor the other, and worse than both." },
    { roll: [20, 20], name: "Early winter", temp: 3, band: "cold", precip: 1, crop: true,
      note: "It arrives a month early and does not leave again." }
  ],
  Winter: [
    { roll: [1, 5], name: "Cold", temp: 1, band: "cold", precip: 0,
      note: "Ordinary winter. Bearable with a coat and a roof." },
    { roll: [6, 7], name: "Hard cold", temp: 2, band: "cold", precip: 0,
      note: "The kind that finds every gap in a wall." },
    { roll: [8, 9], name: "Clear and bitter", temp: 2, band: "cold", precip: 0,
      note: "Blue sky with no warmth in it at all." },
    { roll: [10, 11], name: "Snow", temp: 2, band: "cold", precip: 1, solar: false,
      note: "Quiet, and prettier from indoors." },
    { roll: [12, 13], name: "Thaw", temp: 1, band: "cold", precip: 2,
      note: "Everything that froze is now water, and all of it is indoors." },
    { roll: [14, 15], name: "Whiteout", temp: 2, band: "cold", precip: 1, solar: false, dark: true,
      note: "You can lose the walk between two buildings in this." },
    { roll: [16, 17], name: "Deep freeze", temp: 3, band: "cold", precip: 0,
      note: "Metal sticks to skin. Nothing mechanical wants to start." },
    { roll: [18, 18], name: "Blizzard", temp: 3, band: "cold", precip: 2, solar: false, wind: false, dark: true,
      note: "Days of it. Nobody goes outside who does not have to." },
    { roll: [19, 19], name: "Ice storm", temp: 3, band: "cold", precip: 2, solar: false, crop: true,
      note: "Everything glazed over. Whatever was left outside is part of the ice now." },
    { roll: [20, 20], name: "Killing cold", temp: 3, band: "cold", precip: 2, solar: false, wind: false,
      note: "The week the colony finds out how well it was built." }
  ],
};

/** Where somebody slept, and what it does. */
export const BEDDING = {
  none:         { label: "Rough — nothing at all", shelter: 2, strain: 0 },
  bedroll:      { label: "A bedroll",              shelter: 1, strain: 0 },
  tent:         { label: "A bedroll and shelter",  shelter: 0, strain: 0 },
  basic:        { label: "A basic bed indoors",    shelter: 0, strain: 1 },
  private:      { label: "A private room",         shelter: 0, strain: 2 },
  recreational: { label: "A Recreational Week",    shelter: 0, strain: -1 }   // rolls instead
};

/**
 * What a colonist's own kit takes off this week's hazards.
 *
 * Only readied gear counts — a parka at the bottom of the pack keeps
 * nobody warm — and only against the hazard it is actually for. Cold
 * Apparel does nothing in a heat wave, which is the whole point of
 * there being two kinds.
 */
export function autoMitigation(actor, weather) {
  const band = weather?.band ?? null;        // "cold", "heat" or neither
  let temperature = 0, airQuality = 0, precipitation = 0;
  const used = [];

  for (const it of actor.items ?? []) {
    if (it.type !== "gear") continue;
    const s = it.system ?? {};
    if (!s.protects || s.stowed) continue;   // has to be to hand
    const v = Number(s.mitigation) || 0;

    if (s.mitigates === band)                 { temperature += v;   used.push(it); }
    else if (s.mitigates === "air")           { airQuality += v;    used.push(it); }
    else if (s.mitigates === "precipitation") { precipitation += v; used.push(it); }
  }

  // A matched pair of detox organs clears bad air outright, anywhere.
  const detox = (actor.items ?? []).filter(i =>
    i.type === "cyberware" && /detox\s+(lung|kidney)/i.test(i.name)).length;
  if (detox >= 2) airQuality = 99;
  else if (detox === 1) airQuality += 1;

  return { temperature, airQuality, precipitation, used, band };
}

/** "Cold kept off" reads wrong in a heat wave. */
export function mitigationLabel(weather) {
  if (!weather?.temp) return "Weather kept off";
  return weather.band === "heat" ? "Heat kept off" : "Cold kept off";
}

/* ------------------------------------------------------------------ */
/*  State                                                              */
/* ------------------------------------------------------------------ */

export function registerWeekSettings() {
  game.settings.register("zed00", "week", {
    scope: "world", config: false, type: Number, default: 1
  });
  game.settings.register("zed00", "year", {
    scope: "world", config: false, type: Number, default: 5503
  });
  game.settings.register("zed00", "lastRations", {
    scope: "world", config: false, type: Object, default: {}
  });

  game.settings.register("zed00", "batteryStorage", {
    name: "Batteries store power week to week",
    hint: "Off (the rules as written): a battery provides its capacity whatever the weather, and that is all it does. On (optional): a battery is also a reservoir — a surplus fills it, a shortfall empties it, and a colony that runs dry goes dark. New batteries start empty either way.",
    scope: "world", config: true, type: Boolean, default: false
  });

  game.settings.register("zed00", "epochDay", {
    name: "The day of the year week 1 begins",
    hint: "1 March is day 60, which is where a campaign that opens in early spring wants to start. 1 January is day 1.",
    scope: "world", config: true, type: Number, default: 60,
    range: { min: 1, max: 365, step: 1 }
  });

  game.settings.register("zed00", "epochYear", {
    name: "The year week 1 falls in",
    hint: "Whatever the colony calls its first year.",
    scope: "world", config: true, type: Number, default: 1
  });

  game.settings.register("zed00", "lastWeather", {
    scope: "world", config: false, type: Object, default: null
  });
}

/**
 * The weather the last week was run under.
 *
 * The upkeep tally needs it to say what the generators are doing *today*
 * rather than on an average week, which is the difference between "we
 * have enough power" and "we have enough power while the sun is out".
 */
export function currentWeather() {
  return game.settings.get("zed00", "lastWeather") ?? null;
}

/** Where week 1 sits in the year. Default: the first of March. */
export function epoch() {
  return {
    epochDay: game.settings.get("zed00", "epochDay") ?? 60,
    epochYear: game.settings.get("zed00", "epochYear") ?? 1
  };
}

/**
 * The current date, as a date.
 *
 * The season comes off the month rather than off week-number-modulo-13,
 * which matters: it means spring starts in March and the seasons land
 * where a player's intuition already puts them.
 */
export function currentDate() {
  const week = game.settings.get("zed00", "week");
  const d = dateForWeek(week, epoch());
  return {
    ...d,
    weekOfSeason: weekOfSeason(week),
    label: `${d.span}, Year ${d.year}`,
    full: `Week ${week} · ${d.span}, Year ${d.year} · ${d.season}`
  };
}

/** How far into the current season this week is. */
export function weekOfSeason(week) {
  const here = dateForWeek(week, epoch()).season;
  let n = 1;
  while (n < 20 && dateForWeek(week - n, epoch()).season === here && week - n >= 1) n++;
  return n;
}

/* ------------------------------------------------------------------ */
/*  Hazards                                                            */
/* ------------------------------------------------------------------ */

/**
 * Work out one colonist's six hazards for the week.
 * Returns the hazards and the resulting Exposure, and changes nothing.
 */
export function assessColonist(actor, { weather, bedding, food, meals = null, mitigation = {} }) {
  const sys = actor.system;

  // Temperature: the weather's band, less whatever clothing takes off it.
  const temperature = Math.max(0, (weather?.temp ?? 0) - (mitigation.temperature ?? 0));

  // Precipitation: only bites if you are out in it.
  const outdoors = ["none", "bedroll", "tent"].includes(bedding);
  const precipitation = outdoors
    ? Math.max(0, (weather?.precip ?? 0) - (mitigation.precipitation ?? 0))
    : 0;

  // Shelter and rest is where you slept.
  const shelter = Math.max(0, (BEDDING[bedding]?.shelter ?? 0) - (mitigation.shelter ?? 0));

  // Starvation comes off the colony's food for the week — everyone eats
  // out of the same stores, so everyone sits at the same hunger tier.
  // Mild Malnourishment is a level-1 hazard, Severe and Total are 2.
  // Hunger alone never kills through Exposure; Consecutive Starvation
  // kills on its own clock.
  // Their own share, if one was set; otherwise the colony's average.
  const mine = meals === null ? null : hungerFor(meals);
  const hunger = mine ?? food?.hunger ?? { level: 0, tier: "Well Fed" };
  const starvation = hunger.level;

  // Withdrawal: dependent and went without.
  const withdrawal = (sys.addictions ?? []).some(a => a.dependent && (a.taken ?? 0) === 0) ? 2 : 0;

  // Air quality is a place, not a week — carried over unless set.
  const airQuality = Math.max(0, mitigation.airQuality ?? sys.exposure.hazards.airQuality ?? 0);

  const hazards = { temperature, airQuality, precipitation, shelter, withdrawal, starvation };
  const worst = Math.max(0, ...Object.values(hazards));

  // The weekly gain is the HIGHEST hazard left, never the sum. A level-1
  // hazard stops at Exposure 2, a level-2 at 4; only a 3 reaches Fatal.
  const ceiling = worst === 0 ? 0 : [0, 2, 4, 5][worst];
  const current = sys.exposure.level ?? 0;
  const next = worst === 0
    ? Math.max(0, current - 1)
    : Math.min(ceiling, current + worst);

  // Strain: recovery by bedding, blocked at Exposure 2 or worse, and
  // Exposure 3 adds 2 on top.
  let strainDelta = 0;
  // Any malnourishment blocks natural recovery whatever the bedding —
  // food comes before comfort matters at all.
  const hungry = hunger.level > 0;
  if (next < 2 && !hungry) strainDelta -= (BEDDING[bedding]?.strain ?? 0);
  if (next >= 3) strainDelta += 2;

  // What the colony ate, and what the stomach can shrug off.
  const ironGut = (actor.items ?? []).some(i =>
    (i.type === "cyberware" && /stomach/i.test(i.name)) ||
    (i.type === "xenotype" && /pigskin/i.test(i.name)) ||
    /iron gut/i.test(i.name));
  if (food?.quality?.strain) {
    if (food.quality.strain > 0 && ironGut) {
      // A raw week costs them nothing.
    } else {
      strainDelta += food.quality.strain;
    }
  }
  if (hunger.tier === "Severe Starvation") strainDelta += 2;

  return {
    actor, hazards, worst, ceiling, bedding, hunger,
    exposureFrom: current, exposureTo: next,
    healing: Math.min(sys.health.max - sys.health.value, sys.level),
    strainDelta,
    strainBlocked: next >= 2,
    notes: [],
    recreational: false      // set by the caller, if they took the week off
  };
}

/**
 * A Recreational Week's Strain recovery.
 *
 * The rec room sets the die, and two pieces of furniture each bend it in
 * their own way: a Slot Machine is variance, so roll twice and keep the
 * better; a Dreamweave Pod is simply more, so add one.
 */
export async function rollRecreation(tier, item) {
  // "sparse" is the module's ruling for a colony with one working piece
  // of recreational furniture. The rules want two for a rec room, so this
  // is below the bottom rung rather than on it: a die, and no +1.
  const DIE = { none: "", sparse: "1d2", low: "1d2+1",
                medium: "1d4+1", high: "1d6+1" };
  const formula = DIE[tier] ?? "";
  if (!formula) {
    return { total: 0, note: "Took the week off, but there is no rec room to take it in." };
  }

  const first = await new Roll(formula).evaluate();
  let used = first;
  let note = `Recreational week — ${formula} rolled ${first.total}`;

  if (item === "slot") {
    const second = await new Roll(formula).evaluate();
    used = second.total > first.total ? second : first;
    note = `Recreational week at the Slot Machine — ${formula} twice ` +
           `(${first.total}, ${second.total}), kept ${used.total}`;
  }

  let total = used.total;
  if (item === "pod") {
    total += 1;
    note = `Recreational week in the Dreamweave Pod — ${formula} rolled ` +
           `${used.total}, and +1 from the Pod`;
  }
  return { total, note, formula };
}

/* ------------------------------------------------------------------ */
/*  The dialog                                                         */
/* ------------------------------------------------------------------ */

function weatherFor(season, roll) {
  return WEATHER[season].find(w => roll >= w.roll[0] && roll <= w.roll[1]) ?? WEATHER[season][0];
}

/** Open the week dialog. Computes everything, applies nothing yet. */
export async function openWeek() {
  if (!game.user.isGM) return ui.notifications.warn("The colony week is the GM's to run.");

  const date = currentDate();

  // Only the people living there. A visiting trader or a faction contact
  // can have a full sheet without being fed and frozen every week; the
  // flag lives on their sheet and every row here can still be unticked.
  const everyone = game.actors.filter(a => ["character", "colonist"].includes(a.type));
  const colonists = everyone.filter(a => a.system.atColony !== false);

  // An empty colony is a legitimate week — the party is away, the stores
  // still rot, the date still moves. So this carries on regardless; the
  // dialog simply has no rows in it.
  if (!colonists.length && everyone.length) {
    ui.notifications.info(
      `None of your ${everyone.length} character sheets are marked "At the colony". ` +
      `Running the week for the place itself — stores and the date.`);
  }

  const roll = await new Roll("1d20").evaluate();
  const weather = weatherFor(date.season, roll.total);

  // "A Recreational Week" used to be an option in here, which lost the
  // bed it was slept in. It is its own column now.
  const bedOptions = Object.entries(BEDDING)
    .filter(([k]) => k !== "recreational")
    .map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("");

  // The plan from last week, so a colony with a settled routine just
  // opens the dialog and presses the button.
  const lastPlan = game.settings.get("zed00", "lastRations") ?? {};

  const REC_TIERS = {
    none:   "No rec room",
    sparse: "A single piece of furniture — 1d2",
    low:    "Low quality — 1d2+1",
    medium: "Medium quality — 1d4+1",
    high:   "High quality — 1d6+1"
  };

  // Each colonist's own kit fills these in; override anything by hand.
  const rows = colonists.map(a => {
    const auto = autoMitigation(a, weather);
    const worn = auto.used.length
      ? `Wearing ${auto.used.map(i => i.name).join(", ")}`
      : "Nothing readied that helps";
    const air = Math.max(0,
      (a.system.exposure?.hazards?.airQuality ?? 0) - Math.min(3, auto.airQuality));
    return `
    <tr data-actor-id="${a.id}">
      <td><label class="check"><input type="checkbox" class="present" data-actor-id="${a.id}" checked>
          ${a.name}</label></td>
      <td><select class="bedding" data-actor-id="${a.id}">${bedOptions}</select></td>
      <td><select class="spent" data-actor-id="${a.id}"
                  title="A Recreational Week heals Strain on a die instead of the flat recovery a bed gives. They still slept somewhere — that is the column to the left.">
        <option value="work">Worked</option>
        <option value="research">Researched</option>
        <option value="rec">Recreational week</option>
      </select>
      <select class="rec-item" data-actor-id="${a.id}" title="Recreational furniture used, if any.">
        <option value="">—</option>
        <option value="slot">Slot Machine — roll twice, keep the better</option>
        <option value="pod">Dreamweave Pod — one extra Strain cleared</option>
      </select></td>
      <td><input type="number" class="meals" data-actor-id="${a.id}"
                 value="7" min="0" max="20"
                 title="Meals this colonist gets. The planner fills these in evenly; change one to feed somebody better or worse than the rest."></td>
      <td><input type="number" class="temp-mit" data-actor-id="${a.id}"
                 value="${Math.min(3, auto.temperature)}" min="0" max="3"
                 title="${worn}. Add anything the colony is doing — a campfire or a heater takes more off."></td>
      <td><input type="number" class="air" data-actor-id="${a.id}"
                 value="${air}" min="0" max="3"
                 title="Air quality where they are, after masks and implants"></td>
    </tr>`;
  }).join("");

  const content = `
    <div class="zed00 week-dialog">
      <h3>${date.label}</h3>
      <div class="weather-line">
        <b>${weather.name}</b> — rolled ${roll.total}
        ${weather.temp ? ` · Temperature hazard ${weather.temp}` : ""}
        ${weather.precip ? ` · Precipitation ${weather.precip}` : ""}
        ${weather.solar === false ? " · no solar output" : ""}
        ${weather.wind === true ? " · turbines at full" : ""}
        ${weather.wind === false ? " · no wind output" : ""}
        ${weather.dark ? " · <span class='bad'>outdoor work is in the dark (-2)</span>" : ""}
        ${weather.crop ? " · <span class='bad'>crops at risk</span>" : ""}
      </div>
      ${weather.note ? `<div class="weather-note">${weather.note}</div>` : ""}
      <div class="weather-pick">
        <span class="hint">Change it if the story wants something else.</span>
        <button type="button" id="zed00-reroll"
                data-bands='${JSON.stringify(WEATHER[date.season].map(w => w.roll))}'>Roll again</button>
      </div>
      <select id="zed00-weather">
        ${WEATHER[date.season].map(w =>
          `<option value="${w.name}" ${w.name === weather.name ? "selected" : ""}>${w.name}</option>`).join("")}
      </select>

      <div class="food-planner" id="zed00-food">
        <div class="head">
          <h4>What the colony eats</h4>
          <span class="need" id="zed00-food-need"></span>
        </div>
        <div class="presets">
          ${presets(colonists.length).map(p =>
            `<button type="button" class="food-preset" data-plan='${JSON.stringify(p.plan)}'>${p.label}</button>`
          ).join("")}
        </div>
        <div class="foods">
          ${FOODS.map(f => `
            <label class="food" title="${f.note}">
              <span class="fname">${f.name}</span>
              <input type="number" min="0" class="food-qty" data-food="${f.key}"
                     value="${lastPlan[f.key] ?? 0}">
              <span class="fnote">${f.note}</span>
            </label>`).join("")}
        </div>
        <div class="verdict" id="zed00-food-verdict"></div>
        <div class="share-row">
          <button type="button" id="zed00-share-even">Share it out evenly</button>
          <span class="hint">Or set anyone's Meals by hand below — feed the
            wounded properly and put the rest on short commons.</span>
        </div>
      </div>

      <div class="rec-room">
        <label>The colony's rec room</label>
        <select id="zed00-recroom" title="A fully enclosed room up to 5x5 with at least two working pieces of recreational furniture. This sets the die a Recreational Week rolls.">
          ${Object.entries(REC_TIERS).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}
        </select>
      </div>

      <table class="items">
        <thead><tr><th>Who</th><th>Slept</th><th>Week spent</th><th>Meals</th>
          <th>${mitigationLabel(weather)}</th><th>Air</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="hint">
        Untick anyone who was away this week. Sleeping and how the week was
        spent are separate — a colonist resting in a barracks of bedrolls is
        having a different week from one resting in a private suite.
      </div>
      <div class="hint">
        Nothing is written until you press Apply. The next screen shows exactly what will change.
      </div>
    </div>`;

  // Belt and braces: wire the planner from the dialog's own render
  // callback AND from the global render hook, since which of the two
  // fires is a detail of the Foundry version rather than something to
  // bet a feature on. wireFoodPlanner is idempotent per element.
  const wireOnce = Hooks.on("renderDialogV2", (app, el) => {
    const root = el instanceof HTMLElement ? el : el?.[0];
    if (root?.querySelector("#zed00-food")) wireFoodPlanner(root, colonists.length);
  });

  const answers = await DialogV2.prompt({
    window: { title: "The Colony Week", icon: "fas fa-calendar" },
    position: { width: 680 },
    content,
    render: (event, dialog) => {
      const el = dialog?.element ?? dialog;
      if (el?.querySelector) wireFoodPlanner(el, colonists.length);
    },
    ok: {
      label: "Work it out",
      callback: (event, button, dialog) => {
        const el = dialog.element ?? button.form;
        const get = (cls, id) => el.querySelector(`.${cls}[data-actor-id="${id}"]`)?.value;
        const ticked = (cls, id) =>
          el.querySelector(`.${cls}[data-actor-id="${id}"]`)?.checked ?? true;
        const plan = {};
        for (const input of el.querySelectorAll(".food-qty")) {
          plan[input.dataset.food] = Number(input.value) || 0;
        }
        return {
          weatherName: el.querySelector("#zed00-weather")?.value,
          recRoom: el.querySelector("#zed00-recroom")?.value ?? "none",
          plan,
          people: colonists
            .filter(a => ticked("present", a.id))
            .map(a => ({
              id: a.id,
              bedding: get("bedding", a.id) ?? "basic",
              meals: Number(get("meals", a.id) ?? 7),
              recreational: get("spent", a.id) === "rec",
              researching: get("spent", a.id) === "research",
              recItem: get("rec-item", a.id) ?? "",
              temperature: Number(get("temp-mit", a.id) ?? 0),
              airQuality: Number(get("air", a.id) ?? 0)
            }))
        };
      }
    }
  });

  Hooks.off("renderDialogV2", wireOnce);
  if (!answers) return;

  const chosen = WEATHER[date.season].find(w => w.name === answers.weatherName) ?? weather;

  // One meal plan for the whole colony — the rules are explicit that
  // everybody eats at the same quality and out of the same stores.
  const food = assessRations(answers.plan, answers.people.length);
  await game.settings.set("zed00", "lastRations", answers.plan);

  // Nobody home is still a week. Food rots, the date moves, and the
  // weather happened whether or not anyone was there to feel it.
  const results = [];
  let researchers = 0;        // one to a bench, best bench first
  for (const p of answers.people) {
    const actor = game.actors.get(p.id);
    const assessed = assessColonist(actor, {
      weather: chosen,
      bedding: p.bedding,
      food, meals: p.meals,
      mitigation: { temperature: p.temperature, airQuality: p.airQuality }
    });
    // Remember which consumables did the work, so charges get spent.
    assessed.usedMasks = autoMitigation(actor, chosen).used;

    // A Recreational Week replaces the bed's flat Strain recovery with a
    // roll, and leaves the bed's Exposure shelter exactly as it was.
    if (p.recreational) {
      assessed.recreational = true;
      const rec = await rollRecreation(answers.recRoom, p.recItem);
      assessed.notes.push(rec.note);
      // Exposure 2 or worse blocks Strain recovery however the week was
      // spent — you cannot relax your way out of frostbite.
      if (assessed.strainBlocked) {
        assessed.notes.push("Exposure 2 or worse — no Strain recovery, rec room or not.");
      } else {
        // Replaces the bed's flat recovery rather than stacking with it.
        const bedGave = BEDDING[p.bedding]?.strain ?? 0;
        assessed.strainDelta += bedGave - rec.total;
      }
    }
    if (p.researching) {
      const free = benches().filter(b => b.working);
      const bench = free[researchers] ?? null;
      researchers++;
      if (!bench) {
        assessed.notes.push(
          "Spent the week researching with no free bench — nothing banked.");
      } else {
        const got = await researchWeek(actor, bench);
        assessed.notes.push(
          `Researched at the ${bench.name} — ${got} point${got === 1 ? "" : "s"}.`);
      }
    }
    if (weather.dark) {
      assessed.notes.push("Fog or dust all week — outdoor work took -2.");
    }
    results.push(assessed);
  }

  await reviewAndApply(date, chosen, results, food);
}

/* ------------------------------------------------------------------ */
/*  Review                                                             */
/* ------------------------------------------------------------------ */

/**
 * Clear out whatever went off this week, everywhere it is stored.
 *
 * A freezer stops the clock rather than slowing it: anything in a
 * freezing stockpile has its spoilage date pushed along with the week,
 * so it never arrives. Goods left uncovered lose a quarter instead.
 */
export async function spoilStockpiles(week) {
  if (!game.user.isGM) return;
  // Stockpiles on the map, not entries in the sidebar — one shed in the
  // catalogue is not a shed in the colony.
  const piles = placedStockpiles();

  for (const pile of piles) {
    const frozen = pile.system.freezing && pile.system.working;
    const gone = [], docked = [];

    for (const good of pile.items) {
      const s = good.system ?? {};
      const spoils = Number(s.spoilsOn) || 0;

      // Freezing stops the clock rather than slowing it, so a dated lot
      // simply never arrives at its date.
      if (spoils && frozen) {
        await good.update({ "system.spoilsOn": spoils + 1 });
        continue;
      }
      if (spoils && spoils <= week) { gone.push(good); continue; }

      // Wood, textiles and anything that was once alive lose a quarter a
      // week on an uncovered pile. Metal and stone sit out in the rain
      // quite happily. This bites whether or not the lot has a date.
      if (!pile.system.covered && s.organic) {
        const qty = Number(s.quantity) || 0;
        const left = Math.ceil(qty * 0.75);
        if (left < qty) {
          docked.push(`${good.name} ${qty} → ${left}`);
          if (left <= 0) gone.push(good);
          else await good.update({ "system.quantity": left });
        }
      }
    }

    for (const g of gone) await g.delete();
    if (gone.length || docked.length) {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: pile }),
        content: `<strong>${pile.name}</strong><br>` +
          (gone.length ? `Spoiled: ${gone.map(g => g.name).join(", ")}.<br>` : "") +
          (docked.length ? `<span class="hint">Uncovered losses: ${docked.join(", ")}.</span>` : "")
      });
    }
  }
}

/**
 * Take the week's food out of the stockpiles.
 *
 * Oldest lot first, so the things with a spoilage clock get eaten before
 * they go off rather than rotting behind a fresher pile. Anything the
 * stores could not cover is reported — it has already been counted as a
 * shortfall in the hunger tier, so this is the GM's note of what the
 * colony actually ran out of.
 */
export async function consumeRations(food) {
  if (!game.user.isGM || !food) return;
  const list = shoppingList(food.counts ?? {});
  if (!list.length) return;

  const piles = placedStockpiles();
  const taken = [], missing = [];

  for (const want of list) {
    let left = want.qty;

    // Every lot of this food across every shed, soonest to spoil first.
    const lots = [];
    for (const pile of piles) {
      for (const good of pile.items) {
        if (good.name.trim().toLowerCase() !== want.name.toLowerCase()) continue;
        lots.push(good);
      }
    }
    lots.sort((a, b) => {
      const sa = Number(a.system.spoilsOn) || Infinity;
      const sb = Number(b.system.spoilsOn) || Infinity;
      return sa - sb;
    });

    for (const lot of lots) {
      if (left <= 0) break;
      const have = Number(lot.system.quantity) || 0;
      const grab = Math.min(have, left);
      left -= grab;
      if (grab >= have) await lot.delete();
      else await lot.update({ "system.quantity": have - grab });
    }

    if (want.qty - left > 0) taken.push(`${want.qty - left} ${want.name}`);
    if (left > 0) missing.push(`${left} ${want.name}`);
  }

  ChatMessage.create({
    content: `<div class="zed00-roll"><h3>Rations</h3>` +
      (taken.length ? `<p>Taken from the stores: ${taken.join(", ")}.</p>` : "") +
      (missing.length
        ? `<p class="bad">Not in the stores: ${missing.join(", ")}. ` +
          `The colony ate what there was.</p>`
        : "") +
      `</div>`
  });
}

async function reviewAndApply(date, weather, results, food = null) {
  const empty = results.length === 0
    ? `<tr><td colspan="6" class="hint">Nobody at the colony this week. The
        date moves, stores still rot, and the weather still happened.</td></tr>`
    : "";
  const rows = empty || results.map(r => {
    const moved = r.exposureTo - r.exposureFrom;
    const dir = moved > 0 ? "bad" : moved < 0 ? "good" : "";
    return `<tr>
      <td>${r.actor.name}</td>
      <td class="${dir}">${r.exposureFrom} → <b>${r.exposureTo}</b></td>
      <td>${r.worst || "—"}</td>
      <td>${r.healing ? `+${r.healing}` : "—"}</td>
      <td class="${r.strainDelta > 0 ? "bad" : r.strainDelta < 0 ? "good" : ""}">
        ${r.strainDelta > 0 ? `+${r.strainDelta}` : r.strainDelta || "—"}</td>
      <td class="hint">${Object.entries(r.hazards)
        .filter(([, v]) => v > 0).map(([k, v]) => `${k} ${v}`).join(", ") || "clear"}
        ${(r.notes ?? []).map(n => `<div class="note-line">${n}</div>`).join("")}</td>
    </tr>`;
  }).join("");

  const ok = await DialogV2.confirm({
    window: { title: "What the week does", icon: "fas fa-clipboard-check" },
    position: { width: 720 },
    content: `<div class="zed00">
      <h3>${date.label} — ${weather.name}</h3>
      <table class="items">
        <thead><tr><th>Who</th><th>Exposure</th><th>Worst hazard</th><th>HP</th><th>Strain</th><th>Hazards</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="hint">Apply writes these to the sheets and advances the week.</div>
    </div>`,
    yes: { label: "Apply and advance" },
    no: { label: "Cancel — change nothing" }
  });

  if (!ok) return ui.notifications.info("Week cancelled. Nothing changed.");

  for (const r of results) {
    const sys = r.actor.system;
    const updates = {
      "system.exposure.level": r.exposureTo,
      "system.exposure.hazards": r.hazards,
      "system.health.value": Math.min(sys.health.max, sys.health.value + r.healing)
    };

    // The Recreational Week roll already happened, with the rec room's
    // own die and whatever furniture was used, and is folded into
    // strainDelta. Nothing more to roll here.
    const strain = sys.strain.value + r.strainDelta;
    updates["system.strain.value"] = Math.clamp(strain, 0, sys.strain.max);

    // Tick anything with a stated duration.
    if (sys.injuries?.some(i => i.weeks > 0)) {
      updates["system.injuries"] = sys.injuries.map(i =>
        i.weeks > 0 ? { ...i, weeks: i.weeks - 1 } : i);
    }
    if (sys.diseases?.some(d => d.weeks > 0)) {
      updates["system.diseases"] = sys.diseases.map(d =>
        d.weeks > 0 ? { ...d, weeks: d.weeks - 1 } : d);
    }
    // A new week resets the drug count, dependency intact.
    if (sys.addictions?.length) {
      updates["system.addictions"] = sys.addictions.map(a => ({ ...a, taken: 0 }));
    }

    await r.actor.update(updates);

    // Masks are consumable. A week spent breathing through one spends a
    // charge, and a spent mask stops protecting anybody.
    if (r.hazards.airQuality > 0 || r.usedMasks?.length) {
      const spend = (r.usedMasks ?? []).filter(i =>
        i.system.mitigates === "air" && i.system.chargesMax > 0);
      for (const m of spend) {
        await m.update({ "system.charges": Math.max(0, m.system.charges - 1) });
      }
      const empty = spend.filter(m => m.system.charges <= 1);
      if (empty.length) {
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor: r.actor }),
          content: `<strong>${empty.map(m => m.name).join(", ")}</strong> — spent. ` +
                   `Make or buy another before next week.`
        });
      }
    }

    // Food in the pack rots on the same clock as food in the shed.
    const perished = r.actor.items.filter(i =>
      (Number(i.system?.spoilsOn) || 0) && i.system.spoilsOn <= date.week);
    for (const p of perished) await p.delete();
    if (perished.length) {
      ChatMessage.create({
        speaker: ChatMessage.getSpeaker({ actor: r.actor }),
        content: `<strong>Spoiled in the pack:</strong> ${perished.map(p => p.name).join(", ")}.`
      });
    }
  }

  // --- stockpiles rot too -------------------------------------------
  await spoilStockpiles(date.week);

  // --- and the food comes out of the sheds ---------------------------
  await consumeRations(food);

  // --- and the grid settles, if the storage rule is on ---------------
  await settleBatteries(weather);

  // Remember it, so the upkeep tally knows whether the sun was out.
  await game.settings.set("zed00", "lastWeather", weather);
  await game.settings.set("zed00", "week", date.week + 1);
  await game.settings.set("zed00", "lastWeather", weather);

  const worsened = results.filter(r => r.exposureTo > r.exposureFrom);
  const recovered = results.filter(r => r.exposureTo < r.exposureFrom);

  await ChatMessage.create({
    content: `<div class="zed00-card">
      <header><strong>${date.label}</strong></header>
      <div class="meta">${weather.name}${weather.solar === false ? " — no solar output this week" : ""}
        ${weather.crop ? "<br><b>Crops at risk.</b>" : ""}</div>
      <div class="text">
        ${worsened.length ? `<b>Worse:</b> ${worsened.map(r => `${r.actor.name} (${r.exposureTo})`).join(", ")}<br>` : ""}
        ${recovered.length ? `<b>Recovering:</b> ${recovered.map(r => r.actor.name).join(", ")}<br>` : ""}
        ${!worsened.length && !recovered.length ? "An uneventful week." : ""}
      </div>
    </div>`
  });

  ui.notifications.info(`Week advanced. It is now ${currentDate().label}.`);
}

/* ------------------------------------------------------------------ */

export function registerWeekHooks() {
  registerWeekSettings();
  registerCalendarSettings();
  registerResearchSettings();
  Hooks.once("ready", registerCalendarSocket);

  // Buttons in the scene controls, under tokens, for the GM.
  Hooks.on("getSceneControlButtons", controls => {
    const tokens = controls.tokens ?? controls.find?.(c => c.name === "token");
    if (!tokens) return;

    const add = (tool) => {
      if (Array.isArray(tokens.tools)) tokens.tools.push(tool);
      else if (tokens.tools) tokens.tools[tool.name] = tool;
    };

    // Players get the calendar and the upkeep tally. Both are things the
    // colony knows about itself — how much power there is and what is
    // coming up are exactly the things players should be arguing over
    // without having to ask the GM to read it out.
    add({
      name: "zed00-calendar",
      title: "Colony calendar",
      icon: "fas fa-calendar",
      button: true, visible: true,
      onChange: () => openCalendar(),
      onClick: () => openCalendar()
    });

    add({
      name: "zed00-research",
      title: "Colony research",
      icon: "fas fa-flask",
      button: true, visible: true,
      onChange: () => openResearch(),
      onClick: () => openResearch()
    });

    add({
      name: "zed00-upkeep",
      title: "Colony upkeep — power, wood and fuel",
      icon: "fas fa-bolt",
      button: true, visible: true,
      onChange: () => openUpkeep(currentWeather()),
      onClick: () => openUpkeep(currentWeather())
    });

    if (!game.user.isGM) return;

    add({
      name: "zed00-week",
      title: "Run the colony week",
      icon: "fas fa-calendar-day",
      button: true, visible: true,
      onChange: () => openWeek(),
      onClick: () => openWeek()
    });

  });
}
